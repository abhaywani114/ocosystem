<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FranchiseMerchantLocTerm extends Model
{
    //
	protected $table = "franchisemerchantlocterm";
}
