<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class rack extends Model
{
    protected $table = 'rack';
    protected $guarded = [];
}
