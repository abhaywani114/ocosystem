<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 11/15/2019
 * Time: 11:15 PM
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class MerchantCreditLimit extends Model
{
    protected $table = 'merchantcreditlimit';
    protected $guarded = [];
}