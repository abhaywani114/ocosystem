<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class inventorycostproduct extends Model
{
    protected $table = 'inventorycostproduct';
    protected $guarded = [];

}
