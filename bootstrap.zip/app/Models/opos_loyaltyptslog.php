<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class opos_loyaltyptslog extends Model
{
    protected $table = 'opos_loyaltyptslog';
}
