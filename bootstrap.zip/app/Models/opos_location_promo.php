<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
//use Illuminate\Database\Eloquent\SoftDeletes;

class opos_location_promo extends Model
{
    protected $table="opos_locationpromo";
    protected $guarded = ['id'];
    //use SoftDeletes;
}
