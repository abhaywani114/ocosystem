<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Creditnoteitem extends Model
{
    protected $table = 'creditnoteitem';
    protected $guarded = [];
  
}
