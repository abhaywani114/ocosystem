<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MerchantLink extends Model
{
    //
    protected $table = "merchantlink";
    protected $guared = ["id","deleted_at","updated_at"];
    protected $fillable = ["initiator_user_id","responder_user_id","status"];
}
