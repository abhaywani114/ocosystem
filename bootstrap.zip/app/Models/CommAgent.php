<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommAgent extends Model
{
    protected $table = 'comm_agent';

    protected $primaryKey = 'id';

}
