<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class productbarcode extends Model
{
    protected $table = 'productbarcode';
    protected $guarded = [];
}
