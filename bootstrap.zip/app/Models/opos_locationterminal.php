<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class opos_locationterminal extends Model
{
    protected $table = 'opos_locationterminal';
    use SoftDeletes;

    protected $guarded = [];

    public function product_name()
    {
        return $this->belongsTo(product::class,'product_id');
    }
}
