<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FranchiseMerchant extends Model
{
    //
    protected $table = "franchisemerchant";

}
