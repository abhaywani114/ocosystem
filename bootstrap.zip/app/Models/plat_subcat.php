<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class plat_subcat extends Model
{
    //
    protected $table='plat_countersubcat1';
}
