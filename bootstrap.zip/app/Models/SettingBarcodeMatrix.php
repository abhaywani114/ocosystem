<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingBarcodeMatrix extends Model
{
    protected $table='setting_barcode_matrix';
    //
}
