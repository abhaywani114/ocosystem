<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class inventorycost extends Model
{
    protected $table = 'inventorycost';
    protected $guarded = [];

}
