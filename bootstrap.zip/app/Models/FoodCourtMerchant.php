<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodCourtMerchant extends Model
{
    protected $table = 'foodcourtmerchant';
    protected $guarded = [];
}
