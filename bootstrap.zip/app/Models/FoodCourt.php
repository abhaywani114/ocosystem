<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodCourt extends Model
{
    protected $table = 'foodcourt';
    protected $guarded = [];
}
