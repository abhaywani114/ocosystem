<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class og_pumplog extends Model
{
    //
    protected $table = "og_pumplog";

}
