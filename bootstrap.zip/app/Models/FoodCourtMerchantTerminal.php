<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodCourtMerchantTerminal extends Model
{
    protected $table = 'foodcourtmerchantterminal';
    protected $guarded = [];
}
