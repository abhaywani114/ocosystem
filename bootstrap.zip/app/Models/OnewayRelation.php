<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OnewayRelation extends Model
{
    protected $fillable = [];
    protected $table = 'onewayrelation';
}
