<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Commission extends Model
{
    protected $table = 'comm_schememgmt';

    protected $primaryKey = 'id';

}
