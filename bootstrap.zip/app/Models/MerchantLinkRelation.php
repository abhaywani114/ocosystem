<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MerchantLinkRelation extends Model
{
    //
    protected $table = "merchantlinkrelation";
    protected $guared = ["id","deleted_at","updated_at"];
    protected $fillable = ["merchantlink_id","status","ptype"];

}
