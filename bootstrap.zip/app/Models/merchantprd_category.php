<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class merchantprd_category extends Model
{
    protected $table = 'merchantprd_category';
     protected $guarded = [];
}
