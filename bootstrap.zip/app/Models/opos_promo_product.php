<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
//use Illuminate\Database\Eloquent\SoftDeletes;

class opos_promo_product extends Model
{
    //
    protected $table="opos_promoproduct";
    protected $guarded = ['id'];
    //use SoftDeletes;

}
