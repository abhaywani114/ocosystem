<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class opos_loyaltyproductredemption extends Model
{
    protected $table = 'opos_loyaltyproductredemption';
}
