<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FranchiseMerchantLoc extends Model
{
    //
    protected $table = "franchisemerchantloc";
}
