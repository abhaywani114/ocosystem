<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\OgFuelMovement;
use \App\Models\stockreportproduct;
use \App\Models\opos_receiptproduct;

class GenerateFuelmovementsCommand extends Command
{
    /**clear
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'generate:fuelmovement';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'creating new fuel movements';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Start generating daily fuelMovements ...');
        $current_day = date('Y-m-d');
        // fetch existing location_ogfuel con
        $og_fuelMovements = OgFuelMovement::select(['location_id', 'ogfuel_id'])->groupBy('location_id', 'ogfuel_id')->get();
        $i = 0;
        foreach ($og_fuelMovements as $og_fuelMovement) {
            // check if there is fuelMovement in current day
            $today_og_fuelMovement = OgFuelMovement::where([
                    ['ogfuel_id' , $og_fuelMovement->ogfuel_id],
                    ['location_id' , $og_fuelMovement->location_id]
                ])
                ->whereBetween('updated_at', [date($current_day. ' 00:00:00'), date($current_day.' 23:59:59')])
                ->get()->first();

            if(!$today_og_fuelMovement){
                // generate new row of fuel movement   
                $og_fuelManage = OgFuelMovement::where([
                        ['ogfuel_id' , $og_fuelMovement->ogfuel_id],
                        ['location_id' , $og_fuelMovement->location_id]
                    ])
                    ->orderBy('updated_at','desc')->get()->first();
                if($og_fuelManage) {
                        $sales = $this->_getFuelSales($og_fuelManage->ogfuel_id, date('Y-m-d'));
                        $receipt = $this->_getFuelReceipt($og_fuelManage->ogfuel_id, date('Y-m-d'));
                        $book = $this->_getFuelBook($og_fuelManage->tank_dip, $sales , $receipt);
                    OgFuelMovement::create([
                        'location_id'   => $og_fuelManage->location_id,
                        'ogfuel_id'     => $og_fuelManage->ogfuel_id,
                        'date'          => date('Y-m-d H:i:s'),
                        'cforward'      => $og_fuelManage->tank_dip,
                        'sales'         => $sales,
                        'receipt'       => $receipt,
                        'book'          => $book
                    ]);

                    $i++;
                }
            }
        }
        
        $this->info('operation finished, ('. $i . ') rows created ');
    }

    protected function _getFuelSales($product_id , $date){
        $sold_products = opos_receiptproduct::where([['product_id',$product_id]])
                ->whereBetween('updated_at', [date($date. ' 00:00:00'), date($date.' 23:59:59')])
                ->pluck('quantity');
        $sales = 0;
        foreach ($sold_products as $key => $value) {
            $sales += (float)$value;
        }
        return $sales;
    }

    
    protected function _getFuelReceipt($product_id , $date){
        $loc_product = stockreportproduct::where([['product_id',$product_id]])
            ->whereBetween('updated_at', [date($date. ' 00:00:00'), date($date.' 23:59:59')])
            ->pluck('quantity');
        $receipt = 0;
        foreach ($loc_product as $key => $value) {
            $receipt += (float)$value;
        }
        return $receipt;
    }

    protected function _getFuelBook($cforward, $sales , $receipt) {
        return (($cforward - $sales) + $receipt);
    }

}
