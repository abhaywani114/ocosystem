<?php

namespace App\Http\Controllers;

use App\User;
use Milon\Barcode\DNS1D;
use Milon\Barcode\DNS2D;
use Illuminate\Http\Request;

class MobUserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function show($id)
    {
        $user = User::find($id);
        $num = $user->staff->systemid;
        $username = $user->name;
        $code = DNS1D::getBarcodePNG($num, "C39+", 3, 33);
        // $qr = DNS2D::getBarcodeSVG($num, 'DATAMATRIX', 10, 10);
        // $qrcode = DNS2D::getBarcodeHTML($num, "QRCODE");
        
        $img = '<img style = "
            width: 93%;
            height: 65px;
            margin-top: 23px;" 
            src="data:image/png;base64, ' 
            . $code . '" alt="barcode" />';
        

        return view('platypos.user.users', compact('username', 'num'))->with('barcode', $img);
    }

    public function personal(User $user) {
        $num = $user->staff->systemid;
        $username = $user->name;
        $qrcode = DNS2D::getBarcodeHTML($num, "QRCODE");
        return view('mob_personal.personal', compact('username', 'num'))->with('barcode', $qrcode);
    }

    public function repair_and_maintenance(User $user)
    {
        $lists = ['Corrective Maintenance Report'];
        return view('mob_personal.repair_maintenance', compact('lists'));
    }

    public function repair_and_maintenance_item($id) 
    {
        return view('mob_personal.repair_maint_item');
    }

    public function repair_and_maintenance_form($id)
    {
        return view('mob_personal.repair_maint_form');
    }

    public function repair_and_maintenance_form_add()
    {
        return view('mob_personal.repair_maint_add');
    }
}
