<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MobEcommerceController extends Controller
{
    public function mobEcommerce()
    {
        return view('mob_ecommerce.mob_ecomerce');
    }
}
