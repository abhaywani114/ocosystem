<?php

namespace App\Http\Controllers;

use DB;
use Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Matrix\Exception;
use Yajra\DataTables\DataTables;
use \App\Classes\SystemID;
use \App\Classes\UserData;
use \App\Models\location;
use \App\Models\opos_brancheod;
use \App\Models\merchantlocation;
use App\Models\locationterminal;
use App\Models\opos_eoddetails;
use App\Models\Staff;
use App\Models\opos_tablename;
use \App\Models\usersrole;
use \Illuminate\Support\Facades\Auth;
use App\Models\MerchantLink;
use App\Models\Company;
use App\Models\FoodCourt;
use App\Models\FoodCourtMerchant;
use App\Models\terminal;
use App\Models\FoodCourtMerchantTerminal;
use Illuminate\Support\Facades\Schema;
use App\Models\opos_receipt;

class LocationController extends Controller
{
    protected $user_data;

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('CheckRole:loc');
    }

    public function index()
    {
        // $model = new location();
        // $data = $model->latest()->get();

        //$userId = $this->getCompanyUserId();
        //$responderIds = MerchantLink::where('initiator_user_id', $userId)->pluck('responder_user_id')->toArray();
        //$initiatorIds = MerchantLink::where('responder_user_id', $userId)->pluck('initiator_user_id')->toArray();
        //$merchantUserIds = array_merge($responderIds, $initiatorIds);

        //$linkMerchantIds = Company::join('merchant', 'merchant.company_id', '=', 'company.id')->whereIn('company.owner_user_id', $merchantUserIds)->pluck('merchant.id')->toArray();


        $linkMerchantIds = [];

        $this->user_data = new UserData();

        $linkMerchantIds[] = $this->user_data->company_id();

        $relatedFoodCourts = FoodCourt::join('foodcourtmerchant',
			'foodcourtmerchant.foodcourt_id', '=', 'foodcourt.id')->
			where('tenant_merchant_id', $this->user_data->company_id())->
			pluck('foodcourt.location_id')->
			toArray();

        $relatedData = location::select('location.*',
			'merchantlocation.merchant_id')->
			join('merchantlocation', 'merchantlocation.location_id', '=',
			'location.id')->
			whereIn('location.id', $relatedFoodCourts)->latest()->get();

        //$model           = new location();

        $data = location::select('location.*',
			'merchantlocation.merchant_id')->
			join('merchantlocation', 'merchantlocation.location_id', '=',
			'location.id')->
			whereIn('merchantlocation.merchant_id', $linkMerchantIds)->
			latest()->get();

        $relatedData = $relatedData->merge($data);

        $data = location::select('location.*',
			'franchisemerchantloc.franchisemerchant_id')->
			join('franchisemerchantloc', 'franchisemerchantloc.location_id',
			'=', 'location.id')->
			whereIn('franchisemerchantloc.franchisemerchant_id',
			$linkMerchantIds)->latest()->get();
        
        $data = $relatedData->merge($data);
        /*
        $ids  = merchantlocation::whereIn('merchant_id', $linkMerchantIds)->pluck('location_id');
        $data = $model->whereIn('id', $ids)->orderBy('created_at', 'desc')->latest()->get();
        */

        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('loc_id', function ($location) {
                if($location->foodcourt){
                    if ($location->merchant_id == $this->user_data->company_id()) {
                        return '<p data-field="location_id" style="cursor: auto; margin: 0; text-align: center;">' . $location->systemid . '</p>';
                    } else {
                        // show static
                        $merchant = Company::select('company.name', 'company.systemid')
                            ->join('merchant', 'merchant.company_id', '=', 'company.id')
                            ->where('merchant.id', $location->merchant_id)->first();

                        $operatorName = '';
                        $operatorId = '';

                        if ($merchant != null) {
                            $operatorName = $merchant->name;
                            $operatorId = $merchant->systemid;
                        }

                        return '<p class="os-linkcolor loyaltyOutput js-food-court" data-field="foodcourt" data-operator-name="'.$operatorName.'" data-operator-id="'.$operatorId.'" style="cursor: pointer; margin: 0; text-align: center;">'.$location->systemid.'</p>';;
                    }
                } else {
                    return '<p data-field="location_id" style="cursor: auto; margin: 0; text-align: center;">' . $location->systemid . '</p>';
                }

            })
            ->addColumn('branch', function ($location) {
                $branch = empty($location->branch) ? "Branch" : $location->branch;
                if ($location->merchant_id == $this->user_data->company_id()) {
                    return '<p class="os-linkcolor loyaltyOutput" data-field="branch" style="cursor: pointer; margin: 0;" >' . $branch . '</p>';
                } else {
                    return $branch;
                }
            })
            ->addColumn('address', function ($location) {
                $address = empty($location->address_line1) ? "Address" : $location->address_line1;
                if ($location->merchant_id == $this->user_data->company_id()) {
                    return '<p class="os-linkcolor loyaltyOutput" data-field="address" style="cursor: pointer; margin: 0;">' . $address . '</p>';
                } else {
                    return $address;
                }
            })
            ->addColumn('warehouse', function ($location) {
                if ($location->warehouse) {
                    return '<p data-field="warehouse" class="bg-tick" style="margin:0"><i class="fa fa-check" aria-hidden="true"></i></p>';
                } else {
                    return '';
                }

            })
            ->addColumn('foodcourt', function ($location) {
                if($location->foodcourt){

                    $numberofFoodCourt = FoodCourt::join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id', '=', 'foodcourt.id')->where('foodcourt.location_id', $location->id)
                        ->where('foodcourtmerchant.status', 'active')
                        ->get()->count();

                    $numberofFoodCourt++;

                    if ($location->merchant_id == $this->user_data->company_id()) {
                        // show link
                        return '<a href="/foodcourt-tenant/'.$location->systemid.'" style="text-decoration:none" class="btn-link os-linkcolor foodcourt-link" target="_blank">'.$numberofFoodCourt.'</a>';
                    } else {
                        // show static
                        return $numberofFoodCourt;
                    }
                }else{
                    return '';
                }
            })
            ->addColumn('bluecrab', function ($memberList) {
				return '<div data-field="bluecrab"
					data-toggle="modal"
					data-target="#selectOptions"
					id="quickPrompt">
					<img style="width:25px;height:25px;cursor:pointer"
					class="mt=0 mb-0 text-center"
					src="/images/bluecrab_25x25.png"/></div>';
            })
            ->addColumn('deleted', function ($memberList) {
                if ($memberList->merchant_id == $this->user_data->company_id()) {
					return '<div data-field="deleted"
					class="remove">
					<img style="width:25px;height:25px;cursor:pointer"
					class="mt=0 mb-0 text-center"
					src="/images/redcrab_25x25.png"/>';

                } else {
                    return '';
                }

            })
            ->escapeColumns([])
            ->make(true);
    }

    public function foodCourtMerchantTerminal($locationSystemId, $merchantId)
    {
        $id = Auth::user()->id;
        $user_data = new UserData();
        $user_roles = usersrole::where('user_id',$id)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        $is_king = $is_king != null ? true : false;

        $location = location::where('systemid', $locationSystemId)->first();

        return view('location.foodcourt_merchant_terminal',compact('user_roles','is_king', 'location', 'merchantId'));
    }

    public function getCompanyUserId()
    {
        $userData = new UserData();
        $companyId = $userData->company_id();
        $company = Company::find($companyId);
        return $company->owner_user_id;
    }

    public function merchantTransactionExist($merchantId) {
        return merchantlocation::select('merchantlocation.id')
            ->join('opos_locationterminal', 'opos_locationterminal.location_id', '=', 'merchantlocation.location_id')
            ->join('opos_receipt', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->where('merchantlocation.merchant_id', $merchantId)
            ->get()->count() > 0 ? true : false;
    }


    public function foodCourtTenant($locationSystemId)
    {
        $id = Auth::user()->id;
        $user_data = new UserData();
        $merchant_id = $user_data->company_id();
        //$user_data->exit_merchant();
        $user_roles = usersrole::where('user_id',$id)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        $is_king = $is_king != null ? true : false;

        $location = location::where('systemid', $locationSystemId)->first();

        $locationId = $location->id;


        $userId = $this->getCompanyUserId();
        $responderIds = MerchantLink::where('initiator_user_id', $userId)->pluck('responder_user_id')->toArray();
        $initiatorIds = MerchantLink::where('responder_user_id', $userId)->pluck('initiator_user_id')->toArray();
        $merchantUserIds = array_merge($responderIds, $initiatorIds);

        $first = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id')
            ->whereIn('company.owner_user_id', $merchantUserIds);

        $query = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id');

        $query->where('company.owner_user_id', $userId)->union($first);

        $foodCourtTenants = $query->get();

        /*$activeTenants = FoodCourt::
                 join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id','=', 'foodcourt.id')
                ->where('foodcourt.location_id', $location->id)
                ->pluck('tenant_merchant_id')->toArray();


        $haveActiveTenants = count($activeTenants);*/

        $haveActiveTenants = 0;

        foreach ($foodCourtTenants as $key => $foodCourtTenant) {

            $foodCourtTenants[$key]['permanent_status'] = $this->merchantTransactionExist($foodCourtTenant->merchant_id) ? 'active' : 'inactive';

            /*
            $ids  = merchantlocation::join('location','location.id','=',
                'merchantlocation.location_id')->
            where('merchantlocation.merchant_id',$foodCourtTenant->merchant_id)->
            where('merchantlocation.location_id', $locationId)->
            whereNull('location.deleted_at')->
            pluck('merchantlocation.location_id');

            $query = locationterminal::join('opos_terminal',
                'opos_locationterminal.terminal_id','=','opos_terminal.id')->
            whereNull('opos_terminal.deleted_at')->
            whereIn('location_id', $ids)->
            orderby('opos_terminal.created_at', 'asc');
            */

            $foodCourtTenants[$key]['terminal'] = $terminalIds = FoodCourt::
            join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id', '=', 'foodcourt.id')
                ->join('foodcourtmerchantterminal', 'foodcourtmerchantterminal.foodcourtmerchant_id', '=', 'foodcourtmerchant.id')
                ->where('foodcourt.location_id', $locationId)
                ->where('foodcourtmerchant.tenant_merchant_id', $foodCourtTenant->merchant_id)
                ->get()->count();

            /*
            merchantlocation::join('opos_locationterminal', 'opos_locationterminal.location_id', '=', 'merchantlocation.location_id')
            ->where('merchantlocation.merchant_id', $foodCourtTenant->merchant_id)->get()->count();
            */

            $foodCourtTenants[$key]['status'] = 'inactive';

            $tenantStatus = FoodCourt::
                    join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id','=', 'foodcourt.id')
                    ->where('foodcourt.location_id', $location->id)
                    ->where('foodcourtmerchant.tenant_merchant_id',$foodCourtTenant->merchant_id)
                    ->where('foodcourtmerchant.status', 'active')->get()->count();

            if ($tenantStatus > 0) {
                $foodCourtTenants[$key]['status'] = 'active';
                $haveActiveTenants++;
            }
        }

        return view('location.foodcourt_tenant',compact('user_roles',
            'is_king',
            'locationSystemId',
            'location',
            'foodCourtTenants',
            'haveActiveTenants',
            'merchant_id'
        ));
    }

    public function saveFoodcourtTenant(Request $request)
    {
        $userData = new UserData();
        $ownerMerchantId = $userData->company_id();
        $locationId = $request->input('locationId');

        $foodCourt  = FoodCourt::where('location_id', $locationId)->first();
        if ($foodCourt == null) {
            $foodCourt = new FoodCourt();
        }

        $foodCourt->owner_merchant_id = $ownerMerchantId;
        $foodCourt->location_id = $locationId;
        $foodCourt->save();

        $foodCourtId = $foodCourt->id;

        /*
        $foodCourtMerchant = FoodCourtMerchant::where('foodcourt_id', $foodCourtId)->where('tenant_merchant_id', '!=' , $ownerMerchantId)->get();
        foreach($foodCourtMerchant as $fcMerchant) {
           $fcMerchantTerminals = FoodCourtMerchantTerminal::where('foodcourtmerchant_id', $fcMerchant->id)->get();
           foreach($fcMerchantTerminals as $fcMerchantTerminal) {
               terminal::where('id', $fcMerchantTerminal->terminal_id)->delete();
           }
            FoodCourtMerchantTerminal::where('foodcourtmerchant_id', $fcMerchant->id)->delete();
        }

        FoodCourtMerchant::where('foodcourt_id', $foodCourtId)->where('tenant_merchant_id', '!=' , $ownerMerchantId)->delete();
        */

        $activeMerchants = $request->input('activeMerchants');
        foreach ($activeMerchants as $tenant) {

            if ($tenant['merchantId'] == $ownerMerchantId) {
                $status = FoodCourtMerchant::where('foodcourt_id', $foodCourtId)->where('tenant_merchant_id',$ownerMerchantId)->first();
                if ($status != null) {
                    continue;
                }
            }

            $foodCourtMerchant = FoodCourtMerchant::where('foodcourt_id', $foodCourtId)->where('tenant_merchant_id',$tenant['merchantId'])->first();
            if (is_null($foodCourtMerchant)) {
                $foodCourtMerchant = new FoodCourtMerchant();
            }

            $foodCourtMerchant->foodcourt_id = $foodCourtId;
            $foodCourtMerchant->tenant_merchant_id = $tenant['merchantId'];
            $foodCourtMerchant->status = $tenant['status'];
            $foodCourtMerchant->save();
        }

        /*
        foreach($activeMerchants as $merchantId) {
            if ($merchantId == $ownerMerchantId) {
                $status = FoodCourtMerchant::where('foodcourt_id', $foodCourtId)->where('tenant_merchant_id',$ownerMerchantId)->first();
                if ($status != null) {
                    continue;
                }
            }
            $foodCourtMerchant = new FoodCourtMerchant();
            $foodCourtMerchant->foodcourt_id = $foodCourtId;
            $foodCourtMerchant->tenant_merchant_id = $merchantId;
            $foodCourtMerchant->save();
        }
        */

        if ($foodCourtId) {
            return response()->json(['msg' => 'FoodCourt tenant saved successfully']);
        }

    }

    public function saveTenantTerminal(Request $request)
    {
        $merchantId = $request->input('merchantId');
        $locationId = $request->input('locationId');

        $systemid = new SystemID('terminal');

        $terminal = new terminal();
        $link     = new locationterminal();

        $terminal->systemid = $systemid;
        $terminal->btype_id = 1;
        $terminal->save();

        $link->terminal_id = $terminal->id;
        $link->location_id = $locationId;
        $link->save();

        $sq_name = 'receipt_seq_' . sprintf("%06d",$terminal->id);

        \DB::select(\DB::raw("create sequence $sq_name nocache nocycle"));

        $foodCourtMerchant = FoodCourt::select('foodcourtmerchant.id')->
            join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id', '=',
                'foodcourt.id')->
            where('foodcourt.location_id', $locationId)->
            where('foodcourtmerchant.tenant_merchant_id', $merchantId)->
            first();

        if ($foodCourtMerchant != null) {
            $fcMerchantTerminal = new FoodCourtMerchantTerminal();
            $fcMerchantTerminal->foodcourtmerchant_id = $foodCourtMerchant->id;
            $fcMerchantTerminal->terminal_id = $terminal->id;
            $fcMerchantTerminal->save();
        }

        return response()->json([
            'msg' => 'Terminal created successfully.',
            'status' => 'true'
        ]);
    }

    function delTenantTerminal(Request $request) {
        $fcmtId = $request->input('fcmtId');
        $fcmt = FoodCourtMerchantTerminal::find($fcmtId);

        $terminalId = $fcmt->terminal_id;

        $locationterminal = locationterminal::where('terminal_id', $terminalId)->first();
        $locationterminal->delete();

        $terminal = terminal::where('id', $terminalId)->first();
        $terminal->delete();

        $fcmt->delete();

        return response()->json(['msg' => 'Terminal deleted successfully', 'status' => 'true']);

    }

    public function tenantTerminals(Request $request)
    {

        $merchantId = $request->input('merchantId');
        $locationId = $request->input('locationId');

        $model           = new locationterminal();

        $terminalIds = FoodCourt::
            join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id', '=', 'foodcourt.id')
            ->join('foodcourtmerchantterminal', 'foodcourtmerchantterminal.foodcourtmerchant_id', '=', 'foodcourtmerchant.id')
            ->where('foodcourt.location_id', $locationId)
            ->where('foodcourtmerchant.tenant_merchant_id', $merchantId)
            ->pluck('foodcourtmerchantterminal.terminal_id');


        $query = $model->join('opos_terminal',
            'opos_locationterminal.terminal_id','=','opos_terminal.id')->
        whereNull('opos_terminal.deleted_at')->
        whereIn('opos_terminal.id', $terminalIds)->
        orderby('opos_terminal.created_at', 'asc');

        $recordsTotal = $query->get()->count();

        // applying limit
        $data = $query->skip($request->input('start'))->take($request->input('length'))->get();

        $counter = 0 + $request->input('start');

        foreach ($data as $key => $terminal) {
            $data[$key]['indexNumber'] = ++$counter;
            $data[$key]['locationSystemId'] = location::find($terminal->location_id)->systemid;

            $branchName     = location::find($terminal->location_id)->branch;
            $data[$key]['branchName'] = empty($branchName) ? "Branch" : $branchName;

            $terminalData          = terminal::find($terminal->terminal_id);
            $data[$key]['terminalSystemId'] = empty($terminalData->systemid) ? "Terminal ID" : $terminalData->systemid;

            $fcmt = FoodCourt::select('foodcourtmerchantterminal.id')->
            join('foodcourtmerchant', 'foodcourtmerchant.foodcourt_id', '=', 'foodcourt.id')
                ->join('foodcourtmerchantterminal', 'foodcourtmerchantterminal.foodcourtmerchant_id', '=', 'foodcourtmerchant.id')
                ->where('foodcourt.location_id', $locationId)
                ->where('foodcourtmerchant.tenant_merchant_id', $merchantId)
                ->where('foodcourtmerchantterminal.terminal_id', $terminal->terminal_id)
                ->first();

            $data[$key]['fcmt_id'] = $fcmt->id;

            $data[$key]['deleteStatus'] = opos_receipt::where('terminal_id', $terminal->terminal_id)->get()->count() > 0 ? 'inactive' : 'active';
        }

        $response = [
            'data' => $data,
            'recordsTotal' => $recordsTotal,
            'recordsFiltered' => $recordsTotal
        ];
        return response()->json($response);
    }

    public function edit($id)
    {
        //
    }

    public function store(Request $request)
    {
        //Create a new product here
        try {

            $this->user_data  = new UserData();
            $merchantlocation = new merchantlocation();
            $SystemID         = new SystemID('location');
            $location         = new location();

            $location->systemid = $SystemID;

            if ($request->has('warehouse')) {
                if ($request->warehouse == 'yes') {
                    $location->warehouse = true;
                }
            }
            if ($request->has('foodcourt')) {
                if ($request->foodcourt == 'yes') {
                    $location->foodcourt = true;
                }
            }

            $location->save();

            //tablename
            $this->new_tablename($location->id);

            $sq_name = 'takeaway_seq_' . sprintf("%06d",$location->id);
            \DB::select(\DB::raw("create sequence $sq_name nocache nocycle"));

            $merchantlocation->location_id = $location->id;
            $merchantlocation->merchant_id = $this->user_data->company_id();
            $merchantlocation->save();

            $msg = "Location added successfully";

        } catch (\Illuminate\Database\QueryException $e) {
            $msg = "Error occured occured while storing location in database";

            Log::error("Error @ " . $e->getLine() . " file " . $e->getFile() . " " .
                $e->getMessage());
        }
        return view('layouts.dialog', compact('msg'));
    }

    public function showEditModal(Request $request)
    {
        try {
            $this->user_data = new UserData();
            $allInputs       = $request->all();
            $id              = $request->get('id');
            $fieldName       = $request->get('field_name');

            $is_exist = merchantlocation::where(
                ['location_id' => $id, 'merchant_id' => $this->user_data->company_id()])->first();

            if (!$is_exist) {
                throw new Exception("Location not found", 1);
            }

            $location = location::find($id);

            if (!$location) {
                throw new Exception("Location not found", 1);
            }

            $validation = Validator::make($allInputs, [
                'id'         => 'required',
                'field_name' => 'required',
            ]);

            if ($validation->fails()) {
                throw new Exception("Invalid validation", 1);
            }

            if ($request->field_name == 'branch') {
                $model = 'branch';
            } else if ($request->field_name == 'address') {
                $model = 'address';
            } elseif ($request->field_name == 'deleted') {
                $model = "deleted";
            } else {
                return '';
            }

            return view('location.edit-model', compact('location', 'model'));

        } catch (\Illuminate\Database\QueryException $e) {
            $msg = "Some error occured";
            log::debug($e);
            return view('layouts.dialog', compact('msg'));
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    public function update(Request $request)
    {
        try {
            $this->user_data = new UserData();
            $location_id     = $request->location_id;

            $is_exist = merchantlocation::where(
                ['location_id' => $location_id, 'merchant_id' => $this->user_data->company_id()])->first();

            if (!$is_exist) {
                throw new Exception("Location not found", 1);
            }

            $location = location::find($location_id);

            if (!$location) {
                throw new Exception("Location not found", 1);

            }

            $changed = false;

            if ($request->has('branch')) {
                if ($location->branch != $request->branch) {
                    $location->branch = $request->branch;
                    $changed = true;
                }
            }

            if ($request->has('address')) {
                if ($location->address_line1 != $request->address) {
                    $location->address_line1 = $request->address;
                    $changed           = true;
                }
            }

			$purple = false;
            if ($request->has('e_table_header_color')) {
                if ($location->e_table_header_color != $request->e_table_header_color) {
                    $location->e_table_header_color = $request->e_table_header_color;
                    $changed = true;
					$purple = true;
					$msg = "Screen E Details updated";
                }
            }

            if ($request->has('e_bottom_panel_color')) {
                if ($location->e_bottom_panel_color != $request->e_bottom_panel_color) {
                    $location->e_bottom_panel_color = $request->e_bottom_panel_color;
                    $changed = true;
					$purple = true;
					$msg = "Screen E Details updated";
                }
            }

            if ($request->has('e_right_panel_color')) {
                if ($location->e_right_panel_color != $request->e_right_panel_color) {
                    $location->e_right_panel_color = $request->e_right_panel_color;
                    $changed = true;
					$purple = true;
					$msg = "Screen E Details updated";
                }
            }

            if ($changed == true) {
                $location->save();

				Log::debug('OUTSIDE  purple='.$purple);

				if ($purple) {
					// Note that this is not being used at the blade as
					// the blade is popping up another modal
					Log::debug('INSIDE  purple='.$purple);
					return view('layouts.purpledialog', compact('msg'));


				} else {
					$msg = "Data updated";
					return view('layouts.dialog', compact('msg'));
				}
            } else {
                return '';
            }

        } catch (\Exception $e) {
            $msg = "Some error occured";
            log::error($e);
            return view('layouts.dialog', compact('msg'));
        }
    }

    public function destroy($id)
    {
        try {
            $this->user_data = new UserData();
            $location        = location::find($id);

            $is_exist = merchantlocation::where(
                ['location_id' => $id, 'merchant_id' => $this->user_data->company_id()])->first();

            if (!$is_exist) {
                throw new Exception("Location not found", 1);
            }

            if (!$location) {
                throw new Exception("Location not found", 1);
            }

            //delete tablename
            $tablenames = opos_tablename::where('location_id', $location->id)->get();
            foreach ($tablenames as $tablename) {
                $tablename->delete();
            }

            $sq_name = 'takeaway_seq_' . sprintf("%06d",$location->id);
            \DB::select(\DB::raw("drop sequence $sq_name"));

            $location->delete();

            $msg = "Location deleted successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = "Some error occured";
            log::error($e);
            return view('layouts.dialog', compact('msg'));
        }
    }

    public function showInventoryView()
    {
        return view('inventory.inventory');
    }

    public function showInventoryQtyView()
    {
        return view('inventory.inventoryqty');
    }


    public function getTerminalTime(Request $request)
    {
        if ($request->ajax()) {
            # code...
            try{

                $rowId = $request->rowId;

                // validate row id
                $validateId = Location::find($rowId);

                if($validateId){

                    // get location teminal time
                    $location = location::where('id', $rowId)->first();
                    $starttime = $location->start_work;
                    $endtime = $location->close_work;

                    return response()->json(['status' => 202, 'starttime' => $starttime, 'endtime' => $endtime]);
                }

            }catch(\Exception $e){
                Log::error(
                    "Error @ " . $e->getLine() . " file " . $e->getFile() . ":" . $e->getMessage()
                );
            }
        }
    }

    public function updateTerminalTime(Request $request)
    {
        if ($request->ajax()) {
            # code...
            try{

                $rowId = $request->rowId;
                $starttime = $request->starttime;
                $endtime = $request->endtime;
                $staff_id = $request->staff_id;
                $staff = Staff::where('systemid', $staff_id)->first();
                $user_id = $staff->user_id;

                // validate row id
                $validateId = Location::find($rowId);

                if($validateId){

                    // update location teminal time
                    $location = Location::find($rowId);
                    $location->start_work = $starttime;
                    $location->close_work = $endtime;
                    $location_id = $location->id;
                    $location->update();

                    //locks the terminal if time is reset
                    $opos_brancheod = new opos_brancheod();
                    $opos_brancheod->eod_presser_user_id = $user_id;
                    $opos_brancheod->location_id = $location_id;
                    $opos_brancheod->save();

                    //update id in eoddetails
                    $ids = locationterminal::where('location_id', $location->id)->pluck('terminal_id');
                    foreach ($ids as $id) {
                        $eod_details = opos_eoddetails::where('logterminal_id', $id)->latest('created_at')->first();
                        if ($eod_details) {
                            $eod_details->eod_id = $opos_brancheod->id;
                            $eod_details->update();
                        }
                    }


                    return response()->json(['status' => 202, 'message' => 'Terminal operation hour updated successfully.']);
                }else{
                    return response()->json(['status' => 404, 'message' =>  'Sorry, failed to update record.']);
                }
            }catch(\Exception $ex){
                Log::error(
                    "Error @ " . $ex->getLine() . " file " . $ex->getFile() . ":" . $ex->getMessage()
                );
                return response()->json(['status' => 404, 'message' =>  'Sorry, failed to update record.']);
            }
        }
    }

    public function new_tablename($location_id) {
        $tableName1 = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100','101','102','103','104','105','106','107','108','109','110','111','112','113','114','115','116','117','118','119','120','121','122','123','124','125','126','127','128','129','130','131','132','133','134','135','136','137','138','139','140','141','142','143','144','145','146','147','148','149','150','151','152','153','154','155','156','157','158','159','160','161','162','163','164','165','166','167','168','169','170','171','172','173','174','175','176','177','178','179','180','181','182','183','184','185','186','187','188','189','190','191','192','193','194','195','196','197','198','199','200');
        foreach ($tableName1 as $t) {
            $tn = new opos_tablename();
            $tn->location_id = $location_id;
            $tn->default_name = $t;
            $tn->save();
        }

    }

    public function getBranchLocationByLoggedInUser(){
        $id = $this->getCompanyUserId();

        Log::debug('id='.$id);

        $branchLocationObj = new location();
        $rs = $branchLocationObj->getBranchLocationByLoggedInUserId($id);
        $rs_loc = [];
        if($rs != null){
            $rs_loc = response()->json($rs);
        }
        // dd($rs_loc);
        return $rs_loc;
    }

    public function saveLocationImage(Request $request)
    {

        try {
            $validation = Validator::make($request->all(), [
                'location_id' => 'required',
            ]);

            if ($validation->fails()) {
                throw new \Exception("validation_error", 19);
            }

            $location = location::where('id', $request->location_id)->first();

            if (!$location) {
                throw new \Exception('location_not_found', 25);
            }

            if ($request->hasfile('file')) {
                $file = $request->file('file');
                $extension = $file->getClientOriginalExtension(); // getting image extension
                $company_id = Auth::user()->staff->company_id;

                if (!in_array($extension, array(
                    'jpg', 'JPG', 'png', 'PNG', 'jpeg', 'JPEG', 'gif', 'GIF', 'bmp', 'BMP', 'tiff', 'TIFF'))) {
                    return abort(403);
                }

                $filename = ('p' . sprintf("%010d", $location->id)) . '-m' . sprintf("%010d", $company_id) . rand(1000, 9999) . '.' . $extension;

                $location_id = $location->id;

                $this->check_location("/images/location/$location_id/");
                $file->move(public_path() . ("/images/location/$location_id/"), $filename);

                $location->e_right_panel_image_file = $filename;
                $location->save();

                $return_arr = array("name" => $filename, "size" => 000, "src" => "/images/location/$location_id/$filename");
                return response()->json($return_arr);
            } else {
                return abort(403);
            }

        } catch (\Exception $e) {

            if ($e->getMessage() == 'validation_error') {
                return '';
            }
            if ($e->getMessage() == 'location_not_found') {
                $msg = "Error occured while uploading, Invalid location selected";
            }
            {
                $msg = "Error occured while uploading picture";
            }

            Log::error(
                "Error @ " . $e->getLine() . " file " . $e->getFile() .
                ":" . $e->getMessage()
            );

            $data = view('layouts.dialog', compact('msg'));
        }
        return $data;
    }

    public function deleteLocationImage(Request $request)
    {

        try {
            $validation = Validator::make($request->all(), [
                'location_id' => 'required',
            ]);

            if ($validation->fails()) {
                throw new \Exception("validation_error", 19);
            }

            $location = location::where('id', $request->location_id)->first();

            if (!$location) {
                throw new \Exception('location_not_found', 25);
            }
            unlink(public_path() . ("/images/location/$location->id/$location->e_right_panel_image_file"));
            $location->e_right_panel_image_file = null;
            $location->save();
            $return = response()->json(array("deleted" => "True"));

        } catch (\Exception $e) {
            $return = response()->json(array("deleted" => "False"));
        }

        return $return;

    }


    public function check_location($location)
    {
        $location = array_filter(explode('/', $location));
        $path = public_path();

        foreach ($location as $key) {
            $path .= "/$key";

            Log::debug('check_location(): $path='.$path);

            if (is_dir($path) != true) {
                mkdir($path, 0775, true);
            }
        }
    }
}
