<?php

namespace App\Http\Controllers;

use App\Models\opos_locationterminal;
use App\Models\opos_receiptdetails;
use Log;
use Illuminate\Http\Request;
use \App\Models\usersrole;
use \App\Models\role;
use \Illuminate\Support\Facades\Auth;
use App\Models\merchantlocation;
use App\Models\location;
use App\Classes\UserData;

use \App\Classes\SystemID;
use \App\Models\locationterminal;
use Yajra\DataTables\DataTables;


use \App\Models\membership;

use \App\Models\merchantproduct;
use \App\Models\prd_inventory;
use \App\Models\product;
use \App\Models\restaurant;
use \App\Models\terminal;

use \App\Models\voucher;
use \App\Models\warranty;

use App\Models\Company;
use App\Http\Controllers\OposComponentController;
use App\Models\prdcategory;
use App\Models\prd_subcategory;
use \App\Models\prd_special;
use \App\Models\productspecial;
use \App\Models\opos_btype;
use \App\Models\opos_terminalproduct;
use \App\Models\opos_eoddetails;

use \App\Models\opos_receiptproduct;
use \App\Models\opos_itemdetails;
use \App\Models\opos_receipt;
use \App\Models\Merchant;
use DB;
use Mpdf\Mpdf;


class AnalyticsController extends Controller
{

	function showCashProductSalesView(Request $request) {
		
		Log::debug('***** showCashProductSales() *****');
		
		$id = Auth::user()->id;
		$logged_in_user_id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];


		$each_Product_amount = DB::select(
			'SELECT SUM(opos_itemdetails.amount) AS T_amount,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_itemdetails,opos_receiptproduct,product,merchantproduct,company
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id]
		);

		
		//date range filter
		$dateTimeFrom = $request->from_date_all .' 00:00:00';
		$dateTimeTo = $request->to_date_all .' 23:59:59';
		
		$each_amount_date_range = DB::select(
			'SELECT SUM(opos_itemdetails.amount) AS T_amount,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_itemdetails,opos_receiptproduct,product,merchantproduct,company
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
                AND opos_receiptproduct.created_at BETWEEN  :froms AND :to
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'froms'=>$dateTimeFrom,'to'=>$dateTimeTo]
		);

		// return response()->json($each_amount_date_range);

		if($each_amount_date_range != null){
			return response()->json($each_amount_date_range);
		}

		//branch location
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');


		//location all_branch
		$branch_detail = DB::select(
			'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_amount) DESC;',['loc_id'=>$request->branch_id]
		);
		
		if($branch_detail != null){
			return response()->json($branch_detail);
		}

		//custome daterange_location all_branch
		
		$daterange_branch_detail = DB::select(
			'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN  :froms AND :to
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'froms'=>$request->from_date,'to'=>$request->to_date]
		);

		if($daterange_branch_detail != null){
			return response()->json($daterange_branch_detail);
		}

		//check approved merchat 
		 // if merchant not approved then will be disable all date rage
		$approved_merchant = DB::select('SELECT created_at FROM `company` WHERE `owner_user_id` =:id AND created_at IS NOT NULL;',['id'=>$logged_in_user_id]
		    );
		//User Approved Date
		$userApprovedDate = null;
		
		// DB::select('
		// 	SELECT
		// 		c.approved_at
		// 	FROM
		// 		company c
		// 	WHERE
		// 		c.owner_user_id = '.$id.'
		// ');
		// $userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.cash_productsales', compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'each_Product_amount', 
			'branch_location',
			'approved_merchant',
			'userApprovedDate'
		));
	}

	public function showCashProductSalesViewDownloadPDF(Request $request)
	{
			
		Log::debug('***** showCashProductSales() *****');
		
		$id = Auth::user()->id;
		$logged_in_user_id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];


		$each_Product_amount = DB::select(
			'SELECT SUM(opos_itemdetails.amount) AS T_amount,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_itemdetails,opos_receiptproduct,product,merchantproduct,company
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id]
		);

		
		//date range filter
		$dateTimeFrom = $request->from_date_all .' 00:00:00';
		$dateTimeTo = $request->to_date_all .' 23:59:59';
		
		$each_amount_date_range = DB::select(
			'SELECT SUM(opos_itemdetails.amount) AS T_amount,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_itemdetails,opos_receiptproduct,product,merchantproduct,company
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
                AND opos_receiptproduct.created_at BETWEEN  :froms AND :to
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'froms'=>$dateTimeFrom,'to'=>$dateTimeTo]
		);

		// return response()->json($each_amount_date_range);

		if($each_amount_date_range != null){
			return response()->json($each_amount_date_range);
		}

		//branch location
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');


		//location all_branch
		$branch_detail = DB::select(
			'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_amount) DESC;',['loc_id'=>$request->branch_id]
		);
		
		if($branch_detail != null){
			return response()->json($branch_detail);
		}

		//custome daterange_location all_branch
		
		$daterange_branch_detail = DB::select(
			'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN  :froms AND :to
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'froms'=>$request->from_date,'to'=>$request->to_date]
		);

		if($daterange_branch_detail != null){
			return response()->json($daterange_branch_detail);
		}

		//check approved merchat 
		 // if merchant not approved then will be disable all date rage
		$approved_merchant = DB::select('SELECT created_at FROM `company` WHERE `owner_user_id` =:id AND created_at IS NOT NULL;',['id'=>$logged_in_user_id]
		    );
		//User Approved Date
		$userApprovedDate = null;
		
		// DB::select('
		// 	SELECT
		// 		c.approved_at
		// 	FROM
		// 		company c
		// 	WHERE
		// 		c.owner_user_id = '.$id.'
		// ');
		// $userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');

		$view =  view('analytics.cash_productsales_pdf', compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'each_Product_amount', 
			'branch_location',
			'approved_merchant',
			'userApprovedDate'
		))->render();

		$pdf = \App::make('dompdf.wrapper');

		$pdf->loadHTML($view);
		
		return$pdf->stream();
	}

	function showCashProductSalesQtyView(Request $request) {
		Log::debug('***** showCashProductSales() *****');
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		$logged_in_user_id = Auth::user()->id;
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];


		$each_product_quantity = DB::select(
		'SELECT SUM(opos_receiptproduct.quantity) AS T_quantity,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_receiptproduct,product,merchantproduct,company
			WHERE
				
			    product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id]
		);


		//date range quantity
		$dateTimeFrom = $request->from_date_all .' 00:00:00';
		$dateTimeTo = $request->to_date_all .' 23:59:59';

		$date_rage_product_quantity = DB::select(
		'SELECT SUM(opos_receiptproduct.quantity) AS T_quantity,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_receiptproduct,product,merchantproduct,company
			WHERE
				
			    product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			    AND opos_receiptproduct.created_at BETWEEN :froms AND :to							   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'froms'=>$dateTimeFrom,'to'=>$dateTimeTo]
		);

		if($date_rage_product_quantity != null){
			return response()->json($date_rage_product_quantity);
		}

		//branch loction
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');


		//all location quantity
		
		$location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['loc_id'=>$request->location_id]
		);

		if($location_product_quantity != null){
			return response()->json($location_product_quantity);
		}


		//all location quantity
		
		$location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->location_id]
		);

		if($location_product_quantity != null){
			return response()->json($location_product_quantity);
		}


		//indiviual location quantity
		
		$each_location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN  :froms AND :to
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->loc_id,'froms'=>$request->from_date,'to'=>$request->to_date]
		);

		if($each_location_product_quantity != null){
			return response()->json($each_location_product_quantity);
		}

        //check approved merchat 
        // if merchant not approved then will be disable all date rage
		$approved_merchant = DB::select('SELECT created_at FROM `company` WHERE `owner_user_id` =:id AND created_at IS NOT NULL;',['id'=>$logged_in_user_id]
		    );
		$userApprovedDate = null;
		
		// DB::select('
		// 	SELECT
		// 		c.approved_at
		// 	FROM
		// 		company c
		// 	WHERE
		// 		c.owner_user_id = '.$id.'
		// ');
		// $userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.cash_productsales_by_qty', compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'each_product_quantity',
			'branch_location',
			'approved_merchant',
			'userApprovedDate'
		));
	}


	function showCashCashierSalesView(Request $request) {
 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		$logged_in_user_id = Auth::user()->id;
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        $is_approved = false;
        $approved_at = false;
        $is_enable = false;

        if ($id == 1) {
            $is_enable = true;
        }

        if ($is_king != null) {
            if ($is_king->approved_at != null) {
                $is_approved = true;
                $approved_at = $is_king->approved_at;
            }

            $is_king = true;

        } else {
            $is_king  = false;
        }
		$since = \Carbon\Carbon::now();
		$locations = [];


		// staff location

		$each_staff_total = DB::select(
			'SELECT 
				SUM(opos_receiptdetails.item_amount) AS each_total,
				opos_receipt.staff_user_id,
				users.name 
			FROM 
    			opos_receiptdetails, 
    			opos_receipt,
    			users
			WHERE 
    			opos_receipt.id=opos_receiptdetails.receipt_id
    		AND users.id=opos_receipt.staff_user_id
    		AND users.id=:id
			GROUP BY 
				opos_receipt.staff_user_id 
			ORDER BY 
				each_total DESC;',['id'=>$logged_in_user_id]
			);


		//since
		$date_range_staff_total = DB::select(
			'SELECT 
				SUM(opos_receiptdetails.item_amount) AS each_total,
				opos_receipt.staff_user_id,
				users.name, 
				users.id 

			FROM 
    			opos_receiptdetails, 
    			opos_receipt,
    			users
			WHERE 
    			opos_receipt.id=opos_receiptdetails.receipt_id
    		AND users.id=opos_receipt.staff_user_id
    		AND users.id=:id
    		AND opos_receiptdetails.created_at BETWEEN :froms AND :to
			GROUP BY 
				opos_receipt.staff_user_id 
			ORDER BY 
				each_total DESC;',['id'=>$logged_in_user_id,'froms'=>$request->from_date_all,'to'=>$request->to_date_all]
			);


		if($date_range_staff_total != null){
			return response()->json($date_range_staff_total);
		}


		//branch loction
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');


		$each_location_staff_total = DB::select(
			'SELECT 
				SUM(opos_receiptdetails.item_amount) AS each_total,
				opos_receipt.staff_user_id,
				users.name 
			FROM 
    			opos_receiptdetails, 
    			opos_receipt,
    			users,
				location,
                opos_locationterminal
			WHERE 
    			opos_receipt.id=opos_receiptdetails.receipt_id
    		AND users.id=opos_receipt.staff_user_id
			AND	location.id=:loc_id
			AND location.id = opos_locationterminal.location_id
			AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
			AND opos_receipt.id = opos_receiptdetails.receipt_id
			GROUP BY 
				opos_receipt.staff_user_id 
			ORDER BY 
				each_total DESC;',['loc_id'=>$request->branch_id]
		);

		if($each_location_staff_total != null){
			return response()->json($each_location_staff_total);
		}

		//date range staff location
		
		$date_range_location_staff_total = DB::select(
			'SELECT 
				SUM(opos_receiptdetails.item_amount) AS each_total,
				opos_receipt.staff_user_id,
				users.name 
			FROM 
    			opos_receiptdetails, 
    			opos_receipt,
    			users,
				location,
                opos_locationterminal
			WHERE 
    			opos_receipt.id=opos_receiptdetails.receipt_id
    		AND users.id=opos_receipt.staff_user_id
    		AND users.id=:id
			AND	location.id=:loc_id
			AND location.id = opos_locationterminal.location_id
			AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
			AND opos_receipt.id = opos_receiptdetails.receipt_id
			AND opos_receiptdetails.created_at BETWEEN :froms AND :to
			GROUP BY 
				opos_receipt.staff_user_id 
			ORDER BY 
				each_total DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->loc_id,'froms'=>$request->from_date,'to'=>$request->to_date]
		);

		if($date_range_location_staff_total != null){
			return response()->json($date_range_location_staff_total);
		}

		
		//User Approved Date
		$userApprovedDate = null; 
		// DB::select('
		// 	SELECT
		// 		c.approved_at
		// 	FROM
		// 		company c
		// 	WHERE
		// 		c.owner_user_id = '.$id.'
		// ');
		// $userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.cash_cashiersales',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'each_staff_total',
			'branch_location',
            'is_approved',
            'approved_at',
            'is_enable',
			'userApprovedDate'
			

		)); 
	}


	function showCashStaffSalesView() {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];
		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.cash_staffsales',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'userApprovedDate'
		)); 
	}


	function showCashBranchSalesView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		$logged_in_user_id = Auth::user()->id;

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];


		$each_location_total1 = DB::select('
			SELECT			
				SUM(opos_itemdetails.amount) AS T_amount,
				location.branch,
				location.id,
				company.name
			FROM
				company,
				merchant,
				location,
				merchantlocation,		-- location_id_idx
                opos_receipt,
                opos_locationterminal,	-- terminal_id_idx
                opos_itemdetails,
                merchantproduct,
				opos_receiptproduct
			WHERE
				company.owner_user_id = :id 
                AND	opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND merchant.company_id = company.id
				AND merchantlocation.merchant_id = merchant.id
				AND merchantlocation.location_id = location.id
                AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
                AND merchant.id=merchantproduct.merchant_id
				AND location.branch is NOT NULL
				AND location.deleted_at is NULL
         GROUP BY
         	location.branch
      	 ORDER BY 
       		T_amount DESC;',['id'=>$logged_in_user_id]
       	);

       	$each_location_total2 = DB::select('
			SELECT			
				location.branch,
				location.id,
				company.name
			FROM
				company,
				merchant,
				location,
				merchantlocation
			WHERE
				company.owner_user_id = :id 
				AND merchant.company_id = company.id
				AND merchantlocation.merchant_id = merchant.id
				AND merchantlocation.location_id = location.id
				AND location.branch is NOT NULL
				AND location.deleted_at is NULL
         GROUP BY
         	location.branch;',['id'=>$logged_in_user_id]
       	);

		$index = count($each_location_total1);
       	foreach ($each_location_total2 as $key2 => $value2) {
       		foreach ($each_location_total1 as $key => $value) {
       			if($value2->branch == $value->branch) {
       				unset($each_location_total2[$key2]);
       				break;
       			} else {
       				$each_location_total2[$key2]->T_amount = 0;
       			}
       		}
       	}

       	$each_location_total = array_merge($each_location_total1, $each_location_total2);
       	
       	// date range branch sales
       
       	$date_range_branch = DB::select(
       			'SELECT			
				SUM(opos_itemdetails.amount) AS T_amount,
				location.branch,
				location.id,
				company.name
			FROM
				company,
				merchant,
				location,
				merchantlocation,
                opos_receipt,
                opos_locationterminal,
                opos_itemdetails,
                merchantproduct,
				opos_receiptproduct
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND merchant.company_id = company.id
				AND merchantlocation.merchant_id = merchant.id
				AND merchantlocation.location_id = location.id
                AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
                AND company.id=merchantproduct.merchant_id
				AND location.branch is NOT NULL
				AND location.deleted_at is NULL
                AND opos_itemdetails.created_at BETWEEN :froms AND  :to
         GROUP BY
         	location.branch
      	 ORDER BY 
       		T_amount DESC;',['froms'=>$request->from_date_all,'to'=>$request->to_date_all]
       );

       if($date_range_branch != null){
			return response()->json($date_range_branch);
		}
	
		//User Approved Date
		$userApprovedDate = null;

        return view('analytics.cash_branchsales',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',   
			'each_location_total',
			'userApprovedDate'
		
		)); 
	}




	function showCashPaymentModeView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }
        $locationId = -1;
        if(!empty($request->type)){
            if($request->type == 'location'){
                $locationId = $request->locationId;
            }
        }
		$since = \Carbon\Carbon::now();
		$locations = [];

        $receipt_records['cash_total'] = 0;
        $receipt_records['credit_total'] = 0;
        $receipt_records['grand_total'] = 0;
        if($locationId != -1){
            $terminalId = opos_locationterminal::where('location_id', $locationId)->first()['terminal_id'];
            $receipts = opos_receipt::where('terminal_id', $terminalId)->get();
            foreach ($receipts as $receipt){
                $receipt_details = opos_receiptdetails::where('receipt_id', $receipt->id)->get();
                foreach ($receipt_details as $receipt_detail){
                    $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                    $receipt_records['cash_total'] += $receipt_detail->cash;
                    $receipt_records['credit_total'] += $receipt_detail->creditcard;
                    $receipt_records['grand_total'] += $receipt_detail->total;
                }
            }
        }else{
            $receipt_details = opos_receiptdetails::all();
            foreach ($receipt_details as $receipt_detail){
                $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                $receipt_records['cash_total'] += $receipt_detail->cash;
                $receipt_records['credit_total'] += $receipt_detail->creditcard;
                $receipt_records['grand_total'] += $receipt_detail->total;
            }
        }
//		return $receipt_records;
        $each_payment = DB::select(
			'SELECT
   				SUM(opos_receiptdetails.item_amount) AS cash_total,
    			(SELECT 
    				SUM(opos_receiptdetails.item_amount)  
    			FROM 
    				opos_receiptdetails 
    			where  
    				opos_receiptdetails.cash_received IS null ) AS cradit_total
			FROM 
				opos_receiptdetails
			WHERE 
				opos_receiptdetails.cash_received IS NOT null'
		);

        // p: payment mode
        $branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');
		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
        $receipt_records['cash_percentage'] = 0;
        $receipt_records['credit_percentage'] = 0;
        if($receipt_records['cash_total'] > $receipt_records['credit_total']){
            $receipt_records['cash_percentage'] = 100 -15;
            $receipt_records['credit_percentage'] = ($receipt_records['credit_total'] * 100) / $receipt_records['cash_total'] - 15;
        }
        else if($receipt_records['cash_total'] < $receipt_records['credit_total']){
            $receipt_records['credit_percentage'] = 100 - 15;
            $receipt_records['cash_percentage'] = ($receipt_records['cash_total'] * 100) / $receipt_records['credit_total'] - 15;
        }
        $receipt_records['cash_total'] = number_format(($receipt_records['cash_total'] / 100), 2);
        $receipt_records['credit_total'] = number_format(($receipt_records['credit_total'] / 100),2);
        if($receipt_records['cash_percentage'] >= 100){
            $receipt_records['cash_percentage'] = 100;
        }else if($receipt_records['cash_percentage'] <= 0){
            $receipt_records['cash_percentage'] = 5;
        }
        if($receipt_records['credit_percentage'] >= 100){
            $receipt_records['credit_percentage'] = 100;
        }else if($receipt_records['credit_percentage'] <= 0){
            $receipt_records['credit_percentage'] = 5;
        }
        $userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.cash_payment_mode',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',  
			'each_payment',
            'branch_location',
			'userApprovedDate',
             'receipt_records'

		)); 
	}


	function showCashPaymentModeFiltered(Request $request){
        $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
            Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }
        $locationId = -1;
        $from = 'all';
        $to = 'all';
        if(!empty($request->type)){
            if($request->type == 'location'){
                $locationId = $request->locationId;
            }
            if($request->type == 'date'){
                $from = $request->from;
                $to = $request->to;
            }
        }
        $since = \Carbon\Carbon::now();
        $locations = [];

        $receipt_records['cash_total'] = 0;
        $receipt_records['credit_total'] = 0;
        $receipt_records['grand_total'] = 0;
        if($locationId != -1){
            $terminalId = opos_locationterminal::where('location_id', $locationId)->first()['terminal_id'];
            $receipts = opos_receipt::where('terminal_id', $terminalId)->get();
            foreach ($receipts as $receipt){
                $receipt_details = opos_receiptdetails::where('receipt_id', $receipt->id)->get();
                foreach ($receipt_details as $receipt_detail){
                    $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                    $receipt_records['cash_total'] += $receipt_detail->cash;
                    $receipt_records['credit_total'] += $receipt_detail->creditcard;
                    $receipt_records['grand_total'] += $receipt_detail->total;
                }
            }
        }
        else if($from != 'all' && $to != 'all'){
                $receipt_details = opos_receiptdetails::all()->whereBetween('created_at', [$from, $to]);
                foreach ($receipt_details as $receipt_detail){
                    $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                    $receipt_records['cash_total'] += $receipt_detail->cash;
                    $receipt_records['credit_total'] += $receipt_detail->creditcard;
                    $receipt_records['grand_total'] += $receipt_detail->total;
                }
        }

        if($from == 'all' && $to == 'all' && $locationId == -1 && $request->type == "all"){
            $receipt_details = opos_receiptdetails::all();
            //sum up credit here
            foreach ($receipt_details as $receipt_detail){
                $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                $receipt_records['cash_total'] += $receipt_detail->cash;
                $receipt_records['credit_total'] += $receipt_detail->creditcard;
                $receipt_records['grand_total'] += $receipt_detail->total;
            }
        }
        else if($from == 'all' && $to == 'all' && $locationId == -1 && $request->type == "cash"){
            $receipt_details = opos_receiptdetails::all();
            foreach ($receipt_details as $receipt_detail){
                $receipt_detail->cash = $receipt_detail->cash_received - $receipt_detail->change;
                $receipt_records['cash_total'] += $receipt_detail->cash;
                $receipt_records['credit_total'] += $receipt_detail->creditcard;
                $receipt_records['grand_total'] += $receipt_detail->total;
            }
        }

        $receipt_records['cash_percentage'] = 0;
        $receipt_records['credit_percentage'] = 0;
        if($receipt_records['cash_total'] > $receipt_records['credit_total']){
            $receipt_records['cash_percentage'] = 100 -15;
            $receipt_records['credit_percentage'] = ($receipt_records['credit_total'] * 100) / $receipt_records['cash_total'] - 15;
        }
        else if($receipt_records['cash_total'] < $receipt_records['credit_total']){
            $receipt_records['credit_percentage'] = 100 - 15;
            $receipt_records['cash_percentage'] = ($receipt_records['cash_total'] * 100) / $receipt_records['credit_total'] - 15;
        }
        $receipt_records['cash_total'] = number_format(($receipt_records['cash_total'] / 100),2);
        $receipt_records['credit_total'] = number_format(($receipt_records['credit_total'] / 100),2);
        if($receipt_records['cash_percentage'] >= 100){
            $receipt_records['cash_percentage'] = 100;
        }else if($receipt_records['cash_percentage'] <= 0){
            $receipt_records['cash_percentage'] = 5;
        }
        if($receipt_records['credit_percentage'] >= 100){
            $receipt_records['credit_percentage'] = 100;
        }else if($receipt_records['credit_percentage'] <= 0){
            $receipt_records['credit_percentage'] = 5;
        }
        return json_encode($receipt_records);
    }

	function showCashHourlySalesView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();


        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();

		if (isset($request->filterByDate)){
			$date = $request->filterByDate;
		}
		else {
			$date = date('Y-m-d');
		}

		if (isset($request->locationId)){
			$where_location = ' AND  opos_locationterminal.location_id = '. $request->locationId;
		}
		else {
			$where_location = '';
		}	

		$from_date = $date . ' 00:00:00';
		$to_date = $date . ' 23:59:59';

		$filter_data = DB::select(
			"SELECT 
				HOUR(opos_itemdetails.created_at) AS FromHour,
				(SUM(opos_itemdetails.amount)/100) AS total,
				count(opos_itemdetails.id) AS count
			FROM 
				opos_itemdetails
			LEFT JOIN  
				opos_receiptproduct  ON ( opos_itemdetails.receiptproduct_id = opos_receiptproduct.id) 
			LEFT JOIN 
				opos_receipt ON (opos_receiptproduct.receipt_id = opos_receipt.id )
			LEFT JOIN 
				opos_terminal ON (opos_receipt.terminal_id = opos_terminal.id )
			LEFT JOIN 
				opos_locationterminal ON (opos_terminal.id = opos_locationterminal.terminal_id )
			WHERE 
				opos_itemdetails.created_at BETWEEN :froms AND :to
			$where_location
			GROUP BY
				HOUR(opos_itemdetails.created_at)",['froms'=>$from_date,'to'=>$to_date]
		);

		$ar = array();
		$hour = array_pad($ar,24,0);
	
		foreach ($hour as $keyh => $valueh) {
			foreach ($filter_data as $keya => $valuea) {
				if($keyh == $valuea->FromHour){
					$hour[$keyh]= $valuea->total;
				}
			}
		}

		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');

		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');

		if (isset($request->filterByParams)){ 
			return response()->json($hour, 200);
		}
		else {
			return view('analytics.cash_hourly_sales',
				compact(
				'user_roles',
				'is_king',
				'since',
				'branch_location',    
				'hour',
				'userApprovedDate'
			)); 
		}
	}

	// Credits Term

	function showCreditProductSalesView() {
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];

        return view('analytics.credit_productsales', compact(
			'user_roles',
			'is_king',
			'since',
			'locations'
		));
	}
		function showCreditStaffSalesView() {
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];

        return view('analytics.credit_staffsales', compact(
			'user_roles',
			'is_king',
			'since',
			'locations'
		));
	}


	function showCashSalesMothlyStatementView() {	
		$id 		= 	Auth::user()->id;
		$user_roles = 	usersrole::where('user_id',$id)->get();
        $is_king 	=  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        if ($is_king != null) {
            $is_king = true;
        } 
        else {
            $is_king  = false;
        }
		$since = \Carbon\Carbon::now();
		$locations =  [];
        return view('analytics.cash_salesmonthly_statement', compact('user_roles','is_king','since','locations'
		));
	}


	public function dummy()
    {	$data= opos_eoddetails::select('total_amount','sst')->get();
        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('amount', function ($data) {
                return '<p class="pull-right" style=" margin: 0;">' . number_format($data['total_amount']/100,2) . '</p>';
            })
            ->addColumn('sst', function ($data) {           
                return '<p class="os- linkcolor loyaltyOutput pull-right" style=" margin: 0;">' . number_format($data['sst']/100,2) . '</p>';
            })
            ->escapeColumns([])
            ->make(true);
	}
	

	// Operative View
	function showOperativeViewMerchantSalesView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id', Auth::user()->id)->first();

        $company_id = $is_king->id;
        $owner_merchant = merchant::where('company_id',$company_id)->first();
		$owner_merchant_id = $owner_merchant->id;
		$since = \Carbon\Carbon::now();
		$locations = [];
		
        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
		}
		
		if (isset($request->filterByDateFrom)){
			$from_date = $request->filterByDateFrom;
			$to_date = $request->filterByDateTo;
		}
		else {
			
			$from_date = $since->format('Y-m-d');
			$to_date = $since->format('Y-m-d');
		}

		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
		$res_mechant_sales = DB::table('foodcourtmerchant')
			->select('foodcourtmerchant.tenant_merchant_id', DB::raw("SUM(opos_receiptdetails.total) as merchant_total"), 'company.name')
			->join('foodcourt','foodcourt.id','=','foodcourtmerchant.foodcourt_id')
			->join('merchant','foodcourtmerchant.tenant_merchant_id','=','merchant.id')
			->join('company','merchant.company_id','=','company.id')
			->join('foodcourtmerchantterminal','foodcourtmerchantterminal.foodcourtmerchant_id','=','foodcourtmerchant.id')
			->join('opos_receipt','opos_receipt.terminal_id','=','foodcourtmerchantterminal.terminal_id')
			->join('opos_receiptdetails','opos_receiptdetails.receipt_id','=','opos_receipt.id')
			->where('foodcourt.owner_merchant_id',$owner_merchant_id)
			->whereBetween('opos_receipt.created_at', [$from_date, $to_date])
			->groupBy('foodcourtmerchant.tenant_merchant_id')
			->orderBy('merchant_total','DESC')
			->get();

		$maxValue = 0;
		foreach ($res_mechant_sales as $key => $item) {
			if($maxValue < $item->merchant_total){
				$maxValue = $item->merchant_total;
			}
		}

		$mechant_sales = json_decode( json_encode($res_mechant_sales->toArray()), true);
		foreach ($mechant_sales as $key => $item) {
			$mechant_sales[$key]['percent'] = $item['merchant_total'] * 100 / $maxValue;
		}

		if (isset($request->filterByParams)){ 
			return response()->json($mechant_sales, 200);
		}

        return view('analytics.ov_merchantsales',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'userApprovedDate',
			'mechant_sales'
		)); 
	}
	
	function showOperativeViewOverallProductSalesView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        $company_id = $is_king->id;
        $owner_merchant = merchant::where('company_id',$company_id)->first();
		$owner_merchant_id = $owner_merchant->id;
		$since = \Carbon\Carbon::now();
		$locations = [];

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
		}
		
		if (isset($request->filterByDateFrom)){
			$from_date = $request->filterByDateFrom;
			$to_date = $request->filterByDateTo;
		}
		else {
			$from_date = $since->format('Y-m-d');
			$to_date = $since->format('Y-m-d');
		}


		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');

		$res_mechant_sales = DB::table('foodcourtmerchant')
			->select('foodcourtmerchant.tenant_merchant_id', DB::raw("SUM(opos_receiptdetails.total) as merchant_total"), 'company.name')
			->join('foodcourt','foodcourt.id','=','foodcourtmerchant.foodcourt_id')
			->join('merchant','foodcourtmerchant.tenant_merchant_id','=','merchant.id')
			->join('company','merchant.company_id','=','company.id')
			->join('foodcourtmerchantterminal','foodcourtmerchantterminal.foodcourtmerchant_id','=','foodcourtmerchant.id')
			->join('opos_receipt','opos_receipt.terminal_id','=','foodcourtmerchantterminal.terminal_id')
			->join('opos_receiptdetails','opos_receiptdetails.receipt_id','=','opos_receipt.id')
			->where('foodcourt.owner_merchant_id',$owner_merchant_id)
			->whereBetween('opos_receipt.created_at', [$from_date, $to_date])
			->groupBy('foodcourt.id')
			->orderBy('merchant_total','DESC')
			->get();

		$maxValue = 0;
		foreach ($res_mechant_sales as $key => $item) {
			if($maxValue < $item->merchant_total){
				$maxValue = $item->merchant_total;
			}
		}

		$mechant_sales = json_decode( json_encode($res_mechant_sales->toArray()), true);
		foreach ($mechant_sales as $key => $item) {
			$mechant_sales[$key]['percent'] = $item['merchant_total'] * 100 / $maxValue;
		}

		if (isset($request->filterByParams)){ 
			return response()->json($mechant_sales, 200);
		}
		
        return view('analytics.ov_overall_product_sales',
			compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'userApprovedDate',
			'mechant_sales'
		)); 
	}


	function showOperativeViewFoodCourtHourlySalesView(Request $request) {

 		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

		$company_id = $is_king->id;
		$owner_merchant = merchant::where('company_id',$company_id)->first();
		$owner_merchant_id = $owner_merchant->id;

		$since = \Carbon\Carbon::now();
		$locations = [];
        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
		}

		if (isset($request->filterByDate)){
			$date = $request->filterByDate;
		}
		else {
			$date = date('Y-m-d');
		}

		$from_date = $date . ' 00:00:00';
		$to_date = $date . ' 23:59:59';
		
		$filter_data = DB::table('foodcourtmerchant')
			->select(
				DB::raw('HOUR(opos_receiptdetails.created_at) AS FromHour'), 
				DB::raw("(SUM(opos_receiptdetails.item_amount)/100) AS total"), 
				DB::raw('count(opos_receiptdetails.id) AS count'))
			->join('foodcourt','foodcourt.id','=','foodcourtmerchant.foodcourt_id')
			->join('merchant','foodcourtmerchant.tenant_merchant_id','=','merchant.id')
			->join('company','merchant.company_id','=','company.id')
			->join('foodcourtmerchantterminal','foodcourtmerchantterminal.foodcourtmerchant_id','=','foodcourtmerchant.id')
			->join('opos_receipt','opos_receipt.terminal_id','=','foodcourtmerchantterminal.terminal_id')
			->join('opos_receiptdetails','opos_receiptdetails.receipt_id','=','opos_receipt.id')
			->where('foodcourt.owner_merchant_id',$owner_merchant_id)
			->whereBetween('opos_receiptdetails.created_at', [$from_date, $to_date])
			->groupBy('FromHour')
			->get();
		
		$ar = array();
		$hour = array_pad($ar,24,0);
	
		foreach ($hour as $keyh => $valueh) {
			foreach ($filter_data as $keya => $valuea) {
				if($keyh == $valuea->FromHour){
					$hour[$keyh]= $valuea->total;
				}
			}
		}
	
		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
		
		if (isset($request->filterByParams)){ 
			return response()->json($hour, 200);
		}
		else {
			return view('analytics.ov_foodcourt_hourly_sales',
				compact(
				'user_roles',
				'is_king',
				'since',
				'locations',   
				'hour',
				'userApprovedDate'
			)); 
		}
	}


	function showStockProductSalesQtyView(Request $request) {
		Log::debug('***** showStockProductSales() *****');
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		$logged_in_user_id = Auth::user()->id;
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }

		$since = \Carbon\Carbon::now();
		$locations = [];
		$each_product_quantity = DB::select(
		'SELECT SUM(opos_receiptproduct.quantity) AS T_quantity,product.name,product.thumbnail_1,product.id,merchantproduct.merchant_id 

			FROM 
				opos_receiptproduct,product,merchantproduct,company,locationproduct,merchantlocation ml
			WHERE
				
			    product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
				AND locationproduct.product_id= product.id
				AND ml.location_id = locationproduct.location_id
			    AND company.id=merchantproduct.merchant_id
				AND DATE(opos_receiptproduct.created_at) = :selectedDate
			   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'selectedDate'=> date('Y-m-d')]
		);

		//date range quantity
		if(isset($request->location_id) && !empty($request->location_id) && $request->location_id == "all"){
		
		$date_rage_product_quantity = DB::select(
		' SELECT latest.id AS id,
				   latest.name,
				   latest.type,
				   latest.thumbnail_1,
				   latest.merchant_id,
				   locationproduct.quantity  AS T_quantity
			FROM   (SELECT p.id,
						   p.name,
						   p.ptype            AS type,
						   p.thumbnail_1      AS thumbnail_1,
						   mp.merchant_id     AS merchant_id,
						   lp.quantity,
						   Max(lp.created_at) AS created_at
					FROM   product p,
						   merchantproduct mp,
						   company c,
						   merchant m,
						   locationproduct lp,
						   location l
					WHERE  mp.product_id = p.id
						   AND mp.merchant_id = m.id
						   AND lp.product_id = p.id
						   AND m.company_id = c.id
						   AND p.name IS NOT NULL
						   AND lp.quantity IS NOT NULL
						   AND c.id
						   AND c.owner_user_id = :id
						   AND l.id IS NOT NULL
						   AND l.id = lp.location_id
						   AND DATE(lp.created_at) = :selectedDate
					GROUP  BY p.id,
							  l.id) AS latest
				   INNER JOIN locationproduct
						   ON locationproduct.created_at = latest.created_at
			ORDER  BY T_quantity;',['id'=>$logged_in_user_id,'selectedDate'=> date($request->selectedDate)]
		);
		
		return response()->json($date_rage_product_quantity);
		
		}else if(isset($request->location_id) && !empty($request->location_id) && is_numeric($request->location_id)){
			
		$date_rage_product_quantity = DB::select(
		'SELECT latest.id AS id,
				   latest.name,
				   latest.type,
				   latest.thumbnail_1,
				   latest.merchant_id,
				   locationproduct.location_id AS location,
				   locationproduct.quantity    AS T_quantity
			FROM   (SELECT p.id,
						   p.name,
						   p.ptype            AS type,
						   p.thumbnail_1      AS thumbnail_1,
						   mp.merchant_id     AS merchant_id,
						   lp.quantity,
						   Max(lp.created_at) AS created_at
					FROM   product p,
						   merchantproduct mp,
						   company c,
						   merchant m,
						   locationproduct lp,
						   location l
					WHERE  mp.product_id = p.id
						   AND mp.merchant_id = m.id
						   AND lp.product_id = p.id
						   AND m.company_id = c.id
						   AND p.name IS NOT NULL
						   AND lp.quantity IS NOT NULL
						   AND c.id
						   AND c.owner_user_id = :id
						   AND l.id = :loc_id
						   AND l.id = lp.location_id
						   AND DATE(lp.created_at) = :selectedDate
					GROUP  BY p.id) AS latest
				   INNER JOIN locationproduct
						   ON locationproduct.created_at = latest.created_at
			ORDER  BY T_quantity;',['id'=>$logged_in_user_id,'loc_id'=>$request->location_id,'selectedDate'=> date($request->selectedDate)]
		);
		
		return response()->json($date_rage_product_quantity);
		
		}

		//branch loction
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');


		//all location quantity
		
		$location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->location_id]
		);

		if($location_product_quantity != null){
			return response()->json($location_product_quantity);
		}


		//all location quantity
		
		$location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->location_id]
		);
		
		if($location_product_quantity != null){
			return response()->json($location_product_quantity);
		}


		//indiviual location quantity
		
		$each_location_product_quantity = DB::select(
		'SELECT 
				SUM(opos_receiptproduct.quantity) AS T_quantity,
				product.name,
				product.thumbnail_1,
				product.id,
				merchantproduct.merchant_id,
				opos_receipt.id as recptid	

			FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
                location,
                opos_locationterminal
			WHERE
				opos_itemdetails.receiptproduct_id = opos_receiptproduct.id 
			    AND product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at > :froms 
			   
			GROUP BY 
				product.name 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$request->loc_id,'froms'=>$request->from_date]
		);

		if($each_location_product_quantity != null){
			return response()->json($each_location_product_quantity);
		}
		//User Approved Date
		$userApprovedDate = DB::select('
			SELECT
				c.approved_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userApprovedDate = \Carbon\Carbon::parse($userApprovedDate[0]->approved_at)->format('d F Y');
        return view('analytics.stocklevel', compact(
			'user_roles',
			'is_king',
			'since',
			'locations',
			'each_product_quantity',
			'branch_location',
			'userApprovedDate'
		));
	}


	public function showCashSalesMonthlyStatementView(){
		$id = Auth::user()->id;

        //branch loction
        $branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.' 
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');

        return view('analytics.cash_salesmonthly_statement', compact('branch_location'));
	}

	/*
	// product sales pdf start
	*/
	public function productSalesPdf(Request $request){
		$date_from = $request->from_date;
		$date_to = $request->to_date;
		$range_name = $request->range_name;   
		$branch_name = $request->branch_name;   
		$branch_id = $request->branch_id;   
		
        //for change range name ...
		if ($range_name == '') {
			$range_name = date('dMy', strtotime($date_to)) .' to '. date('dMy', strtotime($date_to));
		}else{
			if ($range_name == 'since') {
				$range_name = ucfirst($range_name).' '. date('dMy', strtotime($date_from));
			}else{
				$range_name = strtoupper($range_name).' '. date('dMy', strtotime($date_from));
			}
		}
        //dynamic title name
		$title_name = $request->title_name;

        //ligged user 
		$logged_in_user_id = Auth::user()->id;

		
		if ($branch_id != -1) {
        	//if have branch info
			$each_amount_date_range = DB::select(
				'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.systemid
					

				FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
				location,
				opos_locationterminal
				WHERE
				 product.id = opos_receiptproduct.product_id
				AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND company.owner_user_id=:id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN :froms AND :to

				GROUP BY 
				product.name 
				ORDER BY 
				(T_amount) DESC;',[
					'id'=>$logged_in_user_id,
					'loc_id'=>$branch_id,
					'froms'=>$date_from,
					'to'=>$date_to
				]
			);

		}else{
        //have not branch info
			$each_amount_date_range = DB::select(
				'SELECT SUM(opos_itemdetails.amount) AS T_amount,product.name,product.systemid FROM 
				opos_itemdetails,opos_receiptproduct,product,merchantproduct,company
				WHERE
				product.id = opos_receiptproduct.product_id
				AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND company.owner_user_id=:id
				AND company.id=merchantproduct.merchant_id
				AND opos_receiptproduct.created_at BETWEEN :froms AND :to
				GROUP BY product.id ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'froms'=>$date_from,'to'=>$date_to]
			);
		}   

        //company name .....
		$company_data = Company::where('owner_user_id', $logged_in_user_id)->first();
		if (!empty($company_data)) {
			$company_name = $company_data->name;
		}


		//send data to view PDF
		$contents = view("analytics.cash_product_sales_pdf",
			compact('title_name', 'range_name', 'each_amount_date_range', 'company_name','branch_name'))->render();
        
        // initialization Mpdf and object create
		$mpdf = new Mpdf([
                'utf-8', // mode - default ''
                'A4', // format - A4, for example, default ''
                10, // font size - default 0
                'dejavusans', // default font family
                10, // margin_left
                10, // margin right
                10, // margin top
                15, // margin bottom
                10, // margin header
                9, // margin footer
                'P' 
            ]);

		$mpdf->SetDefaultBodyCSS('color', '#000');
		$mpdf->SetTitle("ocosystem");
		$mpdf->SetSubject("Subject");
		$mpdf->SetAuthor("Company Name");
		$mpdf->autoScriptToLang = true;
		$mpdf->baseScript = 1;
		$mpdf->autoVietnamese = true;
		$mpdf->autoArabic = true;
		$mpdf->autoLangToFont = true;
		$mpdf->SetDisplayMode('fullwidth');
		$mpdf->setFooter('{PAGENO} / {nb}');
		$mpdf->setAutoTopMargin = 'stretch';
		$mpdf->setAutoBottomMargin = 'stretch';
		$stylesheet = file_get_contents('css/appviewPDF.css');
		$mpdf->WriteHTML($stylesheet, 1);
		$mpdf->WriteHTML($contents, 2);
		$mpdf->defaultfooterfontsize = 10;
		$mpdf->defaultfooterfontstyle = 'B';
		$mpdf->defaultfooterline = 0;
		$mpdf->SetCompression(true);
		$filename = date("Y-m-d_his") . '_download.pdf';
		$path = "pdf/analytics/";
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
			$myfile = fopen($path . "/index.html", "w");
			fclose($myfile);
		}
		
		$mpdf->Output($path.$filename, 'F');

		$data = ['responseCode' => 1, 'file_name' => $filename];
		return response()->json($data);   
	}
    //end product sales pdf

    /*
     product sales qty pdf start
    */
	function productSalesQtyPdf(Request $request){

		$date_from = $request->from_date;
		$date_to = $request->to_date;
		$range_name = $request->range_name;   
		$branch_name = $request->branch_name;   
		$branch_id = $request->branch_id;   
		
        //for change range name ...
		if ($range_name == '') {
			$range_name = date('dMy', strtotime($date_to)) .' to '. date('dMy', strtotime($date_to));
		}else{
			if ($range_name == 'since') {
				$range_name = ucfirst($range_name).' '. date('dMy', strtotime($date_from));
			}else{
				$range_name = strtoupper($range_name).' '. date('dMy', strtotime($date_from));
			}
		}

        //dynamic title name
		$title_name = $request->title_name;

        //ligged user 
		$logged_in_user_id = Auth::user()->id;

		
		if ($branch_id != -1) {
        	//if have branch info
			//indiviual location quantity
		$date_rage_product_quantity = DB::select(
		'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.systemid
					

				FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
				location,
				opos_locationterminal
				WHERE
				 product.id = opos_receiptproduct.product_id
				AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND company.owner_user_id=:id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN :froms AND :to

				GROUP BY 
				product.name 
				ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$branch_id,'froms'=>$date_from]
		);

		}else{
        //have not branch info
		//date range quantity
		$date_rage_product_quantity = DB::select(
		'SELECT SUM(opos_receiptproduct.quantity) AS T_quantity,product.name,product.systemid 
			FROM 
				opos_receiptproduct,product,merchantproduct,company
			WHERE
			    product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			    AND opos_receiptproduct.created_at > :froms						   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'froms'=>$date_from]
		);
		}   
		
        //company name .....
		$company_data = Company::where('owner_user_id', $logged_in_user_id)->first();
		if (!empty($company_data)) {
			$company_name = $company_data->name;
		}


		//send data to view PDF
		$contents = view("analytics.cash_productsales_pdf_qty",
			compact('title_name', 'range_name', 'date_rage_product_quantity', 'company_name','branch_name'))->render();
        
        // initialization Mpdf and object create
		$mpdf = new Mpdf([
                'utf-8', // mode - default ''
                'A4', // format - A4, for example, default ''
                10, // font size - default 0
                'dejavusans', // default font family
                10, // margin_left
                10, // margin right
                10, // margin top
                15, // margin bottom
                10, // margin header
                9, // margin footer
                'P' 
            ]);

		$mpdf->SetDefaultBodyCSS('color', '#000');
		$mpdf->SetTitle("ocosystem");
		$mpdf->SetSubject("Subject");
		$mpdf->SetAuthor("Company Name");
		$mpdf->autoScriptToLang = true;
		$mpdf->baseScript = 1;
		$mpdf->autoVietnamese = true;
		$mpdf->autoArabic = true;
		$mpdf->autoLangToFont = true;
		$mpdf->SetDisplayMode('fullwidth');
		$mpdf->setFooter('{PAGENO} / {nb}');
		$mpdf->setAutoTopMargin = 'stretch';
		$mpdf->setAutoBottomMargin = 'stretch';
		$stylesheet = file_get_contents('css/appviewPDF.css');
		$mpdf->WriteHTML($stylesheet, 1);
		$mpdf->WriteHTML($contents, 2);
		$mpdf->defaultfooterfontsize = 10;
		$mpdf->defaultfooterfontstyle = 'B';
		$mpdf->defaultfooterline = 0;
		$mpdf->SetCompression(true);
		$filename = date("Y-m-d_his") . '_download.pdf';
		$path = "pdf/analytics/";
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
			$myfile = fopen($path . "/index.html", "w");
			fclose($myfile);
		}
		$mpdf->Output($path.$filename, 'F');

		$data = ['responseCode' => 1, 'file_name' => $filename];
		return response()->json($data);
	}


	public function productStockQtyPdf(Request $request){

		$date_from = $request->from_date;   
		$branch_name = $request->branch_name;   
		$branch_id = $request->branch_id;   
        //dynamic title name
		$title_name = $request->title_name;
        //ligged user 
		$logged_in_user_id = Auth::user()->id;

		if ($branch_id == "all" || empty($branch_id)) {
        //date range quantity
		$date_rage_product_quantity = DB::select(
		'SELECT SUM(opos_receiptproduct.quantity) AS T_quantity,product.name,product.systemid 
			FROM 
				opos_receiptproduct,product,merchantproduct,company
			WHERE
			    product.id = opos_receiptproduct.product_id
			    AND merchantproduct.product_id = opos_receiptproduct.product_id
			    AND company.owner_user_id=:id
			    AND company.id=merchantproduct.merchant_id
			    AND opos_receiptproduct.created_at > :froms						   
			GROUP BY 
				product.id 
			ORDER BY 
				(T_quantity) DESC;',['id'=>$logged_in_user_id,'froms'=>date("Y-m-d", strtotime($date_from))]
		);

		}else{
        
        //indiviual location quantity		
		$date_rage_product_quantity = DB::select(
		'SELECT 
				SUM(opos_itemdetails.amount) AS T_amount,
				product.name,
				product.systemid
					
				FROM 
				opos_itemdetails,
				opos_receiptproduct,
				product,
				merchantproduct,
				company,
				opos_receipt,
				location,
				opos_locationterminal
				WHERE
				 product.id = opos_receiptproduct.product_id
				AND merchantproduct.product_id = opos_receiptproduct.product_id
				AND company.owner_user_id=:id
				AND	location.id=:loc_id
				AND location.id = opos_locationterminal.location_id
				AND opos_locationterminal.terminal_id=opos_receipt.terminal_id
				AND opos_receipt.id = opos_receiptproduct.receipt_id
				AND opos_receiptproduct.created_at BETWEEN :froms AND :to

				GROUP BY 
				product.name 
				ORDER BY 
				(T_amount) DESC;',['id'=>$logged_in_user_id,'loc_id'=>$branch_id,'froms'=>date("Y-m-d", strtotime($date_from))]
		);
		}   
		
        //company name .....
		$company_data = Company::where('owner_user_id', $logged_in_user_id)->first();
		if (!empty($company_data)) {
			$company_name = $company_data->name;
		}


		//send data to view PDF
		$contents = view("analytics.stocklevelpdf",
			compact('title_name', 'date_from', 'date_rage_product_quantity', 'company_name','branch_name'))->render();
        
        // initialization Mpdf and object create
		$mpdf = new Mpdf([
                'utf-8', // mode - default ''
                'A4', // format - A4, for example, default ''
                10, // font size - default 0
                'dejavusans', // default font family
                10, // margin_left
                10, // margin right
                10, // margin top
                15, // margin bottom
                10, // margin header
                9, // margin footer
                'P' 
            ]);

		$mpdf->SetDefaultBodyCSS('color', '#000');
		$mpdf->SetTitle("ocosystem");
		$mpdf->SetSubject("Subject");
		$mpdf->SetAuthor("Company Name");
		$mpdf->autoScriptToLang = true;
		$mpdf->baseScript = 1;
		$mpdf->autoVietnamese = true;
		$mpdf->autoArabic = true;
		$mpdf->autoLangToFont = true;
		$mpdf->SetDisplayMode('fullwidth');
		$mpdf->setFooter('{PAGENO} / {nb}');
		$mpdf->setAutoTopMargin = 'stretch';
		$mpdf->setAutoBottomMargin = 'stretch';
		$stylesheet = file_get_contents('css/appviewPDF.css');
		$mpdf->WriteHTML($stylesheet, 1);
		$mpdf->WriteHTML($contents, 2);
		$mpdf->defaultfooterfontsize = 10;
		$mpdf->defaultfooterfontstyle = 'B';
		$mpdf->defaultfooterline = 0;
		$mpdf->SetCompression(true);
		$filename = date("Y-m-d_his") . '_download.pdf';
		$path = "pdf/analytics/";
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
			$myfile = fopen($path . "/index.html", "w");
			fclose($myfile);
		}
		$mpdf->Output($path.$filename, 'F');

		$data = ['responseCode' => 1, 'file_name' => $filename];
		return response()->json($data);
	}

}
