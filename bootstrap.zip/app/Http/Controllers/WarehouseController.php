<?php

namespace App\Http\Controllers;

use Log;

use Illuminate\Http\Request;
use App\Models\usersrole;
use App\Models\role;
use App\Models\Company;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;

use \App\Classes\SystemID;

use \App\Models\product;
use \App\Models\productcolor;
use \App\Models\prd_inventory;
use \App\Models\Merchant;
use \App\Models\merchantproduct;
use \App\Models\opos_brancheod;
use \App\Models\opos_eoddetails;
use \App\Models\opos_itemdetails;
use \App\Models\opos_itemdetailsremarks;
use \App\Models\opos_receipt;
use \App\Models\opos_receiptdetails;
use \App\Models\opos_receiptproduct;
use \App\Models\opos_receiptproductspecial;
use \App\Models\locationproduct;
use \App\Models\merchantlocation;
use \App\Models\location;
use \App\Models\opos_locationterminal;
use \App\Models\opos_terminalproduct;
use \App\Models\opos_refund;
use \App\Models\StockReport;
use \App\Models\stockreportremarks;
use \App\Models\opos_damagerefund;
use \App\Models\Staff;
use \App\Models\opos_wastage;
use \App\Models\opos_wastageproduct;
use \App\Models\productbarcode;
use \App\Models\warehouse;
use \App\Models\rack;
use \App\Models\rackproduct;
use \App\Models\stockreportproduct;
use \App\Models\stockreportproductrack;
use \App\Models\productbarcodelocation;

use \App\Models\warranty;

use \App\Classes\UserData;

class WarehouseController extends Controller
{
    public function showWarehouseMain(){

        $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id', $id)->get();

        $is_king = \App\Models\Company::where('owner_user_id',
            Auth::user()->id)->first();

        $this->user_data = new UserData();
        $ids             = merchantlocation::where('merchant_id', $this->user_data->company_id())->pluck('location_id');
        $location        = location::where([['branch', '!=', 'null']])->where('warehouse',1)->whereIn('id', $ids)->latest()->get();

      return view('warehouse.warehouse',
            compact('user_roles', 'is_king','location'));
    }

    public function get_location_rack(Request $request)
    {
          $location_id = $request->get('location_id');
          $rack = array();
          if($location_id) {
              $location = location::where('id',$location_id)->first(); 
              $warehouse = warehouse::where('location_id',$location_id)->first();
              Log::debug('$warehouse='.json_encode($warehouse));

              if($warehouse) {
                $rack = rack::where('warehouse_id',$warehouse->id)->get();
                Log::debug('$rack='.json_encode($rack));
                foreach ($rack as $key => $value) {
                  $rack_product = StockReport::select('stockreportproduct.id')
                    ->join('stockreportproduct','stockreport.id','=','stockreportproduct.stockreport_id')
                    ->join('stockreportproductrack','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
                    ->where('stockreportproductrack.rack_id',$value->id)
                    ->where('stockreport.location_id',$location_id)
                    ->groupBy('stockreportproduct.product_id')
                    ->get();
                    $rack[$key]->quantity = count($rack_product);  
                }
              }
          }
          return Datatables::of($rack)->
                addIndexColumn()->
                addColumn('inven_pro_id', function ($memberList) {
                    return $memberList->systemid;
                })->
                addColumn('inven_pro_rack_no', function ($memberList) {
                    return (($memberList->rack_no) ? $memberList->rack_no : '-');
                    // return "<a title='".$memberList->rack_no."' href='#' data-toggle='modal' data-target='#war_rack_no' data-item_id='".$memberList->id."' data-rack_no='".$memberList->rack_no."' onclick='rack_update(this)'>". (($memberList->rack_no) ? $memberList->rack_no : '-') ."</a>";                    
                })->
                addColumn('inven_pro_desc', function ($memberList) {
                   return "<a title='".$memberList->description."' href='#' data-toggle='modal' data-target='#rack_desc' data-rackid='".$memberList->id."' data-item_desc='".$memberList->description."' onclick='rack_update(this)'>". (($memberList->description) ? $memberList->description : 'Description') ."</a>";
                })->
                addColumn('inven_pro_allocated', function ($memberList) {
                    return '<a href=""data-toggle="modal" data-target="#allocatedProducts" class="retail-voucher-list os-linkcolor" style="text-decoration:none;" onclick="rack_product_list('.$memberList->id.','.$memberList->rack_no.')">'.$memberList->quantity.'</a>';
                })->
                addColumn('inven_pro_remark', function ($memberList) {
                               return "<a title='".$memberList->remarks."' href='#' data-toggle='modal' data-target='#rack_remark' data-rack_id='".$memberList->id."' data-item_remark='".$memberList->remarks."' onclick='rack_update(this)'>". (($memberList->remarks) ? $memberList->remarks : 'Remarks') ."</a>";
                })->
                escapeColumns([])->
                make(true);

    }

    public function rack_product_list(Request $request)
    {
      $rack_product =array();
      $rack_id = $request->get('rack_id');
      $location_id = $request->get('location_id');
      if($rack_id) {
          $rack_product = StockReport::
                join('stockreportproduct','stockreport.id','=','stockreportproduct.stockreport_id')
                ->join('stockreportproductrack','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
                ->join('rack','rack.id','=','stockreportproductrack.rack_id')
                ->join('product','product.id','=','stockreportproduct.product_id')
                ->where('stockreportproductrack.rack_id',$rack_id)
                ->where('stockreport.location_id',$location_id)
                ->groupBy('stockreportproduct.product_id')
                ->get();
        foreach ($rack_product as $key => $value) {
            $rack_product_qty = StockReport::
                join('stockreportproduct','stockreport.id','=','stockreportproduct.stockreport_id')
              ->join('stockreportproductrack','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
              ->where('stockreportproduct.product_id',$value->product_id)
              ->where('stockreportproductrack.rack_id',$rack_id)
              ->where('stockreport.location_id',$location_id)  
              ->sum('stockreportproduct.quantity');
            $rack_product[$key]->quantity = $rack_product_qty;  
        }
      }
      return Datatables::of($rack_product)->
                addIndexColumn()->
                addColumn('inven_pro_name', function ($memberList) {
                    return '<img src="'.asset('images/product/'.$memberList->product_id.'/thumb/'.$memberList->thumbnail_1).'" style="height:40px;width:40px;object-fit:contain;margin-right:8px;">'. $memberList->name;
                })->
                addColumn('inven_pro_qty', function ($memberList) {
                    return '<a href=""data-toggle="modal" data-target="#qtyallocatedProducts" class="retail-voucher-list os-linkcolor" style="text-decoration:none;" onclick="rack_product_ledger('.$memberList->rack_id.','.$memberList->product_id.','.$memberList->rack_no.')">'.$memberList->quantity.'</a>';
                })->
                escapeColumns([])->
                make(true);
    }
    public function rack_product_ledger(Request $request)
    {
        $rack_product =array();
        $rack_id = $request->get('rack_id');
        $product_id = $request->get('product_id');
        $location_id = $request->get('location_id');
        if($rack_id) {
          $rack_product = stockreportproduct::select('stockreport.systemid','product.id as product_id','rack.id as rack_id','rack.rack_no','stockreportproduct.quantity','stockreport.type','stockreportproduct.created_at as lastupdate')
                  ->join('stockreportproductrack','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
                  ->join('rack','rack.id','=','stockreportproductrack.rack_id')
                  ->join('product','product.id','=','stockreportproduct.product_id')
                  ->join('stockreport','stockreportproduct.stockreport_id','=','stockreport.id')
                  ->where('stockreportproductrack.rack_id',$rack_id)
                  ->where('stockreportproduct.product_id',$product_id)
                  ->where('stockreport.location_id',$location_id)
                  ->get();
        }

      return Datatables::of($rack_product)->
                addIndexColumn()->
                addColumn('inven_report_id', function ($memberList) {
                    return $memberList->systemid;
                })->
                addColumn('inven_report_type', function ($memberList) {
                  if($memberList->type == 'stockin'){
                    return 'Stock In';
                  } else if($memberList->type == 'stockout') {
                    return 'Stock Out';
                  } else {
                    return $memberList->type;
                  }
                })->
                addColumn('inven_report_lastupdate', function ($memberList) {
                    return date('dMY',strtotime($memberList->lastupdate));
                })->
                addColumn('inven_report_qty', function ($memberList) {
                    return $memberList->quantity;
                })->
                escapeColumns([])->
                make(true);
    }

    public function addRack(Request $request)
    {   
        try {
          $location_id = $request->get('location_id');
          if($location_id) {
              $location = location::where('id',$location_id)->first(); 
              $warehouse = warehouse::where('location_id',$location_id)->first();
              if(!$warehouse) {
                $warehouse = new warehouse();
              }
              $warehouse->location_id = $location_id;
              $warehouse->name = $location->branch;
              $warehouse->save();
              
              $rack_system = DB::select("select nextval(rack_seq) as index_rack");
              $rack_system_id = $rack_system[0]->index_rack;
              $rack_system_id = sprintf("%010s",$rack_system_id);
              $rack_system_id = '113'.$rack_system_id;

              $rack_no = rack::where('warehouse_id',$warehouse->id)->count();


              $rack = new rack();
              $rack->systemid = $rack_system_id; 
              $rack->rack_no = $rack_no + 1; 
              $rack->warehouse_id = $warehouse->id; 
              $rack->save(); 
          }
          $msg = "Rack added successfully";
          return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e;//"Some error occured";
            return view('layouts.dialog', compact('msg'));
        }
    }


    public function removeRack(Request $request)
    {   
        try {
          $location_id = $request->get('location_id');
          if($location_id) {
              $warehouse = warehouse::where('location_id',$location_id)->first();
              $rack = rack::where('warehouse_id',$warehouse->id)->orderby('id','DESC')->first();
              $rack_check = stockreportproductrack::
                  join('stockreportproduct','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
                  ->where('stockreportproductrack.rack_id',$rack->id)
                  ->count();
              $barcode_rack = productbarcodelocation::where('rack_id',$rack->id)->count();
              $total_rack = $rack_check + $barcode_rack;
              log::debug('total_rack'.$total_rack);
              if($total_rack <= 0) {
                rack::where('id', $rack->id)->delete();
                $msg = "Rack removed successfully";
              } else {
                $msg = "Rack cannot be removed.";
              }
          }

          return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e;//"Some error occured";
            return view('layouts.dialog', compact('msg'));
        }
    }

    public function updateRemark(Request $request)
    {
        try{
            $id = Auth::user()->id;

            $rack_id = $request->get('rack_id');
            $item_remark = $request->get('item_remark');
            $rack = rack::where('id',$rack_id)->first();
            $rack->remarks = $item_remark;                
            $rack->save();

            $msg = "Remark saved successfully";
            $data = view('layouts.dialog', compact('msg'));
        } catch (\Exception $e) {
            {
                $msg = "Error occured while Saving Remark";
            }
            Log::error(
                "Error @ " . $e->getLine() . " file " . $e->getFile() .
                ":" . $e->getMessage()
            );
            $data = view('layouts.dialog', compact('msg'));
        }
        return $data;
    }

    public function updateRackNo(Request $request)
    {
        try{
            $id = Auth::user()->id;

            $rack_id = $request->get('item_id');
            $rack_no = $request->get('rack_no');
            $rack = rack::where('id',$rack_id)->first();
            $rack->rack_no = $rack_no;                
            $rack->save();

            $msg = "Rack Number saved successfully";
            $data = view('layouts.dialog', compact('msg'));
        } catch (\Exception $e) {
            {
                $msg = "Error occured while Saving Rack Number";
            }
            Log::error(
                "Error @ " . $e->getLine() . " file " . $e->getFile() .
                ":" . $e->getMessage()
            );
            $data = view('layouts.dialog', compact('msg'));
        }
        return $data;
    }

    public function updateRackDesc(Request $request)
    {
        try{
            $id = Auth::user()->id;

            $rack_id = $request->get('rack_id');
            $item_desc = $request->get('item_desc');
            $rack = rack::where('id',$rack_id)->first();
            $rack->description = $item_desc;                
            $rack->save();

            $msg = "Description saved successfully";
            $data = view('layouts.dialog', compact('msg'));
        } catch (\Exception $e) {
            {
                $msg = "Error occured while Saving description";
            }
            Log::error(
                "Error @ " . $e->getLine() . " file " . $e->getFile() .
                ":" . $e->getMessage()
            );
            $data = view('layouts.dialog', compact('msg'));
        }
        return $data;
    }

   	public function showtallyChartView() {
       return view('warehouse.tallychart');
   	}

    public function showpickUpControlView() {
    	return view('warehouse.pickupcontrol');
    }

    public function showdeliveryControlView() {
         return view('warehouse.deliverycontrol');
    }

    public function showdeliveryManView() {
        return view('warehouse.deliveryman');
   }
}
