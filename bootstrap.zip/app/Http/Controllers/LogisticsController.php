<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usersrole;
use App\Models\role;
use App\Models\Company;
use Illuminate\Support\Facades\Auth;

class LogisticsController extends Controller
{
    public function showLogisticsView() {
        return view('logistics.logistics');
    }

    public function showdeliveryControlView() {
         return view('logistics.deliverycontrol');
    }

    public function showdeliveryManView() {
        return view('logistics.deliveryman');
	}

	public function showVehicleManagementView() {
        $user_id = Auth::user()->id;
        $user_roles = usersrole::where('user_id', $user_id)->get();
        $is_king =  Company::where('owner_user_id', Auth::user()->id)->get();
        return view('logistics.vehiclemanagement', compact('user_roles', 'is_king'));
	}

	public function showtallyChartView() {
		return view('logistics.tallychart');
	}

	public function showFormRegionView() {
		return view('logistics.formregion');
	}

	public function showtallyByProductView() {
		return view('logistics.tallybyproduct');
	}

	public function showpickUpControlView() {
		return view('logistics.pickupcontrol');
	}
}
