<?php

namespace App\Http\Controllers;

use App\Models\OgFuelMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;
use Matrix\Exception;
use Yajra\DataTables\DataTables;
use \App\Classes\SystemID;
use \App\Classes\UserData;
use \App\Models\merchantproduct;
use \App\Models\product;
use \App\Models\oilgas;
use \App\Models\prd_inventory;
use App\Models\OgFuel;
use App\Models\OgTank;
use App\Models\OgFuelPrice;
use App\Models\usersrole;
use App\Models\role;
use App\Models\productcolor;
use \App\Models\StockReport;
use \App\Models\rackproduct;
use \App\Models\stockreportproduct;
use \App\Models\stockreportproductrack;
use \App\Models\opos_wastageproduct;
use \App\Models\opos_receiptproduct;
use \App\Models\Company;
use \App\Models\location;
use Illuminate\Support\Facades\Auth;
use \App\Models\locationproduct;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class IndustryOilGasController extends Controller
{

    public function __construct()
	{
		$this->middleware('auth');
    }

    public function index()
    {

        $this->user_data = new UserData();

//         $query = "
//         SELECT
//              sum(quantity)
//         FROM
//              opos_receiptproduct
//         JOIN  
//              product
//         WHERE
//              opos_receiptproduct.product_id = 468
//         GROUP BY 
//               opos_receiptproduct.id
// 		";

// 		$query = DB::select(DB::raw($query));
// dd($query);

        $model = new OgFuel();

        $ids = merchantproduct::where('merchant_id',
			$this->user_data->company_id())->
            pluck('product_id');
		
        //$ids = product::where('name','<>', null)->whereIn('id', $ids)->pluck('id');
		/**/
        $data = $model->whereIn('product_id', $ids)
            ->orderBy('created_at', 'asc')->get();
        
		foreach ($data as $key => $value) {
			$data[$key]['transaction'] = $this->check_transaction($value->product_id);
            $data[$key]['price'] = $this->get_execute_price($value->id);
            $data[$key]['total'] = $this->getTotal($value->product_id);
            $data[$key]['cash_sale'] = $this->getCashSale($value->product_id);
		}

        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('og_product_id', function ($oilgaslist) {
                return '<p data-field="og_product_id" style="cursor: pointer; margin: 0; text-align: center;"'. 'class="os-linkcolor doc_id" url="' .route("inventory.showstockreport",$oilgaslist->product_name->systemid) .'">' . $oilgaslist->product_name->systemid .'</p>';
            })
            ->addColumn('og_product_name', function ($oilgaslist) {
                if (!empty($oilgaslist->product_name->thumbnail_1)) {
                    $img_src = '/images/product/' . $oilgaslist->product_name->id . '/thumb/' . $oilgaslist->product_name->thumbnail_1;
                    $img     = "<img src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'/>";
                } else {
                    $img = "";
                }
                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;display:inline-block" onclick="details(' . $oilgaslist->product_name->systemid . ')">' . (!empty($oilgaslist->product_name->name) ? $oilgaslist->product_name->name : 'Product Name') . '</p>';
            })
            ->addColumn('og_litre', function ($oilgaslist) {

                // return '<p class="buyOutput" style="text-align: center;margin: 0;"  data-field="og_litre"><a href="/industry/oil-gas/product-ledger/' . $oilgaslist->product_id . '" target="_blank"  style="text-decoration:none;text-align: right;">'.(!empty($oilgaslist->litre) ? $oilgaslist->litre: '0.00').'</a></p>';
                return '<p class="buyOutput" style="text-align: center;margin: 0;"  data-field="og_litre">
                    <a href="/industry/oil-gas/product-ledger/' . $oilgaslist->product_id . '" target="_blank"  style="text-decoration:none;text-align: right;">'
                    .(!empty($oilgaslist->total) ?
                        number_format(($oilgaslist->total - $oilgaslist->cash_sale),2) : '0.00').
                    '</a></p>';

            })
            ->addColumn('og_price', function ($oilgaslist) {

                return '<p class="os-linkcolor getOutput" style="text-align: right;margin: 0;" data-field="og_price"><a href="/industry/oil-gas/fuel-prices/' . $oilgaslist->id . '" target="_blank" style="text-decoration:none;text-align: right;">'.(!empty($oilgaslist->price) ? number_format(($oilgaslist->price/100),2): '0.00').'</a></p>';

            })
            ->addColumn('og_loyalty', function ($oilgaslist) {

                if($oilgaslist->loyalty == '' || $oilgaslist->loyalty == null){
                    $oilgaslist->loyalty = 0;
                }

                return '<p class="os-linkcolor getOutput" style="cursor: pointer; margin: 0; text-align: center;" data-toggle="modal"  data-target="#loyaltyUpdateModal'.$oilgaslist->id.'" style="text-align: right;margin: 0;" data-field="og_loyalty">' . $oilgaslist->loyalty . '</p>'.
                //modal pop up for the loyalty definition form
                '<div class="modal fade" id="loyaltyUpdateModal'.$oilgaslist->id.'" onblur="update_loyalty('.$oilgaslist->product_id.','.$oilgaslist->id.','.$oilgaslist->loyalty.')" tabindex="-1" role="dialog" aria-labelledby="LoyaltyUpdate" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm">
                <div class="modal-content">
                    <!-- Modal body -->
                    <div class="modal-body">
                        <input tabindex="-1" style="text-align: center; " id="fuel_product_loyalty'.$oilgaslist->id.'" min="0" type="number" class="pl-1 form-control" value="'.$oilgaslist->loyalty.'"  style="width: 100%; border: 1px solid #ddd;">
                    </div>
                </div>
                </div>
            </div>';

            })
            ->addColumn('deleted', function ($oilgaslist) {
                 return '<a href="/rtm/cap-info/' . $oilgaslist->id . '/view" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-folder-open mr-5"></i> ' . trans('rtm/cap_info.btn_view') . '</a>';

            })->
            addColumn('deleted', function ($oilgaslist) {
				if ($oilgaslist->transaction == 'True') {
					
					return '<p
						style="background-color:#ddd;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor:not-allowed;"
						class="text-secondary" >
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px #ccc;"></i></p>';
					
				} else {
					
					return '<p data-field="deleted"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
				}
			})->
		escapeColumns([])->
		make(true);
    }

    public function updateLoyalty(Request $request){
        // print_r($request->all());
        // echo $request['product_id'];
        $product_id = $request['product_id'];
        // echo $product_id;
        $new_loyalty_value = $request['new_loyalty_value'];
        // echo $new_loyalty_value;
        $update = Ogfuel::where('product_id', $product_id)->update(['loyalty' => $new_loyalty_value]);
        if($update){
            return 200;
        }else{
            return 'failed';
        }
    }

    public function getTotal($product_id) {
        return stockreportproduct::where('product_id', $product_id)->sum('quantity');
        /* $stockreports = stockreportproduct::where('product_id', $product_id)->get();
         $total = 0;
         foreach ($stockreports as $key => $value) {
             $total = $total + $value->quantity;
         }
         return $total;*/
    }

    protected function getCashSale($product_id){
       return opos_receiptproduct::where('product_id', $product_id)->sum('quantity');
    }


    public function showTankManagement(Request $request)
    {
        $this->user_data = new UserData();

        $merchant_id = $this->user_data->company_id();

        $merchantproducts = merchantproduct::where('merchant_id', $merchant_id)->pluck('product_id');

        $location_ID = $request->locID;

        if (!empty($request->locID)) {

            $model = OgTank::where(['location_id' => $location_ID])->whereIn("product_id", $merchantproducts)->get();
            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('tank_no', function ($tanklist) {
                    return '<p class="os-linkcolor" id="tank_no_' . $tanklist->id . '" onclick="storeTankID(' . $tanklist->id . ',' . $tanklist->tank_no . ')" style="cursor: pointer; margin: 0; text-align: center;">' . $tanklist->tank_no . '</p>';
                })
                ->addColumn('tank_id', function ($tanklist) {
                    return '<p style=" margin: 0; text-align: center;">' . $tanklist->systemid . '</p>';
                })
                ->addColumn('product', function ($tanklist) {

                    if (!empty($tanklist->product_name->thumbnail_1)) {
                        $img_src = '/images/product/' . $tanklist->product_name->id . '/thumb/' . $tanklist->product_name->thumbnail_1;
                        $prod_img_id = $tanklist->product_name->id;
                        //class='img-product-thumb-$prod_img_id'
                        $img = "<img id='img-product-thumb-' src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;float:left;object-fit:contain;'/>";
                    } else {
                        $img = "";
                    }
//                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;float:left;display:inline-block;" onclick="details(' . $tanklist->product_name . ')">' . (!empty($tanklist->product_name->name) ? $tanklist->product_name->name : 'Product Name') . '</p>';
//
//				if (!empty($tanklist->product_name)) {
//					$product_name = $tanklist->product_name->name;
//				} else {
//					$product_name = "Product Name";
//				}

                    return $img . '<p class="os-linkcolor" id="tank_product_' . $tanklist->id . '" style="cursor: pointer;  text-align: left;margin-bottom: 0px;" onclick="showProducts(' . $tanklist->id . ')"  >' . (!empty($tanklist->product_id) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                })
                ->addColumn('height', function ($tanklist) {
                    return '<p id="tank_height_' . $tanklist->id . '" class="os-linkcolor" data-field="' . $tanklist->id . '"  onclick="showogFuelHeightModel(' . $tanklist->id . ',' . $tanklist->systemid . ')"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >' . (!empty($tanklist->height) ? number_format($tanklist->height) : '0') . '</p>';

                })
                ->addColumn('deleted', function ($tanklist) {
                    return '<p data-field="deleted"
                        id="' . $tanklist->systemid . '"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
                })->
                escapeColumns([])->
                make(true);

        }else{

            $model = OgTank::whereIn("product_id", $merchantproducts)->get();
            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('tank_no', function ($tanklist) {
                    return '<p class="os-linkcolor" id="tank_no_' . $tanklist->id . '" onclick="storeTankID(' . $tanklist->id . ',' . $tanklist->tank_no . ')" style="cursor: pointer; margin: 0; text-align: center;">' . $tanklist->tank_no . '</p>';
                })
                ->addColumn('tank_id', function ($tanklist) {
                    return '<p style=" margin: 0; text-align: center;">' . $tanklist->systemid . '</p>';
                })
                ->addColumn('product', function ($tanklist) {

                    if (!empty($tanklist->product_name->thumbnail_1)) {
                        $img_src = '/images/product/' . $tanklist->product_name->id . '/thumb/' . $tanklist->product_name->thumbnail_1;
                        $prod_img_id = $tanklist->product_name->id;
                        //class='img-product-thumb-$prod_img_id'
                        $img = "<img id='img-product-thumb-' src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;float:left;object-fit:contain;'/>";
                    } else {
                        $img = "";
                    }
//                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;float:left;display:inline-block;" onclick="details(' . $tanklist->product_name . ')">' . (!empty($tanklist->product_name->name) ? $tanklist->product_name->name : 'Product Name') . '</p>';
//
//				if (!empty($tanklist->product_name)) {
//					$product_name = $tanklist->product_name->name;
//				} else {
//					$product_name = "Product Name";
//				}

                    return $img . '<p class="os-linkcolor" id="tank_product_' . $tanklist->id . '" style="cursor: pointer;  text-align: left;margin-bottom: 0px;" onclick="showProducts(' . $tanklist->id . ')"  >' . (!empty($tanklist->product_id) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                })
                ->addColumn('height', function ($tanklist) {
                    return '<p id="tank_height_' . $tanklist->id . '" class="os-linkcolor" data-field="' . $tanklist->id . '"  onclick="showogFuelHeightModel(' . $tanklist->id . ',' . $tanklist->systemid . ')"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >' . (!empty($tanklist->height) ? number_format($tanklist->height) : '0') . '</p>';

                })
                ->addColumn('deleted', function ($tanklist) {
                    return '<p data-field="deleted"
                        id="' . $tanklist->systemid . '"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
                })->
                escapeColumns([])->
                make(true);
        }

    }

    public function showTank_AccordingLocation_Disabled(Request $request)
    {
        $location_ID = $request->location_id;

        $model = OgTank::where(['location_id' => $location_ID])->get();
        return Datatables::of($model)
            ->addIndexColumn()
            ->addColumn('tank_no', function ($tanklist) {
                return '<p class="os-linkcolor" id="tank_no_' . $tanklist->id . '" onclick="storeTankID(' . $tanklist->id . ',' . $tanklist->tank_no . ')" style="cursor: pointer; margin: 0; text-align: center;">' . $tanklist->tank_no . '</p>';
            })
            ->addColumn('tank_id', function ($tanklist) {
                return '<p style=" margin: 0; text-align: center;">' . $tanklist->systemid . '</p>';
            })
            ->addColumn('product', function ($tanklist) {

                if (!empty($tanklist->product_name->thumbnail_1)) {
                    $img_src = '/images/product/' . $tanklist->product_name->id . '/thumb/' . $tanklist->product_name->thumbnail_1;
                    $prod_img_id = $tanklist->product_name->id;
                    //class='img-product-thumb-$prod_img_id'
                    $img = "<img id='img-product-thumb-' src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;float:left;object-fit:contain;'/>";
                } else {
                    $img = "";
                }
//                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;float:left;display:inline-block;" onclick="details(' . $tanklist->product_name . ')">' . (!empty($tanklist->product_name->name) ? $tanklist->product_name->name : 'Product Name') . '</p>';
//
//				if (!empty($tanklist->product_name)) {
//					$product_name = $tanklist->product_name->name;
//				} else {
//					$product_name = "Product Name";
//				}

                return $img . '<p class="os-linkcolor" id="tank_product_' . $tanklist->id . '" style="cursor: pointer;  text-align: left;margin-bottom: 0px;" onclick="showProducts(' . $tanklist->id . ')"  >' . (!empty($tanklist->product_id) ? $tanklist->product_name->name : 'Product Name') . '</p>';
            })
            ->addColumn('height', function ($tanklist) {
                return '<p id="tank_height_' . $tanklist->id . '" class="os-linkcolor" data-field="' . $tanklist->id . '"  onclick="showogFuelHeightModel(' . $tanklist->id . ',' . $tanklist->systemid . ')"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >' . (!empty($tanklist->height) ? number_format($tanklist->height) : '0') . '</p>';

            })
            ->addColumn('deleted', function ($tanklist) {
                return '<p data-field="deleted"
                        id="' . $tanklist->systemid . '"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
            })->

            escapeColumns([])->
            make(true);
    }

    public function showTank_AccordingLocation(Request $request)
    {
        $location_ID = $request->locID;

        if (!empty($request->locID)) {

            $model = OgTank::where(['location_id' => $location_ID])->get();
            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('tank_no', function ($tanklist) {
                    return '<p class="os-linkcolor" id="tank_no_' . $tanklist->id . '" onclick="storeTankID(' . $tanklist->id . ',' . $tanklist->tank_no . ')" style="cursor: pointer; margin: 0; text-align: center;">' . $tanklist->tank_no . '</p>';
                })
                ->addColumn('tank_id', function ($tanklist) {
                    return '<p style=" margin: 0; text-align: center;">' . $tanklist->systemid . '</p>';
                })
                ->addColumn('product', function ($tanklist) {

                    if (!empty($tanklist->product_name->thumbnail_1)) {
                        $img_src = '/images/product/' . $tanklist->product_name->id . '/thumb/' . $tanklist->product_name->thumbnail_1;
                        $prod_img_id = $tanklist->product_name->id;
                        //class='img-product-thumb-$prod_img_id'
                        $img = "<img id='img-product-thumb-' src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;float:left;object-fit:contain;'/>";
                    } else {
                        $img = "";
                    }
                    //                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;float:left;display:inline-block;" onclick="details(' . $tanklist->product_name . ')">' . (!empty($tanklist->product_name->name) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                    //
                    //				if (!empty($tanklist->product_name)) {
                    //					$product_name = $tanklist->product_name->name;
                    //				} else {
                    //					$product_name = "Product Name";
                    //				}

                    return $img . '<p class="os-linkcolor" id="tank_product_' . $tanklist->id . '" style="cursor: pointer;  text-align: left;margin-bottom: 0px;" onclick="showProducts(' . $tanklist->id . ')"  >' . (!empty($tanklist->product_id) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                })
                ->addColumn('height', function ($tanklist) {
                    return '<p id="tank_height_' . $tanklist->id . '" class="os-linkcolor" data-field="' . $tanklist->id . '"  onclick="showogFuelHeightModel(' . $tanklist->id . ',' . $tanklist->systemid . ')"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >' . (!empty($tanklist->height) ? number_format($tanklist->height) : '0') . '</p>';

                })
                ->addColumn('deleted', function ($tanklist) {
                    return '<p data-field="deleted"
                        id="' . $tanklist->systemid . '"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
                })->

                escapeColumns([])->
                make(true);

        }else{

            $model = OgTank::all();
            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('tank_no', function ($tanklist) {
                    return '<p class="os-linkcolor" id="tank_no_' . $tanklist->id . '" onclick="storeTankID(' . $tanklist->id . ',' . $tanklist->tank_no . ')" style="cursor: pointer; margin: 0; text-align: center;">' . $tanklist->tank_no . '</p>';
                })
                ->addColumn('tank_id', function ($tanklist) {
                    return '<p style=" margin: 0; text-align: center;">' . $tanklist->systemid . '</p>';
                })
                ->addColumn('product', function ($tanklist) {

                    if (!empty($tanklist->product_name->thumbnail_1)) {
                        $img_src = '/images/product/' . $tanklist->product_name->id . '/thumb/' . $tanklist->product_name->thumbnail_1;
                        $prod_img_id = $tanklist->product_name->id;
                        //class='img-product-thumb-$prod_img_id'
                        $img = "<img id='img-product-thumb-' src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;float:left;object-fit:contain;'/>";
                    } else {
                        $img = "";
                    }
                    //                return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;float:left;display:inline-block;" onclick="details(' . $tanklist->product_name . ')">' . (!empty($tanklist->product_name->name) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                    //
                    //				if (!empty($tanklist->product_name)) {
                    //					$product_name = $tanklist->product_name->name;
                    //				} else {
                    //					$product_name = "Product Name";
                    //				}

                    return $img . '<p class="os-linkcolor" id="tank_product_' . $tanklist->id . '" style="cursor: pointer;  text-align: left;margin-bottom: 0px;" onclick="showProducts(' . $tanklist->id . ')"  >' . (!empty($tanklist->product_id) ? $tanklist->product_name->name : 'Product Name') . '</p>';
                })
                ->addColumn('height', function ($tanklist) {
                    return '<p id="tank_height_' . $tanklist->id . '" class="os-linkcolor" data-field="' . $tanklist->id . '"  onclick="showogFuelHeightModel(' . $tanklist->id . ',' . $tanklist->systemid . ')"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >' . (!empty($tanklist->height) ? number_format($tanklist->height) : '0') . '</p>';

                })
                ->addColumn('deleted', function ($tanklist) {
                    return '<p data-field="deleted"
                        id="' . $tanklist->systemid . '"
						style="background-color:red;
						border-radius:5px;margin:auto;
						width:25px;height:25px;
						display:block;cursor: pointer;"
						class="text-danger remove">
						<i class="fas fa-times text-white"
						style="color:white;opacity:1.0;
						padding-top:4px;
						-webkit-text-stroke: 1px red;"></i></p>';
                })->

                escapeColumns([])->
                make(true);
        }
    }


    public function storeTank(Request $request)
    {
        try {
            $SystemID = new SystemID('og_tank');
            $og_tank = new OgTank();

            if (empty($request->location_id)) {
                $msg = "Please select a location";
                return view('layouts.dialog', compact('msg'));
            }

            $og_tank->tank_no = '0';
            $og_tank->location_id = $request->location_id;
            $og_tank->systemid = $SystemID->__toString();
            $og_tank->height = '0';
            $og_tank->save();

            $msg = "Tank added successfully";
            return view('layouts.dialog', compact('msg'));
            // return view('layouts.dialog')->with(['msg'=>$msg]);

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
            // return view('layouts.dialog')->with(['msg'=>$msg]);
        }
    }



    public function updateTankHeight(Request $request)
    {
        try {
            $this->user_data = new UserData();
            $og_tank_id   = $request->get('TankID');
            $height       = (int)str_replace(',', '',str_replace('.', '',
				number_format($request->get('ogTankHeight'))));
                                
            $ogTankHeight = OgTank::where('systemid',$og_tank_id)->first();
            
            $ogTankHeight->height = $height;
            $ogTankHeight->save();
            $msg = "Height updated successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }
    }


    public function showTankProducts(Request $request)
    {
        //$og_fuels= OgFuel::all()->take($request->length);

		$query = "
		SELECT
			latest.id,
			latest.name,
			og_fuelprice.ogfuel_id as No,
			og_fuelprice.price
		FROM (
		SELECT
			p.id,
			p.name,
			max(fp.created_at) as fp_created_at
		FROM
			product p,
			prd_ogfuel pof,
			merchantproduct mp,
			company c,
			merchant m,
			og_fuelprice fp
		WHERE
			pof.product_id = p.id 
			AND mp.product_id = p.id
			AND mp.merchant_id = m.id
			AND fp.ogfuel_id = pof.id
			AND m.company_id = c.id
			AND p.name is not null
			AND fp.price is not null
			AND c.owner_user_id = ".Auth::user()->id."
		GROUP BY
			p.id
		) as latest
		INNER JOIN
			og_fuelprice
		ON
			og_fuelprice.created_at = latest.fp_created_at
		ORDER BY
			og_fuelprice.ogfuel_id
		LIMIT 8
		";

		$og_fuels = DB::select(DB::raw($query));

        $output="";
        foreach ($og_fuels as  $og_fuel) {
            $output.='<button class="btn btn-success bg-enter btn-log sellerbuttonwide ps-function-btn pump_credit_card_product"  style="width: 129px !important;" onclick="add_product_pump('.$og_fuel->id.','.$request->tank_id.')" > <span>'. $og_fuel->name .' </span> </button>';
        }

        $response = [
            'og_fuels' => $og_fuels,
            'output' => $output,
        ];
        return response()->json($response);
    }


    public function saveTankProducts(Request $request){
        try{
            $product_id=$request->product_id;
            $tank_id=$request->tank_id;

            $tank=OgTank::find($tank_id);
            $tank->product_id=$product_id;
            $tank->save();
            $msg = 'Product updated successfully';
            return view('layouts.dialog', compact('msg'));
//            return view('layouts.dialog')->with(['msg'=>$msg]);

        }catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
//            return view('layouts.dialog')->with(['msg'=>$msg]);
        }
    }


    public function getTankProducts(Request $request){
        try{
            $tank_id=$request->tank_id;
            $product_name=OgTank::find($tank_id)->product_name()->first()->name;
            $product_id = OgTank::find($tank_id)->product_name()->first()->id;
            $product_image_thumbnail = OgTank::find($tank_id)->product_name()->first()->thumbnail_1;

            return array('0' => $product_name, '1' => $product_id, '2' => $product_image_thumbnail);

        }catch (\Exception $e) {
            $msg = $e->getMessage();
//            return view('layouts.dialog', compact('msg'));
            return view('layouts.dialog')->with(['msg'=>$msg]);
        }
    }


    public function saveTankNo(Request $request){
        try {
            $tank_id=$request->tank_id;
            $tank_no=$request->tank_no;

            $tank=OgTank::find($tank_id);
            $tank->tank_no=$tank_no;
            $tank->save();
            $msg = 'Tank No. updated successfully';
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }
    }
    

	public function check_transaction($product_id)
	{

		$sales_count = opos_receiptproduct::where('product_id', $product_id)
			->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->count();
            
		$stock_count = StockReport::where('product_id', $product_id)->count();
		$wastage = opos_wastageproduct::where('product_id', $product_id)->count();
        $total = $sales_count + $stock_count + $wastage;
        //dd($total);
		if ($total > 0) {
			return true;
		} else {
			return false;
		}
    } 


	public function get_execute_price($id)
	{
		$ogFuelPrice = OgFuelPrice::where('ogfuel_id', $id)
						->where('price', '!=', null)
                        ->where('start', '!=', null)
                        ->whereDate('start', '<=', Carbon::now())
						->orderBy('id', 'DESC')
						->first();
					
		if(!empty($ogFuelPrice)){
			$price = $ogFuelPrice->price;
		}else{
			$price = '0.00';
		}
		
		return $price;
    }
	
    	
    public function showOgFuelProducts(Request $request)
    {
        $company_id=DB::table('users')
        // ->select('staff.company_id')
        ->join('staff','users.id','staff.user_id')
        ->where('staff.user_id' , Auth::user()->id )->first()->company_id;
        $query = "
		SELECT
			latest.id,
            latest.name,
            latest.thumbnail_1,
            latest.systemid,
			og_fuelprice.ogfuel_id as No,
			og_fuelprice.price,
            og_fuelprice.start
		FROM (
		SELECT
			p.id,
            p.name,
            p.thumbnail_1,
            p.systemid,
			max(fp.created_at) as fp_created_at
		FROM
			product p,
			prd_ogfuel pof,
			merchantproduct mp,
			company c,
			merchant m,
			og_fuelprice fp
		WHERE
			pof.product_id = p.id 
			AND mp.product_id = p.id
			AND mp.merchant_id = m.id
			AND fp.ogfuel_id = pof.id
			AND m.company_id = c.id
			AND p.name is not null
            AND p.prdcategory_id  > 0
            AND p.prdsubcategory_id  > 0
            AND p.prdprdcategory_id > 0
            AND p.photo_1 is not null
			AND fp.price is not null
            AND fp.start <= '".Carbon::now()."'   
			AND c.id = ".$company_id."
		GROUP BY
			p.id
		) as latest
		INNER JOIN
			og_fuelprice
		ON
			og_fuelprice.created_at = latest.fp_created_at
		ORDER BY
			og_fuelprice.ogfuel_id
		LIMIT 8
		";
        $products = DB::select(DB::raw($query));

        $output="";
        foreach ($products as  $product) {
            $output.='<button class="btn btn-success bg-enter btn-log sellerbuttonwide ps-function-btn pump_credit_card_product" href_fuel_prod_name="'.$product->name.'" href_fuel_prod_id="'.$product->id.'" href_fuel_prod_thumbnail="'.$product->thumbnail_1.'" href_fuel_prod_systemid="'.$product->systemid.'" style="width: 129px !important;"> <span>'. $product->name .' </span> </button>';
        }


        $totalRecords = count($products);

        $response = [
            'data' => $products,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'output'   => $output
        ];
        return response()->json($response);
    }

    public function getOgFuelQualifiedProducts() {

        $products_chunck=array();
        $filter = array();
        $this->user_data = new UserData();
        $merchant_product_ids = merchantproduct::where('merchant_id',$this->user_data->company_id())->	
            pluck('product_id');

        $ids = OgFuel::whereIn('product_id',$merchant_product_ids)->pluck('product_id');

        $products = product::
                     select('product.*','og_fuelprice.start','og_fuelprice.price','og_fuelprice.ogfuel_id as og_f_id')
                    ->join('prd_ogfuel','product.id','prd_ogfuel.product_id')
                    ->join('og_fuelprice','prd_ogfuel.id','og_fuelprice.ogfuel_id')
                    ->whereIn('product.id',$ids)
                    ->where([
                        ['name', '<>', null] ,
                        ['prdcategory_id', '>', 0],
                        ['prdsubcategory_id', '>', 0],
                        ['prdprdcategory_id', '>', 0],
                        ['photo_1','!=',null]
                    ])
                    ->whereDate('og_fuelprice.start', '<=', Carbon::now())
                    ->orderBy('og_fuelprice.created_at', 'DESC')
                    ->get();
        
        foreach($products as $product){
            if(!in_array($product->og_f_id, $filter)){
                $products_chunck[] = $product;
                $filter[] = $product->og_f_id;
            }
        }
        return $products_chunck;
    }

    public function showOgFuelQualifiedProducts(Request $request) {
        $products = $this->getOgFuelQualifiedProducts();
        $output="";
        foreach ($products as  $product) {
            $output.='<button class="btn btn-success bg-enter btn-log sellerbuttonwide ps-function-btn pump_credit_card_product" href_fuel_prod_name="'
                        .$product->name.'" href_fuel_prod_id="'.$product->id.'" href_fuel_prod_thumbnail="'.$product->thumbnail_1.'" href_fuel_prod_systemid="'
                        .$product->systemid.'" style="width: 129px !important;"> <span>'. $product->name .' </span> </button>';
        }


        $totalRecords = count($products);

        $response = [
            'data' => $products,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'output'   => $output
        ];
        return response()->json($response);
    }


    public function saveProduct(Request $request) {
        //Create a new product here
        try {
            $this->user_data = new UserData();
            $SystemID = new SystemID('product');

            $product = new product();
            $product->systemid = $SystemID;
            $product->ptype = 'inventory';
            $product->save();

            $inventory = new prd_inventory();
            $inventory->product_id = $product->id;
            $inventory->save();

            $merchantproduct = new merchantproduct();
            $merchantproduct->product_id = $product->id;
            $merchantproduct->merchant_id = $this->user_data->company_id();
            $merchantproduct->save();

            $ogFuel = new OgFuel();
            $ogFuel->product_id = $product->id;
            $ogFuel->save();

            $msg = "Product added successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }
    }
    

    function showIndustryView(){
        return view('industry.oil_gas.og_oilgas');
    }


    function showFuelPriceView($id) {
		$oilgas = OgFuel::where('id', $id)->first();
        return view('industry.oil_gas.og_fuelprice', compact(['id', 'oilgas']));
    }


    function showProductLedgerView($id,Request $request) {
            //atif
        $product = DB::table('product')
            ->join('prd_ogfuel' , 'product.id' , '=' , 'prd_ogfuel.product_id')
            ->select("product.*")
            ->where(['product.id' => $id])->first();

        if($request->day) {
            $stockreportproducts = $this->getStockReportProducts($id, $request, true , false);
            $opos_product = $this->getOposreceiptproducts($id, $request,true , false);

        }else{

            $stockreportproducts = $this->getStockReportProducts($id, $request , false , false);
            $opos_product = $this->getOposreceiptproducts($id, $request, false , false);
        }

        $data = $opos_product->merge($stockreportproducts)->map(function ($item){
            $item->table_name = class_basename($item);
            return $item;
        })->sortByDesc('updated_at');

    /*  
        return view('industry.oil_gas.og_productledger')->with([
            'stockreportproducts' => $stockreportproducts,
            'product' => $product//product::findOrFail($id)
        ]);
    */


//        $location_product = locationproduct::where('product_id', $id)->first();
    /*   $opos_receiptproduct = opos_receiptproduct::with('receipt')
            ->join('locationproduct', 'opos_receiptproduct.product_id',
                '=', 'locationproduct.product_id')->latest('opos_receiptproduct.created_at')->limit(10)->get();


        dd($opos_receiptproduct);*/


      /*  return view('industry.oil_gas.og_productledger')->with([
            'stockreportproducts' => $stockreportproducts,
            'product' => product::findOrFail($id)
        ]);
            */


    // ,'stockreport.type as type'
       // $item[class_basename($item)
        // dd($data)
        return view('industry.oil_gas.og_productledger',
			compact('id', 'product','opos_product','stockreportproducts', 'data'));
    }

    function showProductLedgerViewSale($id , $location_id , Request $request) {
        $product = DB::table('product')
            ->join('prd_ogfuel' , 'product.id' , '=' , 'prd_ogfuel.product_id')
            ->select("product.*")
            ->where(['product.id' => $id])->first();
        if($request->day) {
            $stockreportproducts = $this->getStockReportProducts($id, $request, true , $location_id);
            $opos_product = $this->getOposreceiptproducts($id, $request ,true , $location_id);

        }else{
            $stockreportproducts = $this->getStockReportProducts($id, $request , false , $location_id);
            $opos_product = $this->getOposreceiptproducts($id, $request ,false , $location_id);
        }

        $data = $opos_product->merge($stockreportproducts)->map(function ($item){
            $item->table_name = class_basename($item);
            return $item;
        })->sortByDesc('updated_at');
        return view('industry.oil_gas.og_productledger_sale',
            compact('id', 'product','opos_product','stockreportproducts', 'data'));
    }

    function showProductLedgerViewReceipt($id , $location_id , Request $request) {
        $product = DB::table('product')
            ->join('prd_ogfuel' , 'product.id' , '=' , 'prd_ogfuel.product_id')
            ->select("product.*")
            ->where(['product.id' => $id])->first();
            
        if($request->day) {
            $stockreportproducts = $this->getStockReportProducts($id, $request, true , $location_id);
            $opos_product = $this->getOposreceiptproducts($id, $request ,true ,$location_id);
        }else{
            $stockreportproducts = $this->getStockReportProducts($id, $request , false , $location_id);
            $opos_product = $this->getOposreceiptproducts($id, $request ,false ,$location_id);
        }
        $data = $stockreportproducts->merge($stockreportproducts)->map(function ($item){
            $item->table_name = class_basename($item);
            return $item;
        })->sortByDesc('updated_at');
        
        return view('industry.oil_gas.og_productledger_receipt',
            compact('id', 'product','opos_product','stockreportproducts', 'data'));
    }

    public function stockinproduct(Request $request){
        $location_ID = $request->id;
        
        $this->user_data = new UserData();
	
        $ids = merchantproduct::where('merchant_id',
            $this->user_data->company_id())->	
            pluck('product_id');
        $filtered_ids = array();
        foreach ($ids as $id) {
            if (product::where('name','<>',null)->find($id)) {
                $filtered_ids[] = $id;
            }
        }
        
        //dd($filtered_ids);

		$data = array();
            
        $model = new OgFuel();

        $data = $model->whereIn('product_id', $filtered_ids)->
            with('product_name', 'og_fuel_price')->
            orderBy('created_at', 'asc')->
            latest()->get();	

		return Datatables::of($data)->addIndexColumn()->
			addColumn('inven_pro_id', function ($memberList) {
				return $memberList->product_name->systemid;
				//return '<p data-field="og_product_id" style="cursor: pointer; margin: 0; text-align: center;"'. 'class="os-linkcolor doc_id" url="' .route("inventory.showstockreport",$memberList->product_name->systemid) .'">' . $memberList->product_name->systemid .'</p>';
			})->
			addColumn('inven_pro_name', function ($oilgaslist) {
				if (!empty($oilgaslist->product_name->thumbnail_1)) {
					$img_src = '/images/product/' . $oilgaslist->product_name->id . '/thumb/' . $oilgaslist->product_name->thumbnail_1;
					$img     = "<img src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'/>";
				} else {
					$img = "";
				}
				$txt = $img . '<p class="os-linkcolor" data-field="og_product_name" 
				style="cursor: pointer; margin: 0;display:inline-block" 
				onclick="details(' . $oilgaslist->product_name->systemid . ')">';
				$txt .= (!empty($oilgaslist->product_name->name)) ? $oilgaslist->product_name->name .' '  : 'Product Name';
				//$txt .= ($oilgaslist->og_fuel_price) ? ' (' . number_format($oilgaslist->og_fuel_price->price,  2) .')' : '---' . '</p>';
				return $txt;
			})->
			addColumn('inven_pro_colour', function ($memberList) {
			$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
				->where('productcolor.product_id', $memberList->product_id)->first();
			if ($product_color) {
				return $product_color->name;
			}
			return "-";
			})->
			addColumn('inven_pro_matrix', function ($memberList) {
				return '-';
			})->
			addColumn('inven_pro_rack', function ($memberList) {
			// if (count($memberList->rack) <= 0) {
			// 	return '-';
			// }
			return '<div style="cursor: pointer;"
				class="rack_list" id="' . $memberList->product_id . '" onclick="open_rack(' . $memberList->product_id . ',' . $memberList->first_product . ')">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';
			})->
			addColumn('inven_pro_existing_qty', function ($memberList) use ($location_ID) {
			   $lp = locationproduct::where(['location_id'=>$location_ID,'product_id'=>$memberList->product_id])->get()->first();
			 if($lp)
				 return  '<label value="'.$lp->quantity.'" id="existing_qty_'.$memberList->product_id.'">'.number_format($lp->quantity,2).'</label>';
				 else return '<label value="' . 0 . '" id="existing_qty_' . $memberList->product_id . '">0.00</label>';
			/*
				if($memberList->existing_qty == null)
					return 0;
				else
				return $memberList->system_id;
			*/
			})->
			addColumn('inven_pro_qty', function ($memberList) {
				return '<div class="value-button increase" id="increase_' . $memberList->product_id . '" onclick="increaseValue(' . $memberList->product_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
					</div><input type="number" id="number_' . $memberList->product_id . '"  class="number product_qty" value="0.00" step="0.01" min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->product_id . ')">
					<div class="value-button decrease" id="decrease_' . $memberList->product_id . '" onclick="decreaseValue(' . $memberList->product_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
					</div>';
			})->
			addColumn('inven_bluecrab', function ($memberList) {
				return '<p data-field="bluecrab"
						style="padding-top:1.4px;display:block;cursor: pointer;"
						class=" btn-primary bg-bluecrab"
						data-toggle="modal"><a class="os-linkcolor" href="barcodeinventoryout/' . $memberList->product_name->systemid . '/' . $memberList->product_name->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
			})->
		escapeColumns([])->
		make(true);
    }


    public function stockoutproduct(Request $request){
        
        $locationID = $request->id;
		$this->user_data = new UserData();
        $data = array();
	
        $ids = merchantproduct::where('merchant_id',
            $this->user_data->company_id())->	
            pluck('product_id');
            
        $filtered_ids = array();
        foreach ($ids as $id) {
            if (product::where('name','<>','')->find($id)) {
                $filtered_ids[] = $id;
            }
        }

        if ($locationID) {
            $nonEmptyQty = locationproduct::where(['location_id' => $locationID],['quatity','>',0])
			->whereIn('product_id', $filtered_ids)
			->pluck('product_id');
            //dd($nonEmptyQty);
            $model = new OgFuel();

            $data = $model->whereIn('product_id', $nonEmptyQty)->
                with('product_name', 'og_fuel_price')->
                orderBy('created_at', 'asc')->
                latest()->get();
        }

		return Datatables::of($data)->addIndexColumn()->
			addColumn('inven_pro_id', function ($memberList) {
				return $memberList->product_name->systemid;
				//return '<p data-field="og_product_id" style="cursor: pointer; margin: 0; text-align: center;"'. 'class="os-linkcolor doc_id" url="' .route("inventory.showstockreport",$memberList->product_name->systemid) .'">' . $memberList->product_name->systemid .'</p>';
			})->
			addColumn('inven_pro_name', function ($oilgaslist) {
				if (!empty($oilgaslist->product_name->thumbnail_1)) {
					$img_src = '/images/product/' . $oilgaslist->product_name->id . '/thumb/' . $oilgaslist->product_name->thumbnail_1;
					$img     = "<img src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'/>";
				} else {
					$img = "";
				}
				$txt = $img . '<p class="os-linkcolor" data-field="og_product_name" 
				style="cursor: pointer; margin: 0;display:inline-block" 
				onclick="details(' . $oilgaslist->product_name->systemid . ')">';
				$txt .= (!empty($oilgaslist->product_name->name)) ? $oilgaslist->product_name->name .' '  : 'Product Name';
				//$txt .= ($oilgaslist->og_fuel_price) ? ' (' . number_format($oilgaslist->og_fuel_price->price,  2) .')' : '---' . '</p>';
				return $txt;
			})->
			addColumn('inven_pro_colour', function ($memberList) {
			$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
				->where('productcolor.product_id', $memberList->product_id)->first();
			if ($product_color) {
				return $product_color->name;
			}
			return "-";
			})->
			addColumn('inven_pro_matrix', function ($memberList) {
				return '-';
			})->
			addColumn('inven_pro_rack', function ($memberList) {
			// if (count($memberList->rack) <= 0) {
			// 	return '-';
			// }
			return '<div style="cursor: pointer;"
					class="rack_list" id="' . $memberList->product_id . '" onclick="open_rack(' . $memberList->product_id . ',' . $memberList->first_product . ')">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';
		})->
			addColumn('inven_pro_existing_qty', function ($memberList)  use ($locationID)  {
				$lp = locationproduct::where(['location_id'=>$locationID,'product_id'=>$memberList->product_id])->get()->first();
				
				if($lp)
				 return '<label value="' . $lp->quantity . '" id="existing_qty_' . $memberList->product_id . '">'.number_format($lp->quantity,2).'</label>';
				else
				 return '<label value="' . 0 . '" id="existing_qty_' . $memberList->product_id . '">0.00</label>';
			})->
			addColumn('inven_pro_qty', function ($memberList) use ($locationID) {
				$lp = locationproduct::where(['location_id'=>$locationID,'product_id'=>$memberList->product_id])->get()->first();
				
				if($lp)
				return '<div class="value-button increase" id="increase_' . $memberList->product_id . '" onclick="increaseValue(' . $memberList->product_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
					</div><input type="number" id="number_' . $memberList->product_id . '"  class="number product_qty" value="0.00" step="0.01"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->product_id . ')">
					<div class="value-button decrease" id="decrease_' . $memberList->product_id . '" onclick="decreaseValue(' . $memberList->product_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
					</div>';
				else return '<div class="value-button increase" id="increaseddd_' . $memberList->product_id . '" onclick="increaseValue(' . $memberList->product_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
				</div><input type="number" id="number_' . $memberList->product_id . '"  class="number product_qty" value="0"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->product_id . ')"' . '"onchange="update_qty(' . $memberList->product_id . ')" disabled>
				<div class="value-button decrease" id="dddecrease_' . $memberList->product_id . '" onclick="decreaseValue(' . $memberList->product_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
				</div>';
			})->
			addColumn('inven_bluecrab', function ($memberList) {
				return '<p data-field="bluecrab"
						style="padding-top:1.4px;display:block;cursor: pointer;"
						class=" btn-primary bg-bluecrab"
						data-toggle="modal"><a class="os-linkcolor" href="barcodeinventoryout/' . $memberList->product_name->systemid . '/' . $memberList->product_name->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
			})->
		escapeColumns([])->
		make(true);

    }

	function showProductStockInView() {
		$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

		$location = DB::select('
        SELECT
            l.branch,
            l.created_at,
            l.id,
            c.name
        FROM 
            company c,
            merchant m,
            location l,
            merchantlocation ml
        WHERE
            c.owner_user_id = '.$id.'
            AND m.company_id = c.id
            AND ml.merchant_id = m.id
            AND ml.location_id = l.id
            AND l.branch is NOT NULL
            AND l.deleted_at is NULL;
       
        ');

        $data = array();
		$this->user_data = new UserData();
			$model = new OgFuel();
	
			$ids = merchantproduct::where('merchant_id',
				$this->user_data->company_id())->	
				pluck('product_id');
	
			/*
			$ids = product::where('ptype', 'oilgas')->
				whereIn('id', $ids)->pluck('id');
			*/
	
			$data = $model->whereIn('product_id', $ids)->
				orderBy('created_at', 'asc')->
				latest()->get();

				// foreach ($data as $key => $value) {
				// 	$data[$key]['transaction'] = $this->check_transaction($value->product_id);
				// 	$data[$key]['price'] = $this->get_execute_price($value->id);
				// }		
		
			
			 Datatables::of($data)
				->addIndexColumn()->
				addColumn('inven_pro_id', function ($memberList) {
					return $memberList->product_name->systemid;
				})->
				addColumn('inven_pro_name', function ($oilgaslist) {
					if (!empty($oilgaslist->product_name->thumbnail_1)) {
						$img_src = '/images/product/' . $oilgaslist->product_name->id . '/thumb/' . $oilgaslist->product_name->thumbnail_1;
						$img     = "<img src='$img_src' data-field='og_product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'/>";
					} else {
						$img = "";
					}
					return $img . '<p class="os-linkcolor" data-field="og_product_name" style="cursor: pointer; margin: 0;display:inline-block" onclick="details(' . $oilgaslist->product_name->systemid . ')">' . (!empty($oilgaslist->product_name->name) ? $oilgaslist->product_name->name : 'Product Name') . '</p>';
				})->
			 addColumn('inven_pro_colour', function ($memberList) {
				$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
					->where('productcolor.product_id', $memberList->product_id)->first();
				if ($product_color) {
					return $product_color->name;
				}
				return "-";
			})->
			addColumn('inven_pro_matrix', function ($memberList) {
				return '-';
			})->
			addColumn('inven_pro_rack', function ($memberList) {
				// if (count($memberList->rack) <= 0) {
				// 	return '-';
				// }
				return '<div style="cursor: pointer;"
                        class="rack_list" id="' . $memberList->product_id . '" onclick="open_rack(' . $memberList->product_id . ',' . $memberList->first_product . ')">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';
			})->
			 	addColumn('inven_pro_existing_qty', function ($memberList) {
					// if($memberList->existing_qty == null)
					// 	return 0;
					// else
					return $memberList->system_id;
	
				})->
				addColumn('inven_pro_qty', function ($memberList) {
					return '<div class="value-button increase" id="increase_' . $memberList->product_id . '" onclick="increaseValue(' . $memberList->product_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
						</div><input type="number" id="number_' . $memberList->product_id . '"  class="number product_qty" value="0"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->product_id . ')">
						<div class="value-button decrease" id="decrease_' . $memberList->product_id . '" onclick="decreaseValue(' . $memberList->product_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
						</div>';
				})->
				addColumn('inven_bluecrab', function ($memberList) {
					return '<p data-field="bluecrab"
							style="padding-top:1.4px;display:block;cursor: pointer;"
							class=" btn-primary bg-bluecrab"
							data-toggle="modal"><a class="os-linkcolor" href="barcodeinventoryout/' . $memberList->product_name->systemid . '/' . $memberList->product_name->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
				})->
			escapeColumns([])->
            make(true);
            
        return view('industry.oil_gas.og_productstockin', [
			'user_roles'=>$user_roles,
			'is_king'=>$is_king,
			'location'=>$location
		]);
    }
 

    function showProductStockOutView() {
//        $product = OgFuel::where('id', $id)->first();
        $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
        
        $location = DB::select('
        SELECT
            l.branch,
            l.created_at,
            l.id,
            c.name
        FROM 
            company c,
            merchant m,
            location l,
            merchantlocation ml
        WHERE
            c.owner_user_id = '.$id.'
            AND m.company_id = c.id
            AND ml.merchant_id = m.id
            AND ml.location_id = l.id
            AND l.branch is NOT NULL
            AND l.deleted_at is  NULL;

        ');
  
		return view('industry.oil_gas.og_productstockout', [
			'location'=>$location,
			'user_roles'=>$user_roles,
			'is_king'=>$is_king
		]);
    }


    public function store(Request $request)
    {
        //Create a new product here
        try {
            $this->user_data = new UserData();
            $merchantproduct = new merchantproduct();
            $SystemID        = new SystemID('product');
            $product         = new product();

            $product->systemid = $SystemID;
            $product->ptype    = 'oilgas';
            $product->save();

            $oilgas             = new OgFuel();
            $oilgas->product_id = $product->id;
            $oilgas->save();

            $merchantproduct->product_id  = $product->id;
            $merchantproduct->merchant_id = $this->user_data->company_id();
            $merchantproduct->save();

            $msg = "Product added successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }
    }    
    

    public function showEditModal(Request $request)
    {
      
        try {
            $allInputs = $request->all();
            $id        = $request->get('id');
            $fieldName = $request->get('field_name');
           // dd($allInputs);

            $validation = Validator::make($allInputs, [
                'id'         => 'required',
                'field_name' => 'required',
            ]);

            if ($validation->fails()) {
                $response = (new ApiMessageController())->
                    validatemessage($validation->errors()->first());

            } else {

                $oilgas = OgFuel::where('id', $id)->first();
                // dd($oilgas);
                return view('industry.oil_gas.og_oilgas-modals', compact(['id', 'fieldName', 'oilgas']));
                // dd($request);
            }

        } catch (\Illuminate\Database\QueryException $ex) {
            $response = (new ApiMessageController())->queryexception($ex);
        }
    }


    public function update(Request $request)
    {
        try {
            $allInputs = $request->all();
            $og_product_id       = $request->get('og_product_id');
            $changed = false;

            $validation = Validator::make($allInputs, [
                'og_product_id'         => 'required',
            ]);

            if ($validation->fails()) {
                throw new Exception("product_not_found", 1);
            }

             $oilgas = OgFuel::find($og_product_id);

             if (!$oilgas) {
                throw new Exception("product_not_found", 1);
            }

            if ($request->has('litre')) {

                if ($oilgas->litre != (int) str_replace('.','',$request->litre)) {
                    $oilgas->litre = (int) str_replace('.','',$request->litre);
                    $changed = true;
                    $msg = "Litre updated";
                }
            }

            if ($changed == true) {
                $oilgas->save();
                $response = view('layouts.dialog', compact('msg'));
            } else {
                $response  = null;
            }

        }  catch (\Exception $e) {
			$msg = $e->getMessage();
            if ($msg == 'product_not_found') {
                $msg = "Product not found";
            } else if ($msg == 'invalid_cost') {
                $msg = "Invalid cost";
            } 

            // $msg = $e;
            $response = view('layouts.dialog', compact('msg'));
        }

        return $response;
    }

    public function destroy($id)
    {
        try {
            $this->user_data = new UserData();
            $oilgas          = OgFuel::find($id);
			
            $product_id      = $oilgas->product_id;

            $is_exist = merchantproduct::where([
				'product_id' => $product_id,
				'merchant_id' => $this->user_data->company_id()
			])->first();

            if (!$is_exist) {
                throw new Exception("Error Processing Request", 1);
            }

            $is_exist->delete();
            product::find($product_id)->delete();
            $oilgas->delete();

            $msg = "Product deleted successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Illuminate\Database\QueryException $e) {
            $msg = $e->getMessage();

            return view('layouts.dialog', compact('msg'));
        }
    }
	
	public function showFuelPrices(Request $request)
    {
		$this->user_data = new UserData();
        $model = new OgFuelPrice();
		$og_fuel_id       = $request->get('ogFuelId');
		
        $data = $model->where('ogfuel_id', $og_fuel_id)->
			orderBy('created_at', 'desc')->
            latest()->get();
		
		$checkFuel = $model->where('ogfuel_id', $og_fuel_id)->
			orderBy('id', 'desc')->
            first();
			
		$enableButton = true;
		if(!empty($checkFuel->start) && !empty($checkFuel->price)){
			$enableButton = false;
		}
		foreach ($data as $key => $value) {
			$data[$key]['username'] = $value->user_name->name;
			$data[$key]['enableButton'] = $enableButton;
		}
		$myJSON = json_encode($data); 
		return $myJSON;	
	}

    public function storeFuel(Request $request){
        try {
            $og_fuelManage = new OgFuelMovement();

            if (empty($request->fuel_prod_id)) {
                $msg = "Please select a fuel";
                return view('layouts.dialog', compact('msg'));
                return false;
            }

            if (empty($request->location_id)) {
                $msg = "Please select a location";
                return view('layouts.dialog', compact('msg'));
                return false;
            }

            $og_fuelManage->location_id = $request->location_id;
            $og_fuelManage->fuel_prod_id = $request->fuel_prod_id;
            $og_fuelManage->date = date('Y-m-d H:i:s');
            $og_fuelManage->cforward = $request->cforward;
            $og_fuelManage->sales = "";
            $og_fuelManage->receipt = "";
            $og_fuelManage->book = "";
            $og_fuelManage->tank_dip = "";
            $og_fuelManage->daily_variance = "";
            $og_fuelManage->cumulative = "";
            $og_fuelManage->percentage = "";
            $og_fuelManage->save();

            $msg = "Fuel added successfully";
            return view('layouts.dialog', compact('msg'));

            //return $request->location_id."-".$request->fuel_prod_id."-".$request->cforward;

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }

    }    

    private function StockInCarryForward($location_id ,  $product_id , $cforward){

                $stock_system = DB::select("select nextval(stockreport_seq) as index_stock");
                $stock_system_id = $stock_system[0]->index_stock;
                $stock_system_id = sprintf("%010s", $stock_system_id);
                $stock_system_id = '111' . $stock_system_id;

                // $locationproduct = locationproduct::where(['location_id' => $location_id, 'product_id' => $product_id ])->orderby('id', 'desc')->first();
                // //dd($value['qty']);
                // if ($locationproduct) { // modify existing location product
                //     $curr_qty = $locationproduct->quantity;
                //     $curr_qty += $cforward;
                //     $locationproduct->quantity = $curr_qty;
                //     $locationproduct->save();
                // } else { // save new location productvalue['product_id']
                //     $product = new locationproduct();
                //     $product->product_id = $product_id;
                //     $product->location_id = $location_id;
                //     $product->quantity = $cforward;
                //     $product->save();
                // }
                // $og_fuel_mov = OgFuelMovement::where(['location_id'=>$location_id,'ogfuel_id'=> $product_id])->get()->first();
                // if($og_fuel_mov){ 
                //     $og_fuel_mov->receipt += $cforward;
                //     $og_fuel_mov->book = ($og_fuel_mov->cforward - $og_fuel_mov->sales) + $og_fuel_mov->receipt;
                //     $og_fuel_mov->date = now();
                //     $og_fuel_mov->save();
                // } else {
                //     OgFuelMovement::create([
                //         'location_id' => $location_id,
                //         'ogfuel_id' => $product_id,
                //         'receipt' => $cforward,
                //         'date'  => now()
                //     ]);
                // }
                /* saving stockreport  &&  stockreportproduct */

                $stock = new StockReport();
                $stock->creator_user_id = Auth::user()->id;
                $stock->type = 'cforward';
                $stock->systemid = $stock_system_id;
                $stock->quantity =  $cforward;
                $stock->product_id = $product_id;
                $stock->status = 'confirmed';
                $stock->location_id = $location_id;
                $stock->save();

                /* saving stockreport  &&  stockreportproduct */
                $stockreportproduct = new stockreportproduct();
                $stockreportproduct->quantity =$cforward;
                $stockreportproduct->stockreport_id = $stock->id;
                $stockreportproduct->product_id = $product_id;
                $stockreportproduct->status = 'confirmed';
                $stockreportproduct->save();
                return 1;
                /* ------------------------------------- */
    }
    
    public function storeFuelMovement(Request $request){
        try {    
			// This is actually product_id
            if (empty($request->fuel_prod_id)) {
                $msg = "Please select a fuel";
                return view('layouts.dialog', compact('msg'));
                return false;
            }
            if (empty($request->location_id)) {
                $msg = "Please select a location";
                return view('layouts.dialog', compact('msg'));
                return false;
            }
            $current_day = date('Y-m-d');

            /*added by Udemezue  for selecting the actual value of ogfuel_id*/
            $og_fuel = Ogfuel::where("product_id",
				$request->fuel_prod_id)->first();

            $og_fuel_id = $og_fuel ? $og_fuel->id : '';

            // selecting this day's fuel movement
            $og_fuelManage = OgFuelMovement::where([
                    ['ogfuel_id' , $og_fuel_id],
                    ['location_id' , $request->location_id]
                ])->whereBetween('updated_at', [
					date($current_day. ' 00:00:00'),
					date($current_day.' 23:59:59')
				])->orderBy('updated_at','DESC')->
				get()->first();

            if($og_fuelManage){
                $number='';
                $data = explode(',' , $request->cforward);
                for($i=0; $i<count($data); $i++){
                    $number=$number.''.$data[$i];
                }
                $cf_converted = (float)$number;
                $sales = $this->_getFuelSales($request->fuel_prod_id,
					Carbon::parse($og_fuelManage->date)->format('Y-m-d'));

                $receipt = $this->_getFuelReceipt($request->fuel_prod_id,
					Carbon::parse($og_fuelManage->date)->format('Y-m-d'));

                $book = $this->_getFuelBook($cf_converted, $sales , $receipt);

                if ($request->tank_dip) {
                    // Modify tank dip of selected fuel movementog_fuelManage
					$og_fuelManage->tank_dip = $request->tank_dip;
					$og_fuelManage->daily_variance =
						($og_fuelManage->tank_dip - $book);
					$og_fuelManage->book = $book;
					$og_fuelManage->save();
                } else {
                    // modify c/forward
                    $cf_converted = (float)$request->cforward * 1000;
                    $og_fuelManage->date = date('Y-m-d H:i:s');
                    $og_fuelManage->cforward = $cf_converted;
                    $og_fuelManage->sales = $sales; 
                    $og_fuelManage->receipt = $receipt;
                    $og_fuelManage->book = $book;
                    $og_fuelManage->save();
                }
                
                $variance =$this->_variance($og_fuelManage->ogfuel_id ,
					$og_fuelManage->location_id);
                $percentage =$this->_percentage($og_fuelManage->ogfuel_id,
					$og_fuelManage->location_id);
                $og_fuelManage->cumulative = $variance;
                $og_fuelManage->percentage = $percentage;
                $og_fuelManage->update();
            } else {
                $cf_converted = (float)$request->cforward;
                // create new fuel movement for the first time
                // $sales = $this->_getFuelSales($request->fuel_prod_id, date('Y-m-d'));
                // $receipt = $this->_getFuelReceipt($request->fuel_prod_id, date('Y-m-d'));
                // $book = $this->_getFuelBook($cf_converted, $sales , $receipt);
            ///  changes here
                // OgFuelMovement::create([
                //     'location_id'   => $request->location_id,
                //     'ogfuel_id'     => $request->fuel_prod_id,
                //     'date'          => date('Y-m-d H:i:s'),
                //     'cforward'      => $cf_converted,
                //     'sales'         => $sales,
                //     'receipt'       => $receipt,
                //     'book'          => $cf_converted,
                // ]);
                
                OgFuelMovement::create([
                    'location_id'   => $request->location_id,
                    'ogfuel_id'     => $og_fuel_id,
                    'date'          => date('Y-m-d H:i:s'),
                    'cforward'      => $cf_converted,
                    'sales'         => 0.00,
                    'receipt'       => 0.00,
                    'book'          => $cf_converted,
                ]);

                /* 
                    This block was added by Udemezue.
                    what it actually does is to create a initial start stock
					in locationproduct
                */
                locationproduct::create([
                    'location_id' => $request->location_id,
                    'product_id' => $request->fuel_prod_id,
                    'quantity' => $request->cforward,
                ]);
            }
            
            if(isset($request->tank_dip) && $request->tank_dip == 0){
                $this->StockInCarryForward($request->location_id ,
					$request->fuel_prod_id , $request->cforward);
            }

            $msg = "Fuel added successfully";
            return view('layouts.dialog', compact('msg'));

            //return $request->location_id."-".$request->fuel_prod_id."-".$request->cforward;

        } catch (\Exception $e) {
            $msg = $e->getMessage();
            return view('layouts.dialog', compact('msg'));
        }
    }


    public function _variance($fuel_id , $location_id){
        $og_fuelManage = OgFuelMovement::where([
                            ['ogfuel_id' , $fuel_id],
                            ['location_id' , $location_id]
                        ])
                        ->orderBy('updated_at','desc')->get();
        $variance =0;
        foreach($og_fuelManage as $row){
            $variance = $row->daily_variance + $variance;
        }
        return $variance;
    }

    public function _percentage($fuel_id , $location_id){
        $og_fuelManage = OgFuelMovement::where([
                            ['ogfuel_id' , $fuel_id],
                            ['location_id' , $location_id]
                        ])->orderBy('updated_at','desc')->get();
        $book=0;
        foreach($og_fuelManage as $row){
            $book =$book + $row->book;
        }
        
        $end = end($og_fuelManage);
        $percentage = $book == 0 ? 0 : $end[0]->daily_variance/($book)*100;
        return $percentage;
    }




    function _getFuelSales($product_id , $date){
        $sold_products = opos_receiptproduct::where([['product_id',$product_id]])
                ->whereBetween('updated_at', [date($date. ' 00:00:00'), date($date.' 23:59:59')])
                ->pluck('quantity');
        $sales = 0;
        foreach ($sold_products as $key => $value) {
            $sales += (float)$value;
        }
        return $sales;
    }

    
    function _getFuelReceipt($product_id , $date){
        $loc_product = stockreportproduct::select('stockreportproduct.quantity')
            ->join('stockreport' ,'stockreportproduct.stockreport_id','stockreport.id')
             ->where([['stockreportproduct.product_id',$product_id]])
             ->where('stockreport.type','!=','cforward')
            ->whereBetween('stockreportproduct.updated_at', [date($date. ' 00:00:00'), date($date.' 23:59:59')])->get();
        $receipt = 0;
        foreach ($loc_product as $value) {
            $receipt += (float)$value->quantity;
        }
        return $receipt;


    }

    function _getFuelBook($cforward, $sales , $receipt) {
        return (($cforward - $sales) + $receipt);
    }


    public function storeFuelPrices(Request $request)
    {
        //Create a new product here
        try {
            $this->user_data = new UserData();
			$og_fuel_id       = $request->get('ogFuelPriceId');
			
            $merchantproduct = new merchantproduct();
			//$SystemID        = new SystemID('product');

            $ogFuelPrice            = new OgFuelPrice();
            $ogFuelPrice->ogfuel_id = $og_fuel_id;
            $ogFuelPrice->user_id = Auth()->user()->id;
            $tomorrow = date("Y-m-d", strtotime("+ 1 day"));
            $tomorrow = date_create($tomorrow);
            $tomorrow = date_format($tomorrow, 'Y-m-d 00:00:01');
            $ogFuelPrice->start = $tomorrow;
            $ogFuelPrice->save();

            $msg = "Product added successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e;
            return view('layouts.dialog', compact('msg'));
        }
    }
	
	public function updateFuelPrices(Request $request)
    {
        //Create a new product here
        try {
            $this->user_data = new UserData();
			$og_fuel_id       = $request->get('ogFuelPriceId');
            $price       = 		(int)str_replace(',', '',str_replace('.', '',number_format($request->get('ogFuelPrice'), 2)));
								
            $ogFuelPrice = OgFuelPrice::find($og_fuel_id);
			
			$ogFuelPrice->price = $price;
            $ogFuelPrice->save();
			$msg = "Price updated successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e;
            return view('layouts.dialog', compact('msg'));
        }
    }
	
	public function updateStartDateFuelPrices(Request $request)
    {
        //Create a new product here
        try {
            $this->user_data = new UserData();
			$og_fuel_id       = $request->get('ogFuelPriceId');
            $startDate       = $request->get('startDate');
            $ogFuelPrice = OgFuelPrice::find($og_fuel_id);
			
			$date = date_create($startDate);
			$date = date_format($date, 'Y-m-d 00:00:01');
			$ogFuelPrice->start = $date;
            $ogFuelPrice->save();
			$msg = "Start updated successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Exception $e) {
            $msg = $e;
            return view('layouts.dialog', compact('msg'));
        }
    }


    public function showFuelManagement_tables(Request $request){

        $location_ID = $request->locID;
        //$ogfuel_id = $request->ogfuel_id;

        /*added by Udemezue  for selecting the actual value of ogfuel_id*/
        $og_fuel = Ogfuel::where("product_id", $request->ogfuel_id)->first();
        $og_fuel_id = $og_fuel ? $og_fuel->id : '';
        
        if(!empty($location_ID) && !empty($og_fuel_id)){
            $model = OgFuelMovement::where([['location_id',$location_ID],['ogfuel_id',$og_fuel_id]])
                                    ->orderBy('updated_at','desc')->get();
            $latest =  $model->first();
            if($latest){
                $latest->daily_variance = ($latest->tank_dip - $latest->book);
                $latest->cumulative = $this->_variance($latest->ogfuel_id, $latest->location_id);
                $latest->percentage = $this->_percentage($latest->ogfuel_id, $latest->location_id);
                $latest->update();
            }

            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('date', function ($fuel_list) {
                    return '<p  id="fuel_date" style="margin: 0; text-align: center;">' . Carbon::parse($fuel_list->date)->format('dMy H:i:s') . '</p>';
                })
                ->addColumn('cforward', function ($fuel_list) {
                    return '<p  id="fuel_cforward" style="margin: 0; text-align: right;" value="'.number_format($fuel_list->cforward,2).'">' . number_format($fuel_list->cforward,2).'</p>';
                })
                ->addColumn('sales', function ($fuel_list) {
                    $og_fuel = OgFuel::where("id", $fuel_list->ogfuel_id)->first();
                    return '<p id="fuel_receipt" class="os-linkcolor fuel_receipt" data-field="' .( (!empty($fuel_list->sales) && $fuel_list->sales == 0 ) ? $fuel_list->sales : "" ). '" url="' .route("get_industry_oil_gas_product_ledger_index_view_sales",['oilgas_product_id' => $og_fuel->product_id, 'location_id' => $fuel_list->location_id]) . '" day="' .Carbon::parse($fuel_list->date)->format('Y-m-d') . '" style="cursor: pointer; margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->sales,2) .'</p>';
                })
                ->addColumn('receipt', function ($fuel_list) {
                    $og_fuel = OgFuel::where("id", $fuel_list->ogfuel_id)->first();
                    return '<p id="fuel_receipt" class="os-linkcolor fuel_receipt" data-field="' .( (!empty($fuel_list->receipt) && $fuel_list->receipt == 0 ) ? $fuel_list->receipt : "" ). '" url="' .route("get_industry_oil_gas_product_ledger_index_view_receipt",['oilgas_product_id' => $og_fuel->product_id , 'location_id' => $fuel_list->location_id]) . '" day="' .Carbon::parse($fuel_list->date)->format('Y-m-d') . '" style="cursor: pointer;margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->receipt,2) .'</p>';
                })
                ->addColumn('book', function ($fuel_list) {
                    return '<p id="fuel_book" data-field="' .( (!empty($fuel_list->book) && $fuel_list->book == 0 ) ? $fuel_list->book : "" ). '"  style="margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->book,2) .'</p>';
                })
                ->addColumn('tank_dip', function ($fuel_list) {
                    return '<p id="fuel_tankDIp" data-field="' .( (!empty($fuel_list->tank_dip) && $fuel_list->tank_dip == 0 ) ? $fuel_list->tank_dip : "" ). '" style="margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->tank_dip,2).'</p>';
                })
                ->addColumn('daily_variance', function ($fuel_list) {
                    return '<p id="fuel_dailyVariance" data-field="' .( (!empty($fuel_list->daily_variance) && $fuel_list->daily_variance == 0 ) ? $fuel_list->daily_variance : "" ). '"  style="margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->daily_variance,2) .'</p>';
                })
                ->addColumn('cumulative', function ($fuel_list) {
                    return '<p id="fuel_cumulative" data-field="' .( (!empty($fuel_list->cumulative) && $fuel_list->cumulative == 0 ) ? $fuel_list->cumulative : "" ). '"  style="margin:0;float:right; text-align:center;" >'.number_format($fuel_list->cumulative,2).'</p>';
                })
                ->addColumn('percentage', function ($fuel_list) {
                    return '<p id="fuel_cumulative" data-field="' .( (!empty($fuel_list->percentage) && $fuel_list->percentage == 0 ) ? $fuel_list->percentage : "" ). '"  style="margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->percentage,2) .'</p>';
                })
                ->escapeColumns([])->
                make(true);
        }/*else{
            $model = OgFuelMovement::all();
            return Datatables::of($model)
                ->addIndexColumn()
                ->addColumn('date', function ($fuel_list) {
                    return '<p class="os-linkcolor" id="fuel_date" style="cursor: pointer; margin: 0; text-align: center;">' . Carbon::parse($fuel_list->date)->format('dMy H:i:s') . '</p>';
                })
                ->addColumn('cforward', function ($fuel_list) {
                    return '<p  id="fuel_cforward" style="margin: 0; text-align: right;">' .number_format($fuel_list->cforward,2) . '</p>';
                })
                ->addColumn('sales', function ($fuel_list) {
                    return '<p id="fuel_receipt" class="os-linkcolor" data-field="' .( (!empty($fuel_list->sales) && $fuel_list->sales == 0 ) ? $fuel_list->sales : "" ). '" style="cursor: pointer; margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->sales,2) .'</p>';
                })
                ->addColumn('receipt', function ($fuel_list) {
                    return '<p id="fuel_receipt" class="os-linkcolor fuel_receipt" data-field="' .( (!empty($fuel_list->receipt) && $fuel_list->receipt == 0 ) ? $fuel_list->receipt : "" ). '" url="' .route("get_industry_oil_gas_product_ledger_index_view",$fuel_list->ogfuel_id) . '" day="' .Carbon::parse($fuel_list->date)->format('Y-m-d') . '" style="cursor: pointer; margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->receipt,2).'</p>';
                })
                ->addColumn('book', function ($fuel_list) {
                    return '<p id="fuel_book" class="os-linkcolor" data-field="' .( (!empty($fuel_list->book) && $fuel_list->book == 0 ) ? $fuel_list->book : "" ). '"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->book,2) .'</p>';
                })
                ->addColumn('tank_dip', function ($fuel_list) {
                    return '<p id="fuel_tankDIp" class="os-linkcolor" data-field="' .( (!empty($fuel_list->tank_dip) && $fuel_list->tank_dip == 0 ) ? $fuel_list->tank_dip : "" ). '" style="cursor: pointer; margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->tank_dip,2).'</p>';
                })
                ->addColumn('daily_variance', function ($fuel_list) {
                    return '<p id="fuel_dailyVariance" class="os-linkcolor" data-field="' .( (!empty($fuel_list->daily_variance) && $fuel_list->daily_variance == 0 ) ? $fuel_list->daily_variance : "" ). '"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >'. number_format($fuel_list->daily_variance,2) .'</p>';
                })
                ->addColumn('cumulative', function ($fuel_list) {
                    return '<p id="fuel_cumulative" class="os-linkcolor" data-field="' .( (!empty($fuel_list->cumulative) && $fuel_list->cumulative == 0 ) ? $fuel_list->cumulative : "" ). '"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->cumulative,2).'</p>';
                })
                ->addColumn('percentage', function ($fuel_list) {
                    return '<p id="fuel_cumulative" class="os-linkcolor" data-field="' .( (!empty($fuel_list->percentage) && $fuel_list->percentage == 0 ) ? $fuel_list->percentage : "" ). '"  style="cursor: pointer; margin: 0;float:right; text-align:center;" >'.number_format($fuel_list->percentage,2) .'</p>';
                })
                ->escapeColumns([])->
                make(true);
        
        }*/
        return Datatables::of(array())->make(true);
    }


    public function showFuelManagement(){
        $date= Company::select(DB::raw('EXTRACT(MONTH FROM created_at) as \'month\', EXTRACT(YEAR FROM created_at) as \'year\''))->where('owner_user_id','=',Auth::user()->id)->get()->first();
        return view('industry.oil_gas.og_fuel-management',compact(['date']));
    }
	
	public function showOgProduct(){
        return view('industry.oil_gas.og_product');
    }
    
    public function showEditModalFuelPrice(Request $request)
    {
        
        try {
            $allInputs = $request->all();
            $id        = $request->get('id');
            $fieldName = $request->get('field_name');
            $oilgas = OgFuelPrice::where('id', $id)->first();
            return view('industry.oil_gas.og_fuelprice-modals', compact(['id', 'fieldName', 'oilgas']));
            

        } catch (\Illuminate\Database\QueryException $ex) {
            $response = (new ApiMessageController())->queryexception($ex);
        }
    }
    
    
    public function destroyFuelprice($id)
    {
        try {
            $this->user_data = new UserData();
            $oilgas          = OgFuelPrice::find($id);
            $oilgas->delete();

            $msg = "Fuel price deleted successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Illuminate\Database\QueryException $ex) {
            $msg = "Some error occured";

            return view('layouts.dialog', compact('msg'));
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function destroyTank(Request $request)
    {
        try {
            $this->user_data = new UserData();
            $og_tank_id       = $request->get('TankID');

            $ogTankHeight = OgTank::where('systemid',$og_tank_id)->first();

            $ogTankHeight->deleted_at = Carbon::now();
            $ogTankHeight->save();

            $msg = "Tank deleted successfully";
            return view('layouts.dialog', compact('msg'));
//            return view('layouts.dialog')->with(['msg'=>$msg]);

        } catch (\Exception $e) {
            $msg = $e;
            return view('layouts.dialog', compact('msg'));
//            return view('layouts.dialog')->with(['msg'=>$msg]);
        }
    }


    public function updateProductQuantitystock(Request $request)
	{
	
		try {
			$id = Auth::user()->id;
		
            $table_data = $request->get('table_data');
            
			$stock_type = $request->get('stock_type');
            $total_qty = 0;
            
            $stock_system = DB::select("select nextval(stockreport_seq) as index_stock");
			$stock_system_id = $stock_system[0]->index_stock;
			$stock_system_id = sprintf("%010s", $stock_system_id);
			$stock_system_id = '111' . $stock_system_id;
			/**/
			foreach ($table_data as $key => $value) {
				if ($value['qty'] <= 0) {
					continue;
				}
				$locationproduct = locationproduct::where(['location_id' => $value['location_id'], 'product_id' => $value['product_id']])->orderby('id', 'desc')->first();
                //dd($value['qty']);
                if ($locationproduct) { // modify existing location product
					$curr_qty = $locationproduct->quantity;
					if ($stock_type == "IN") {
                        $curr_qty += $value['qty'];
                        
					} else {
						$curr_qty -= $value['qty'];
                    }
                    $locationproduct->quantity = $curr_qty;
                    $locationproduct->save();
				} else { // save new location product
                    
                    $product = new locationproduct();

                    $product->product_id = $value['product_id'];
                    $product->location_id = $value['location_id'];
                    $product->quantity = $value['qty'];
                    $product->save();
                }

                /*added by Udemezue  for selecting the actual value of ogfuel_id*/
                $og_fuel = Ogfuel::where("product_id", $value['product_id'])->first();
                $og_fuel_id = $og_fuel ? $og_fuel->id : '';

                /*$og_fuel_mov = OgFuelMovement::where(['location_id'=>$value['location_id'],'ogfuel_id'=>$og_fuel_id])->get()->first();*/

                $current_day = date('Y-m-d');
                $og_fuel_mov = OgFuelMovement::where(['location_id'=>$value['location_id'],'ogfuel_id'=>$og_fuel_id])->whereBetween('updated_at', [date($current_day. ' 00:00:00'), date($current_day.' 23:59:59')])
                    ->orderBy('updated_at','DESC')->get()->first();


                if($og_fuel_mov){ 
                    if ($stock_type == "IN") {
                        $og_fuel_mov->receipt += $value['qty'];
					} else {
                        $og_fuel_mov->receipt -= $value['qty'];

                    }
                    $og_fuel_mov->book = ($og_fuel_mov->cforward - $og_fuel_mov->sales) + $og_fuel_mov->receipt;

                    $og_fuel_mov->daily_variance = $og_fuel_mov->tank_dip - $og_fuel_mov->book;

                    $og_fuel_mov->date = now();

                    /*added by Udemezue this file trigers variance and percentage when SISO happens*/

                    $variance =$this->_variance($og_fuel_mov->ogfuel_id , $og_fuel_mov->location_id);
                    $percentage =$this->_percentage($og_fuel_mov->ogfuel_id , $og_fuel_mov->location_id);
                    $og_fuel_mov->cumulative = $variance;
                    $og_fuel_mov->percentage = $percentage;


                    $og_fuel_mov->update();
                } else {
                    OgFuelMovement::create([
                        'location_id' => $value['location_id'],
                        'ogfuel_id' => $og_fuel_id,
                        'receipt' => $value['qty'],
                        'date'  => now()
                    ]);
                }
                /* saving stockreport  &&  stockreportproduct */

                $stock = new StockReport();
                $stock->creator_user_id = Auth::user()->id;
                $stock->type = ($stock_type == 'IN') ? 3 : 4; //('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
                $stock->systemid = $stock_system_id;
                $stock->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
                $stock->product_id = $value['product_id'];
                $stock->status = 'confirmed';
                $stock->location_id = $value['location_id'];
                $stock->save();

                /* saving stockreport  &&  stockreportproduct */
				$stockreportproduct = new stockreportproduct();
				$stockreportproduct->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
				$stockreportproduct->stockreport_id = $stock->id;
				$stockreportproduct->product_id = $value['product_id'];
				$stock->status = 'confirmed';
                $stockreportproduct->save();
                /* ------------------------------------- */

                $total_qty += $value['qty'];
			}
			if ($total_qty > 0) {
				if ($stock_type == "IN") {
					$msg = "Stock In performed succesfully";
				} else {
					$msg = "Stock Out performed succesfully";
				}
			} else {
				$msg = "Please fill in product quantity";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
		dd($e);
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
    }

    public function updateLocationProduct(Request $request){
        try{
            $id =Auth::user()->id;

            $table_data = $request->get('table_data');
            $stock_type = $request->get('stock_type');

            $product_id = $table_data[0]['product_id'];
            $location_id = $table_data[0]['location_id'];
            $quantity = $table_data[0]['qty'];

            if ($quantity > 0) {
                $current_location_product = locationproduct::orderBy("id", "desc")->where('product_id', $product_id)->where('location_id', $location_id)->first();

                if($current_location_product){
                    $current_location_product->update([
                        'quantity' => $current_location_product->quantity + $quantity,
                    ]);
                }
                else{
                    locationproduct::create([
                        'product_id' => $product_id,
                        'location_id' => $location_id,
                        'quantity' => $quantity,
                    ]);
                }

                /*added by Udemezue  for selecting the actual value of ogfuel_id*/
                $og_fuel = Ogfuel::where("product_id", $product_id)->first();
                $og_fuel_id = $og_fuel ? $og_fuel->id : '';
                
                /*$og_fuel_mov = OgFuelMovement::where(['location_id'=>$location_id,'ogfuel_id'=>$og_fuel_id])->get()->first();
*/
                $current_day = date('Y-m-d');
                $og_fuel_mov = OgFuelMovement::where(['location_id'=>$location_id,'ogfuel_id'=>$og_fuel_id])->whereBetween('updated_at', [date($current_day. ' 00:00:00'), date($current_day.' 23:59:59')])
                    ->orderBy('updated_at','DESC')->get()->first();


                if($og_fuel_mov){
                    $og_fuel_mov->book = ($og_fuel_mov->cforward - $og_fuel_mov->sales) + $og_fuel_mov->receipt;

                    $og_fuel_mov->daily_variance = $og_fuel_mov->tank_dip - $og_fuel_mov->book;

                    $og_fuel_mov->date = now();

                    /*added by Udemezue this file trigers variance and percentage when SISO happens*/
                    $variance =$this->_variance($og_fuel_mov->ogfuel_id , $og_fuel_mov->location_id);
                    $percentage =$this->_percentage($og_fuel_mov->ogfuel_id , $og_fuel_mov->location_id);
                    $og_fuel_mov->cumulative = $variance;
                    $og_fuel_mov->percentage = $percentage;

                    $og_fuel_mov->update();
                } /*else {
                    OgFuelMovement::create([
                        'location_id' => $location_id,
                        'ogfuel_id' => $og_fuel_id,
                        'receipt' => $quantity,
                        'date'  => now()
                    ]);
                }*/
                /* saving stockreport  &&  stockreportproduct */

                $stock = new StockReport();
                $stock->creator_user_id = Auth::user()->id;
                $stock->type = ($stock_type == 'IN') ? 3 : 4; //('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
                $stock->systemid = $stock_system_id;
                $stock->quantity = $quantity;
                $stock->product_id = $product_id;
                $stock->status = 'confirmed';
                $stock->location_id = $location_id;
                $stock->save();

                /* saving stockreport  &&  stockreportproduct */
                $stockreportproduct = new stockreportproduct();
                $stockreportproduct->quantity = $quantity;
                $stockreportproduct->stockreport_id = $stock->id;
                $stockreportproduct->product_id = $product_id;
                $stock->status = 'confirmed';
                $stockreportproduct->save();
                /* ------------------------------------- */
                
                $msg = "Stock In performed succesfully";
            } else {
                $msg = "Please fill in product quantity";
            }
            $data = view('layouts.dialog', compact('msg'));
            
        } catch (\Exception $e) {
            $msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
        }
        return $data; 
    }
    
    public function updateRackProductQuantitystock(Request $request)
	{
		
		try {
			$id = Auth::user()->id;
			
			$table_data = $request->get('table_data');
			$stock_type = $request->get('stock_type');
			
			$total_qty = 0;
			$stock_system = DB::select("select nextval(stockreport_seq) as index_stock");
			$stock_system_id = $stock_system[0]->index_stock;
			$stock_system_id = sprintf("%010s", $stock_system_id);
			$stock_system_id = '111' . $stock_system_id;
			
			foreach ($table_data as $key => $value) {
				if ($value['qty'] <= 0) {
					continue;
				}
				
				$rackproduct = rackproduct::where('rack_id', '=', $value['rack_id'])->where('product_id', '=', $value['product_id'])->orderby('id', 'desc')->first();
				if ($rackproduct) {
					$curr_qty = $rackproduct->quantity;
					if ($stock_type == "IN") {
						$curr_qty += $value['qty'];
					} else {
						$curr_qty -= $value['qty'];
					}
				} else {
					$curr_qty = $value['qty'];
				}
				log::debug('curr_qty' . $curr_qty);
				log::debug('value:' . json_encode($value));
				$product = new rackproduct();
				$product->product_id = $value['product_id'];
				$product->rack_id = $value['rack_id'];
				$product->quantity = $curr_qty;
				$product->save();
				
				$stockreport = new StockReport();
				$stockreport->type = ($stock_type == 'IN') ? 3 : 4; //('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
				$stockreport->creator_user_id = Auth::user()->id;
				$stockreport->systemid = $stock_system_id;
				$stockreport->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
				$stockreport->product_id = $value['product_id'];
				$stockreport->status = 'confirmed';
				$stockreport->location_id = $value['location_id'];
				$stockreport->save();
				
				$stockreportproduct = new stockreportproduct();
				$stockreportproduct->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
				$stockreportproduct->stockreport_id = $stockreport->id;
				$stockreportproduct->product_id = $value['product_id'];
				$stockreportproduct->save();
				
				$stockreportproductrack = new stockreportproductrack();
				$stockreportproductrack->stockreportproduct_id = $stockreportproduct->id;
				$stockreportproductrack->rack_id = $value['rack_id'];
				$stockreportproductrack->save();
				$total_qty += $value['qty'];
			}
			
			if ($total_qty > 0) {
				if ($stock_type == "IN") {
					$msg = "Stock In performed succesfully";
				} else {
					$msg = "Stock Out performed succesfully";
				}
			} else {
				$msg = "Please fill in product quantity";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
    }

    public function getTodayFuelMovement($location_id, $ogfuel_id) {
        
        $date = date('Y-m-d');
        $ogfuel_movement = OgFuelMovement::where([
            ['ogfuel_id' ,'=', $ogfuel_id],
            ['location_id','=' , $location_id]
        ])
        ->whereBetween('updated_at', [date($date. ' 00:00:00'), date($date.' 23:59:59')])
        ->get()->first();
        if($ogfuel_movement) return true;

        return false;
    }

    public function checkFuelMovementExist($location_id, $ogfuel_id) {
        
        $date = date('Y-m-d');
        $ogfuel_movement = OgFuelMovement::where([
            ['ogfuel_id' ,'=', $ogfuel_id],
            ['location_id','=' , $location_id]
        ])
        ->get()->first();
        if($ogfuel_movement) return true;

        return false;
    }

    public function checkFuelMovement(Request $request){

        /*added by Udemezue  for selecting the actual value of ogfuel_id*/
        $og_fuel = Ogfuel::where("product_id", $request->ogfuel_id)->first();
        $og_fuel_id = $og_fuel ? $og_fuel->id : '';
        
        //$exist = ['exist' => false];
        $btns_activation_status = ['start' => false , 'dipping' => false];
        if($request->ogfuel_id && $request->location_id){
            if($this->getTodayFuelMovement($request->location_id, $og_fuel_id)){
                $btns_activation_status['start'] = false ;
                $btns_activation_status['dipping'] = true ;
            } else {
                if($this->checkFuelMovementExist($request->location_id, $og_fuel_id)) {
                    $btns_activation_status['start'] = false ;
                    $btns_activation_status['dipping'] = true ;
                } else {
                    $btns_activation_status['start'] = true ;
                    $btns_activation_status['dipping'] = false ;
                }
            }
        }

        return json_encode($btns_activation_status);
    }
	
	protected function getStockReportProducts($id, $request, $byDay = false , $location_id){
        $stockreportproducts = stockreportproduct::with('stock_report.location',
            'stock_report.remark',
            'stock_report.product');
            if($location_id){
                $stockreportproducts = $stockreportproducts->whereHas('stock_report.location',function($query) use($location_id){
                    $query->where('location_id' , $location_id);
                });
            }
            $stockreportproducts = $stockreportproducts->where('product_id' , $id)
            ->orderby('id', 'DESC');

//        dd($stockreportproducts->get()[0]->stock_report);

        return $byDay ? $stockreportproducts->
        whereBetween('updated_at', [date($request->day. ' 00:00:00'), date($request->day.' 23:59:59')])
        ->get() : $stockreportproducts->get();
    }

    protected function getOposreceiptproducts($id, $request, $byDay = false , $location_id){
        $opos_product = opos_receiptproduct::
        SELECT (
            'opos_receipt.systemid as document_no',
           /* 'opos_receiptproduct.receipt_id',
            'opos_receiptproduct.promo_id'  ,
            'opos_receiptproduct.created_at as last_update',*/
            /*'opos_itemdetails.id as item_detail_id',
            'opos_itemdetails.receiptproduct_id',*/
            'location.branch as location',
            'location.id as locationid',
            'opos_receiptdetails.void',

//            'opos_receiptproduct.quantity as opos_receiptproduct_quantity',
            'opos_receipt.payment_type',
            'opos_receiptproduct.*',
            'opos_refund.refund_type',
            'opos_refund.refunded_amt'
            // 'opos_receiptremarks.remarks'
        )
//            ->join('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
            ->leftJoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
            ->leftJoin('opos_refund', 'opos_refund.receiptproduct_id', '=', 'opos_receiptproduct.id')
            ->join('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->join('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->join('location', 'location.id', '=', 'opos_locationterminal.location_id')
            // ->leftjoin('opos_receiptremarks','opos_receiptproduct.receipt_id', '=', 'opos_receiptremarks.receipt_id')
            ->where('opos_receiptproduct.product_id', $id)
            ->where('opos_receiptproduct.product_id', $id);
            if($location_id){
                $opos_product->where('location.id', $location_id);
            }
            $opos_product = $opos_product->orderby('opos_receiptproduct.id', 'DESC');

        return 
        $byDay ? $opos_product->whereBetween('opos_receipt.updated_at', [date($request->day. ' 00:00:00'), date($request->day.' 23:59:59')])
            ->get() : $opos_product->get();
    }
}
