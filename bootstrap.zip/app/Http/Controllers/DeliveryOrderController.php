<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class DeliveryOrderController extends Controller
{
	


	public function index()
	{
		return DataTables::of(array('',''))
			->addIndexColumn()
			->addColumn('do_no',function($staffList){
			return '<p data-field="do_no" style="margin:0;"> 1</p>';
			})
			->addColumn('do_id',function($staffList){
			return '<a data-field="do_id" href="/deliveryorder" target="_blank" class="text-center">19062821030100000001</a>';
			})
			->addColumn('do_source',function(){
			return '<p data-field="do_source" style="margin:0;" class="text-center">GATOR</p>';
			})
			->addColumn('do_date',function(){
			return '<p data-field="do_date" style="margin:0;" class="text-center">28Jun19 21:13:40</p>';
			})
			->addColumn('do_status',function(){
			return '<p data-field="do_status" style="margin:0;" class="text-center">Completed</p>';
			})
			->escapeColumns([])
			->make(true);

	}


	public function showIssuedlist()
	{
		return view('deliveryorder.deliveryorder_issued_list');
	}
public function showReceivedlist()
	{
		return view('deliveryorder.deliveryorder_received_list');
	}

    // method for delievery order template
    public function doindex()
    {
    	return view('deliveryorder.deliveryorder');
    }
}
