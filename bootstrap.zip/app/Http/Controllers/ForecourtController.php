<?php

namespace App\Http\Controllers;

use App\Models\merchantproduct;
use App\Models\OgFuel;
use App\Models\OgPumpNozzle;
use App\Models\OgPump;
use App\Models\OgFuelPrice;
use App\Models\opos_receiptproduct;
use App\Models\opos_wastageproduct;
use App\Models\StockReport;
use App\Models\ogController;
use Carbon\Carbon;
use Illuminate\Http\Request;
use \Illuminate\Support\Facades\Auth;
use \App\Models\usersrole;
use \App\Classes\UserData;
use App\Models\Company;
use \App\Classes\SystemID;
use Yajra\DataTables\DataTables;
use Yadakhov\InsertOnDuplicateKey;
use Log;
use DB;

class ForecourtController extends Controller
{
	public function index($locationId) {
		$id = Auth::user()->id;
        $user_data = new UserData();
        $user_roles = usersrole::where('user_id',$id)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        $is_king = $is_king != null ? true : false;

        return view('superadmin.controller_mgmt',
			compact('user_roles','is_king'));
	}

    public function fcContrlr($locationId) {
        
        $dataList = DB::select('SELECT * FROM og_controller WHERE location_id = ? ORDER BY id DESC', [$locationId]);

        $temp = [];
        foreach ($dataList as $elem) {
            $elem = get_object_vars($elem);
            $query = DB::select('SELECT * FROM og_pump WHERE controller_id = ?', [$elem["id"]]);

            $pumpNo = array("pump_no"=> count($query));
            $t = array_merge($elem, $pumpNo);
            array_push($temp, $t);
        }

        $data = Datatables::of($temp)->
        addIndexColumn()->
        addColumn('public_ip', function ($memberList) {
            if (empty($memberList['public_ipaddress'])) {
                $memberList['public_ipaddress'] = "0.0.0.0";
            }
            return "<p class='dt-center' data-field='public_ip' style='margin: 0;cursor:pointer'><a style='color: #007bff' class='publicip-" . $memberList['id'] . "' data-field='publicip' id='" . $memberList['id'] . "' onclick='editModal(this.id, this.innerHTML, this.dataset.field)'>". $memberList['public_ipaddress'] ."</a></p><input type='hidden'  name='id[]' value=" . $memberList['id'] . "><input type='hidden' class='ipv publicip-" . $memberList['id'] . "' style='border: 0' name='publicip[]' value=" . $memberList['public_ipaddress'] . " placeholder='ENTER PUBLIC IP'>";
        })->
        addColumn('local_ip', function ($memberList) {
            if (empty($memberList['ipaddress'])) {
                $memberList['ipaddress'] = "0.0.0.0";
            }
            return "<p class='dt-center' data-field='local_ip' style='margin: 0;cursor:pointer'><a style='color: #007bff' class='localip-" . $memberList['id'] . "' data-field='localip' id='" . $memberList['id'] . "' onclick='editModal(this.id, this.innerHTML, this.dataset.field)'>". $memberList['ipaddress'] ."</a></p><input type='hidden' style='border: 0' name='localip[]' class='ipv localip-" . $memberList['id'] . "' value=" . $memberList['ipaddress'] . " placeholder='ENTER PUBLIC IP'>";
        })->
        addColumn('controller_id', function ($memberList) {
            return "<p class='dt-center' data-field='controller_id' style='margin: 0;cursor:pointer'>". $memberList['systemid'] ."</p>";
        })->
        addColumn('device_id', function ($memberList) {  

			Log::debug('device_id='.json_encode($memberList));

            if(($memberList['device_id']))
            {
            return '<p data-field="device_id" class="text-center" style="cursor: pointer;  margin: 0;">' .
            $memberList['device_id'] . '</p><input type="hidden" style="border: 0" name="deviceid[]" class="deviceid" value="'.$memberList['device_id'].'">';

            } else {
                return '<p data-field="device_id" class="text-center" style="cursor: pointer;  margin: 0;">-</p><input type="hidden" style="border: 0" name="deviceid[]" class="deviceid" value="-">';
            }
        })->
        addColumn('pumps', function ($memberList) {
            return '<p data-field="pumps" class="dt-center" style="cursor: pointer;  margin: 0;"><a class="pumps" id="' . $memberList['id'] . '" onclick="pumpMgmt(this.id)" >' .
            $memberList['pump_no'] . '</a></p>';

        })->
        addColumn('fw_rel_date', function ($memberList) {
            return '<p data-field="fw_rel_date" class="dt-center" style="cursor: pointer;  margin: 0;">' .
            $memberList['fw_rel_date'] . '</p><input type="hidden" style="border: 0" name="fw_rel_date[]" value="'.$memberList['fw_rel_date'].'">';

        })->
        addColumn('battery', function ($memberList) {
            return '<p data-field="battery" class="dt-center" style="cursor: pointer;  margin: 0;">' .
            number_format($memberList['battery_voltage'],3) . 'V</p><input type="hidden" style="border: 0" name="battery_voltage[]" value="'.$memberList['battery_voltage'].'">';
            
        })->
        addColumn('flash', function ($memberList) {
            return '<p data-field="flash" class="dt-center" style="cursor: pointer;  margin: 0;">' .
            number_format($memberList['free_storage'],0) . 'KB, '.
			number_format(($memberList['free_storage']/(
			(empty($memberList['total_storage']) ? 1 : $memberList['total_storage'])
			)) * 100, 2) .
			'%</p><input type="hidden" style="border: 0" name="free_storage[]" value="'.$memberList['free_storage'].'">';
            
        })->
        addColumn('bluecrab', function ($memberList) {
            return '<a class="bluecrabc allip" onClick="displayIpAddresses(this.id)" id="' . $memberList['id'] . '" data-id="' . $memberList['id'] . '"  data-toggle="modal" data-target="#ipaddress" ><p data-field="bluecrab"
            style="background-color:#007bff;
            color:#fff;
            border-radius:5px;margin:auto; 
            width:25px;height:25px;
            display:block;cursor: pointer;" 
            class="text-center">
            O</p></a>';
        })->

        //commented by atif 
        // addColumn('pull', function ($memberList) {
        //     return '<a class="pull" onClick="pullFromController(this,this.id)" id="' . $memberList['id'] . '" data-id="' . $memberList['id'] . '" ><p data-field="pull" 
        //     style="background-color:#f79a07;
        //     color:#fff;
        //     border-radius:5px;margin:auto; 
        //     width:25px;height:25px;
        //     display:block;cursor: pointer;" 
        //     class="text-center">
        //     U</p></a>';
        // })-> 

        //created by atif
         addColumn('pull', function ($memberList) {
            return '<a class="pull" onClick="confirmationAboutPulling(this.id)" id="' . $memberList['id'] . '" data-id="' . $memberList['id'] . '" ><p data-field="pull" 
            style="background-color:#f79a07;
            color:#fff;
            border-radius:5px;margin:auto; 
            width:25px;height:25px;
            display:block;cursor: pointer;" 
            class="text-center">
            U</p></a>';
        })-> 
        // end by atif
        addColumn('deleted', function ($memberList) {
            return '<a class="delete" onClick="showDeletePrompt(this.id)" id="' . $memberList['id'] . '" data-id="' . $memberList['id'] . '" ><p data-field="deleted" 
			style="background-color:red;
			border-radius:5px;margin:auto; 
			width:25px;height:25px;
			display:block;cursor: pointer;" 
			class="text-danger remove">
			<i class="fas fa-times text-white"
			style="color:white;opacity:1.0;
			padding:4px 7px;
			-webkit-text-stroke: 1px red;"></i></p></a>';
        })->escapeColumns([])->make(true);
        
        return $data;
    }


    public function newController(Request $request, $locationId)
    {	
        $local_ip  = $request->get('local_ip');
        $public_ip  = $request->get('public_ip');
    	$a = new SystemID('controller');
	    $systemId = $a->__toString();

        $created_at = date("Y-m-d H:i:s");
        $updated_at = date("Y-m-d H:i:s");

    	$query = DB::insert('INSERT INTO og_controller (systemid, location_id, ipaddress , public_ipaddress, created_at, updated_at) VALUES (?, ?, ?, ? ,? ,? )', [$systemId, $locationId , $local_ip , $public_ip,  $created_at, $updated_at]);

    	$id = DB::select('SELECT id FROM og_controller WHERE systemid = ?', [$systemId]);

    	$data = array(
			'id' => $id,
			'pts_mode' => env('PTS_MODE'),
			'systemid' => $systemId,
			'locationId' => $locationId
		);

    	return response()->json($data);
    }

    //atif added
    public function updateController(Request $request, $controller_id){
        if($controller_id){
            $data =$request->all();
            //$data['battery_voltage'] = $data['battery_voltage']/1000;
            $data = DB::table('og_controller')->
				where('id',$controller_id)->
				update($data);
            return $data;
        }
    }

    public function saveController(Request $request){
        $localip   = request()->input('localip', []);
        $publicip   = request()->input('publicip', []);
        $deviceid   = request()->input('deviceid', []);
        $fw_rel_date   = request()->input('fw_rel_date', []);
        $battery_voltage   = request()->input('battery_voltage', []);
        $free_storage   = request()->input('free_storage', []);
        $id   = (count(request()->input('id', [])) > 0) ? request()->input('id', []) : '0';

        if($id == 0){
            return response()->json();
        }
        for($count=0; $count < count($localip); $count++){
            $controllers = ['id' => $id[$count], 'ipaddress' => $localip[$count], 'public_ipaddress' => $publicip[$count], 'device_id' => $deviceid[$count], 'fw_rel_date' => $fw_rel_date[$count], 'battery_voltage' => $battery_voltage[$count], 'free_storage' => $free_storage[$count]];
            $data[] = $controllers;
        }
        
        ogController::insertOnDuplicateKey($data);
        //$query = DB::insert('INSERT INTO og_controller (id, location_id, device_id, fw_rel_date, battery_voltage, free_storage, ipaddress, public_ipaddress) VALUES (1210000000082,0,1,0,1,2,88888,2132), (1210000000081,0,1,0,1,2,12323,2132), (1210000000080,0,1,0,1,2,12323232,212332) ON DUPLICATE KEY UPDATE systemid = VALUES(systemid)');
       
        return response()->json($deviceid);
    }


    public function delController($controllerId) {
        $query = DB::delete('DELETE FROM og_controller WHERE id = ?', [$controllerId]);
        $msg = "Location deleted successfully";
        return response()->json($controllerId);
    }


    public function formatDate($date) {
        $newDate = date("dMy h:i:s", strtotime($date));
        return response()->json($newDate);
    }


    public function savePumpNozzleData(Request $request){
		Log::debug('***** savePumpNozzleData() *****');

        $system_id = $request->pump_id;
        $controller_id = $request->controller_id;
        $pump_no = $request->pump_no;
        $pump_configuration_protocol = $request->pump_configuration_protocol;
        $baud_rate = $request->baud_rate;
        $pump_port = $request->pump_port;
        $communication_address = $request->communication_address;
        $nz=$request->nz;
        $nz_data=$request->nz_data;

        // return $request->all();
        $pump_id=OgPump::where("systemid",$system_id)->first()->id;
        OgPump::whereId($pump_id)->update([
            "controller_id"=>$controller_id,
            "og_pts2_protocol_id"=>$pump_configuration_protocol,
            "baudrate"=>$baud_rate,
            "pump_port"=>$pump_port,
            "comm_address"=>$communication_address,
        ]);

		// Inserting to pumpnozzle table
        $this->user_data = new UserData();
    
		$model = new OgFuel();
	
		$ids = merchantproduct::where('merchant_id',
			$this->user_data->company_id())->
			pluck('product_id');
		
		$data = $model->whereIn('product_id', $ids)->get();

		Log::debug('data='.json_encode($data));
		Log::debug('nz='.json_encode($nz));
		Log::debug('nz_data='.json_encode($nz_data));

		for($i=1; $i <= count($nz); $i++){
			$ogfuel_id=0;

			Log::debug('---i='.$i);

			foreach ($data as $key => $value) {

				if (!empty($nz[$i])) {
					Log::debug('nz['.$i.']='.json_encode($nz[$i]));
					Log::debug('value='.json_encode($value));

					if($value->product_name->name==$nz[$i]){
						$ogfuel_id=$value->id;
					}
				}
			}
		
			OgPumpNozzle::updateOrCreate(
				['pump_id' => $pump_id, 'nozzle_no' => $i],
				['ogfuel_id' =>$ogfuel_id]
			);
        }

        for($j = count($nz)+1; $j <= 6; $j++){
            OgPumpNozzle::where('pump_id', $pump_id)->
				where('nozzle_no',$j)->
				delete();
        }

        return response()->json();
    }


    public function pumpNozzle(){
		$ret = [];

        $this->user_data = new UserData();
        
        $model = new OgFuel();
    
        $ids = merchantproduct::where('merchant_id',
            $this->user_data->company_id())->
			pluck('product_id');
        
        $data = $model->whereIn('product_id', $ids)->get();

        foreach ($data as $key => $value) {
            $ret[$key]['price'] = $this->get_execute_price($value->id);
            $ret[$key]['id'] = $value->product_name->id;
            $ret[$key]['name'] = $value->product_name->name;
            $ret[$key]['ogfuel_id'] = $value->id;
        }
        
        //Log::debug(response()->json($ret));

        return response()->json($ret);
    }


    public function savePump(Request $request){
		Log::debug('***** savePump() *****');
        $pump_id = $request->input('pump_id');

		Log::debug(json_encode($request->input('nz')));

        $nz  = (count($request->input('nz')) > 0) ?
			$request->input('nz') : 0;

        if($nz == 0){
            return response()->json();
        }

		// Inserting to pumpnozzle table
        for($i=1; $i <= count($nz); $i++){
			$opn = new OgPumpNozzle();
			$opn->nozzle_no = $i;
			$opn->pump_id = $pump_id;
			$opn->ogfuel_id = $nz[$i]['ogfuel_id'];
			$opn->save();
        }
        
        return response()->json();
    }


    public function get_execute_price($id)
    {
        $ogFuelPrice = OgFuelPrice::where('ogfuel_id', $id)
            ->where('price', '!=', null)
            ->where('start', '!=', null)
            ->whereDate('start', '<=', Carbon::now())
            ->orderBy('id', 'DESC')
            ->first();
        
        if(!empty($ogFuelPrice)){
            $price = $ogFuelPrice->price;
        }else{
            $price = '0.00';
        }
        
        return $price;
    }

    public function PumpMgment($controllerId)
    {   
        $data = DB::select('SELECT og_pts2_protocol.id, og_pts2_protocol.protocol_no, og_pts2_protocol.protocol_name from og_pts2_protocol');
        return view('superadmin.pump_mgmt',compact('data'));
    }
    
    public function pumpMgmt($controllerId)
    {   
        $data = DB::select('SELECT og_pump.id, og_pump.systemid, og_pump.controller_id, og_pump.pump_no, og_pump.created_at, og_controller.id AS c_id, og_controller.systemid AS c_systemid FROM og_pump INNER JOIN og_controller ON  og_controller.id = og_pump.controller_id WHERE controller_id = ?', [$controllerId] );

        return response()->json($data);
    }

    public function newPump($controllerId)
    {   
        $a = new SystemID('pump');
        $systemId = $a->__toString();

        $query = DB::insert('INSERT INTO og_pump (systemid, controller_id) VALUES (?, ?)', [$systemId, $controllerId]);

        $id = DB::select('SELECT id FROM og_pump WHERE systemid = ?', [$systemId]);
        $c_systemid = DB::select('SELECT systemid FROM og_controller WHERE id = ?', [$controllerId]);

        $data = array('id' => $id[0]->id, 'systemid' => $systemId, 'controllerid' => $controllerId, 'c_systemid' => $c_systemid[0]->systemid);

        return response()->json($data);
    }


    function updateIp ($ipAddress, $controllerId, $fieldType) {
        $query = DB::update('UPDATE og_controller SET ' . $fieldType . ' = ? WHERE id = ?', [$ipAddress, $controllerId]);

        return response()->json([
            'ipAddress' => $ipAddress,
            'controllerId' => $controllerId,
            'fieldType' => $fieldType
        ]);
    }

    function updatePump ($id, $pump_no) {
        $query = DB::update('UPDATE og_pump SET pump_no = ? WHERE id = ?', [$pump_no, $id]);

        return response()->json($pump_no . "-" . $id);
    }

    public function delPump($pumpId) {
        $query = DB::delete('DELETE FROM og_pump WHERE id = ?', [$pumpId]);

        $response = (new ApiMessageController())->
			saveresponse('Client deleted successfully!');
        
        return response()->json($pumpId);
    }


	/* Need to get some data for pull operation:
	   ipaddress, public_ipaddress, PTS_MODE */
	function getPullData($controllerId) {
		$ipaddress = null;

        $ips = DB::select('SELECT ipaddress, public_ipaddress FROM og_controller WHERE id = '.$controllerId);

		Log::debug('IP Addresses = '.json_encode($ips));

        return response()->json([
            'ipaddress' => $ips[0]->ipaddress,
            'public_ipaddress' => $ips[0]->public_ipaddress,
            'pts_mode' => env('PTS_MODE')
        ]);
	}


	/* Update IP address */
	function updateIpAddress(Request $request) {
		$controller_id = $request->input('controller_id');
		$ipaddress = $request->input('ipaddress');
		$public_ipaddress = $request->input('public_ipaddress');

        $query = DB::update('UPDATE og_controller SET ipaddress="'.
			$ipaddress. '", public_ipaddress="'. $public_ipaddress.
			'" WHERE id = '. $controller_id);

        return response()->json($query);
	}


	// Having a og_controller.id from Admin, get the company.owner_user_id
	public function getOwnerUserId($controller_id) {
		$query = "
		SELECT
			c.owner_user_id
		FROM
			og_controller ogc,
			merchantlocation ml,
			merchant m,
			company c
		WHERE
			ogc.location_id = ml.location_id AND
			ml.merchant_id = m.id AND
			m.company_id = c.id AND
			ogc.id = ".$controller_id." 
		";

		$result = DB::select(DB::raw($query));

		//Log::debug('result='.json_encode($result));

		return $result;
	}

	/* Retrieve OG Fuel Products */
    public function getOGFuelProducts($owner_user_id) {
		/* This is normally run as admin, so we need to get the actual 
		 * user_id or merchant_id */

		$query = "
		SELECT
			latest.id,
			latest.name,
			og_fuelprice.ogfuel_id as No,
			og_fuelprice.price
		FROM (
		SELECT
			p.id,
			p.name,
			max(fp.created_at) as fp_created_at
		FROM
			product p,
			prd_ogfuel pof,
			merchantproduct mp,
			company c,
			merchant m,
			og_fuelprice fp
		WHERE
			pof.product_id = p.id 
			AND mp.product_id = p.id
			AND mp.merchant_id = m.id
			AND fp.ogfuel_id = pof.id
			AND m.company_id = c.id
			AND p.name is not null
			AND fp.price is not null
			AND c.owner_user_id = ".$owner_user_id." 
		GROUP BY
			p.id
		) as latest
		INNER JOIN
			og_fuelprice
		ON
			og_fuelprice.created_at = latest.fp_created_at
		ORDER BY
			og_fuelprice.ogfuel_id
		LIMIT 8
		";

		$og_fuels = DB::select(DB::raw($query));

        return response()->json($og_fuels);
    }


	/* Retrieve currently active and defined OG Fuel products
	 * Note that this should retrieve all active products from ALL
	 * controllers owned by the company */
    public function getActiveOGFuelProducts($owner_user_id) {
		$query = "
			SELECT
				og_fuelprice.ogfuel_id as No,
				latest.nozzle_no,
				latest.name,
				og_fuelprice.price
			FROM (
			SELECT
				p.name,
				pn.nozzle_no,
				max(fp.created_at) as created_at
			FROM
				product p,
				prd_ogfuel of,
				merchantproduct mp,
				company c,
				merchant m,
				og_fuelprice fp,
				og_pump op,
				og_controller oc,
				og_pumpnozzle pn
			WHERE
				of.product_id = p.id 
				AND mp.product_id = p.id
				AND mp.merchant_id = m.id
				AND fp.ogfuel_id = of.id
				AND m.company_id = c.id
				AND pn.pump_id = op.id
				AND pn.ogfuel_id = of.id
				AND op.controller_id = oc.id
				AND p.name is not null
				AND fp.price is not null
				AND c.owner_user_id = ".$owner_user_id." 
			GROUP BY
				p.id
			) as latest
			INNER JOIN
				og_fuelprice
			ON
				og_fuelprice.created_at = latest.created_at
			ORDER BY
				og_fuelprice.ogfuel_id
			LIMIT 8
		";

		$active_og_fuels = DB::select(DB::raw($query));

        return response()->json($active_og_fuels);
	}

	/* Retrieve product/nozzle mapping per pump for all the pumps given
	 * the owner_user_id */

    public function getNozzleProductMapping($owner_user_id) {
		$query = "
			SELECT
				oc.id as controller_id,
				op.id as pump_id,
				pn.nozzle_no,
				pn.ogfuel_id
			FROM
				og_controller oc,
				og_pump op,
				og_pumpnozzle pn,
				prd_ogfuel prd,
				product p,
				merchantlocation ml,
				merchant m,
				company c
			WHERE
				pn.pump_id = op.id AND
				pn.ogfuel_id = prd.id AND
				prd.product_id = p.id AND
				op.controller_id = oc.id AND
				oc.location_id = ml.location_id AND
				ml.merchant_id = m.id AND
				m.company_id = c.id AND
				c.owner_user_id = ".$owner_user_id."
			";

		$nozprod = DB::select(DB::raw($query));

        return response()->json($nozprod);
	}
        

	function getPumpData($controllerId, $pumpNo, $pumpId,
		Request $request) {
		$pumpDetails=OgPump::select([
			'og_pts2_protocol_id',
			'baudrate',
			'pump_port',
			'comm_address',
			'controller_id',
			'pump_no',
			'systemid'])->with([
				'pumpNozzlesData:pump_id,nozzle_no,ogfuel_id'
			])->where([
				"controller_id" => "$controllerId",
				"pump_no" => $pumpNo,
				"systemid" => $pumpId
			])->first();

		//Log::debug('

		return response()->json($pumpDetails);
	}
}
