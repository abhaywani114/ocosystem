<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use App\Models\Company;
use App\Models\usersrole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;

class HcapStaffController extends Controller
{
    //
    public function showView()
    {
      $staffs = Staff::all();
        return view('hcap_staff.hcap_staff',compact('staffs'));
    }

    public function personalDetails($user_id)
    {
      $user_id = Auth::user()->id;
      $user_roles = usersrole::where('user_id', $user_id)->get();
      $is_king =  Company::where('owner_user_id', Auth::user()->id)->get();
      return view('hcap_staff.personal_details', compact('user_roles', 'is_king', 'user_id'));
    }

    public function personalTab(request $tab)
    {
      switch ($tab->tabName) {
        case 'personalDetails':
            return view('hcap_staff.form_personal', compact('tab'));
          break;
        case 'staffDetail':
            return view('hcap_staff.form_detail', compact('tab'));
          break;
        case 'staffAppraisal':
            return view('hcap_staff.form_appraisal', compact('tab'));
          break;
        
        default:
          return false;
          break;
      }
    } 

    public function staffPicture(Request $request)
    {
      if ($request->file('photo')->isValid()) {
        // return $request->photo->path();
        // $path = $request->file('photo')->store('images');
        // return $path;
        $this->check_location("/images/profile");

        $file = $request->file('photo');
          $extension = $file->getClientOriginalExtension(); // getting image extension
          $user_id = Auth::user()->id;

          if (!in_array($extension, array(
              'jpg', 'JPG', 'png', 'PNG', 'jpeg', 'JPEG', 'gif', 'GIF', 'bmp', 'BMP', 'tiff', 'TIFF'))) {
              return abort(403);
          }

          $filename = 'profile_'.rand(111, 999) .'_' .$user_id .'.' .$extension;

          $file->move(public_path() . ("/images/profile/"), $filename);
          
          return asset('/images/profile/' .$filename);
      }
    }

    public function staffDelPicture(request $request) {
      $path = array_filter(explode('/', $request->path));
      $photo_path = '/' .$path[3] .'/' .$path[4] .'/' .$path[5];
      
      File::delete(public_path() .$photo_path);
      return '';
    }

    public function check_location($location)
    {
        $location = array_filter(explode('/', $location));
        $path = public_path();

        foreach ($location as $key) {
            $path .= "/$key";

			Log::debug('check_location(): $path='.$path);

            if (is_dir($path) != true) {
                mkdir($path, 0775, true);
            }
        }
    }
}
