<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SvcWarrantyController extends Controller
{
    //
}
