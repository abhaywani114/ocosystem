<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CRPTDirRemunerationController extends Controller
{   public function index()
{
    return view('crpt.dir_remuneration.crpt_dir_remuneration');
} //
}
