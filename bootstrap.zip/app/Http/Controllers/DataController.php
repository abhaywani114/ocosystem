<?php

namespace App\Http\Controllers;

use App\Classes\SystemID;
use App\Models\MerchantLinkRelation;
use App\Models\stockreportproduct;
use App\Models\warranty;
use App\Models\Wholesale;
use App\StockReport;
use Illuminate\Http\Request;
use \App\Models\usersrole;
use \App\Models\role;
use Illuminate\Support\Carbon;
use \Illuminate\Support\Facades\Auth;
use App\Models\merchantlocation;
use App\Models\location;
use App\Classes\UserData;
use App\Models\prd_inventory;
use App\Models\product;
use App\Models\rawmaterial;
use App\Models\Company;
use App\Models\Currency;
use App\Models\Twoway;
use App\User;
use Yajra\DataTables\DataTables;
use App\Models\MerchantLink;
use \App\Models\merchantproduct;
use App\Models\inventorycost;
use App\Models\inventorycostproduct;
use App\Models\Merchant;
use App\Models\MerchantCreditLimit;
use App\Models\Oneway;
use App\Models\OnewayRelation;
use App\Models\FoodCourtMerchant;
use App\Models\FoodCourtMerchantTerminal;
use App\Models\terminal;
use App\Models\prd_proservices;

use Log;


class DataController extends Controller
{
    public function showSupplierView() {
        $this->user_data = new UserData();
        //$idd = Auth::user()->id;

        $ids = merchantlocation::where('merchant_id', $this->user_data->
			company_id())->
			pluck('location_id');

        $location = location::where([['branch', '!=', 'null']])->
			whereIn('id', $ids)->
			latest()->
			get();

        $user_id = $this->getCompanyUserId();

        return view('data.supplier',compact(
			'location', 'user_id'
		));
    }


	public function showDocumenttrackingView($merchantId, Request $request){
        $this->user_data = new UserData();
		//$idd = Auth::user()->id;

		$ids = merchantproduct::where('merchant_id',
			$this->user_data->company_id())->
			pluck('product_id');

		$inventory_data = product::whereIn('ptype',
			['inventory', 'rawmaterial'])->
			whereNotNull('name')->
            whereIn('id', $ids)->
            where('description', '!=', '')->
            where('photo_1', '!=', '')->
            where('thumbnail_1', '!=', '')->
            where('prdcategory_id', '!=', '')->
            where('prdprdcategory_id', '!=', '')->
            where('brand_id', '!=', '')->
            where('prdsubcategory_id', '!=', '')
            ->get();

		$ids = merchantlocation::where('merchant_id',
			$this->user_data->company_id())->
			pluck('location_id');

        $locations = location::where([['branch', '!=', 'null']])->
			whereIn('id', $ids)->latest()->
			get();

		$user_id = $this->getCompanyUserId();

        $report_id = stockreport::count();
        $report_id += 1;

        return view('data.tracking',compact(
			'locations', 'user_id', 'merchantId', 'inventory_data', 'report_id'
		));
	}


    public function getCompanyUserId()
    {
        $userData = new UserData();
        $companyId = $userData->company_id();
        $company = Company::find($companyId);
        return $company->owner_user_id;
    }


    public function merchantTransactionExist($merchantId) {
        return merchantlocation::select('merchantlocation.id')
            ->join('opos_locationterminal', 'opos_locationterminal.location_id', '=', 'merchantlocation.location_id')
            ->join('opos_receipt', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->where('merchantlocation.merchant_id', $merchantId)
            ->get()->count() > 0 ? true : false;
    }


    public function getSupplierData(Request $request)
    {
        //$userId = Auth::user()->id;
        $userId = $this->getCompanyUserId();

        $userData = new UserData();

        $responderIds = MerchantLink::where('initiator_user_id', $userId)->
			pluck('responder_user_id')->toArray();

        $initiatorIds = MerchantLink::where('responder_user_id', $userId)->
			pluck('initiator_user_id')->toArray();

        $merchantUserIds = array_merge($responderIds, $initiatorIds);

        $first = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id');


        /*
        // name filter
        $search = $request->input('search');
        if (isset($search['value']) && $search['value'] != '')
            $query->where('title', 'like', '%'.$search['value'].'%');

        // order by
        $order = $request->input('order');
        if (isset($order[0]['column']) && $order[0]['column'] != '') {
            if ($order[0]['column'] == 2) {
                $query->orderBy('title', $order[0]['dir']);
            }
            if ($order[0]['column'] == 4) {
                $query->orderBy('price', $order[0]['dir']);
            }
        }

        $query->orderBy('id',  'desc');
        */

        $first->whereIn('company.owner_user_id', $merchantUserIds);


        // one way information
        $oneWayData = Oneway::selectRaw(
			"id as company_id,
			company_name,
			business_reg_no as company_business_reg_no,
			null as company_system_id,
			null as owner_user_id,
			null as merchant_d"
        )->where('self_merchant_id', $userData->company_id());

        $query = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id');

        $query->where('company.owner_user_id', $userId)->
			union($oneWayData)->
			union($first);

        // applying limit
        $suppliers = $query->skip($request->input('start'))->
			take($request->input('length'))->get();

        $dealerMerchantId = $userData->company_id();

        $counter = 0 + $request->input('start');
        foreach ($suppliers as $key => $supplier) {
            $suppliers[$key]['indexNumber'] = ++$counter;
            $suppliers[$key]['merchant_link_id'] = 0;
            $suppliers[$key]['status'] = 'pending';
            $suppliers[$key]['merchant_link_relation_id'] = 0;
            $suppliers[$key]['merchant_location'] = 'Location';
            $suppliers[$key]['merchant_location_id'] = '';
            $suppliers[$key]['row_type'] = 'own';

            $suppliers[$key]['delete_status'] = 'active';

            if (!is_null($supplier->merchant_id)) {
                //$mlIds = merchantlocation::where('merchant_id', $supplier->merchant_id)->pluck('location_id');
                //$suppliers[$key]['merchant_location'] = location::whereIn('id', $mlIds)->get()->count();

                $suppliers[$key]['delete_status'] = $this->merchantTransactionExist($supplier->merchant_id) ? 'inactive' : 'active';


                if ($supplier->merchant_id == $dealerMerchantId) {
                    $suppliers[$key]['delete_status'] = 'inactive';
                    $merchant = Merchant::where('id', $supplier->merchant_id)->first();
                    if (!is_null($merchant->supplier_default_location_id)) {
                        $merchantLocation =
							location::where('id',
								$merchant->supplier_default_location_id)->
								first();

                        $suppliers[$key]['merchant_location'] =
							$merchantLocation->branch;

                        $suppliers[$key]['merchant_location_id'] =
							$merchant->supplier_default_location_id;
                    }
                }


                // credit limit
                $suppliers[$key]['credit_limit'] = 0;
                $suppliers[$key]['credit_limit_id'] = '';
                $merchantCreditLimit = MerchantCreditLimit::where('supplier_merchant_id',
					$supplier->merchant_id)->
					where('dealer_merchant_id', $dealerMerchantId)->
					first();

                if ($merchantCreditLimit) {
                    $suppliers[$key]['credit_limit'] = $merchantCreditLimit->credit_limit/100;
                    $suppliers[$key]['credit_limit_id'] = $merchantCreditLimit->id;
                }

                if (in_array($supplier->owner_user_id, $responderIds)) {
                    $suppliers[$key]['row_type'] = 'twoway';
                    $suppliers[$key]['responder'] = '0';
                    $merchantLink = MerchantLink::where('initiator_user_id', $userId)->
						where('responder_user_id', $supplier->owner_user_id)->
						first();

                    $suppliers[$key]['merchant_link_id'] = $merchantLink->id;

                    // initiator
                    $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id',
						$merchantLink->id)->
						where('ptype', 'dealer')->
						first();

                    if ($merchantLinkRelation != null) {
                        $suppliers[$key]['status'] = $merchantLinkRelation->status;
                        $suppliers[$key]['merchant_link_relation_id'] =
							$merchantLinkRelation->id;

                        if (!is_null($merchantLinkRelation->default_location_id)) {
                            $location = location::where('id',
								$merchantLinkRelation->default_location_id)->
								first();

                            $suppliers[$key]['merchant_location'] = $location->branch;

                            $suppliers[$key]['merchant_location_id'] =
								$merchantLinkRelation->default_location_id;
                        }
                    }
                }

                if (in_array($supplier->owner_user_id, $initiatorIds)) {
                    $suppliers[$key]['row_type'] = 'twoway';
                    $merchantLink = MerchantLink::where('initiator_user_id',
						$supplier->owner_user_id)->
						where('responder_user_id', $userId)->
						first();

                    $suppliers[$key]['merchant_link_id'] = $merchantLink->id;
                    $suppliers[$key]['responder'] = '1';

                    // responder
                    $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id',
						$merchantLink->id)->
						where('ptype', 'supplier')->
						first();

                    if ($merchantLinkRelation != null) {
                        $suppliers[$key]['status'] = $merchantLinkRelation->status;
                        $suppliers[$key]['merchant_link_relation_id'] = $merchantLinkRelation->id;

                        if (!is_null($merchantLinkRelation->default_location_id)) {
                            $location = location::where('id',
								$merchantLinkRelation->default_location_id)->
								first();

                            $suppliers[$key]['merchant_location'] = $location->branch;
                            $suppliers[$key]['merchant_location_id'] =
								$merchantLinkRelation->default_location_id;
                        }
                    }
                }

            } else {
                // process one way
                $suppliers[$key]['row_type'] = 'oneway';

                $oneWayRelation = OnewayRelation::where('oneway_id',
					$supplier->company_id)->
					where('ptype', 'supplier')->
					first();

                if (!is_null($oneWayRelation)) {
                    $suppliers[$key]['status'] = $oneWayRelation->status;
                    $suppliers[$key]['merchant_link_relation_id'] =
						$oneWayRelation->id;

                    if (!is_null($oneWayRelation->default_location_id)) {
                        $location = location::where('id',
							$oneWayRelation->default_location_id)->first();

                        $suppliers[$key]['merchant_location'] =
							$location->branch;

                        $suppliers[$key]['merchant_location_id'] =
							$oneWayRelation->default_location_id;
                    }
                }
            }
        }

        $response = [
            'data' => $suppliers,
            'recordsTotal' => $suppliers->count(),
            'recordsFiltered' => $suppliers->count()
        ];
        return response()->json($response);
    }


    public function showDealerView() {
        $this->user_data = new UserData();
        //$idd = Auth::user()->id;
        $ids = merchantlocation::where('merchant_id',
			$this->user_data->company_id())->
			pluck('location_id');

        $location = location::where([['branch', '!=', 'null']])->
			whereIn('id', $ids)->latest()->
			get();

        $user_id = $this->getCompanyUserId();

        return view('data.dealer',compact('location', 'user_id'));
    }

    public function getDealerData(Request $request)
    {

        //$userId = Auth::user()->id;
        $userId = $this->getCompanyUserId();

        $responderIds = MerchantLink::where('initiator_user_id',
			$userId)->pluck('responder_user_id')->toArray();

        $initiatorIds = MerchantLink::where('responder_user_id',
			$userId)->pluck('initiator_user_id')->toArray();

        $merchantUserIds = array_merge($responderIds, $initiatorIds);

        $first = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id');

        /*
        // name filter
        $search = $request->input('search');
        if (isset($search['value']) && $search['value'] != '')
            $query->where('title', 'like', '%'.$search['value'].'%');

        // order by
        $order = $request->input('order');
        if (isset($order[0]['column']) && $order[0]['column'] != '') {
            if ($order[0]['column'] == 2) {
                $query->orderBy('title', $order[0]['dir']);
            }
            if ($order[0]['column'] == 4) {
                $query->orderBy('price', $order[0]['dir']);
            }
        }

        $query->orderBy('id',  'desc');
        */

        $first->whereIn('company.owner_user_id', $merchantUserIds);

        $userData = new UserData();

        // one way information
        $oneWayData = Oneway::selectRaw("id as company_id,
			company_name,
			business_reg_no as company_business_reg_no,
			null as company_system_id,
			null as owner_user_id,
			null as merchant_d"
        )->where('self_merchant_id', $userData->company_id());


        $query = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id');

        $query->where('company.owner_user_id', $userId)->
			union($oneWayData)->
			union($first);


        // applying limit
        $dealers = $query->skip($request->input('start'))->take($request->input('length'))->get();

        $counter = 0 + $request->input('start');


        $supplierMerchantId = $userData->company_id();

        foreach ($dealers as $key => $dealer) {
            $dealers[$key]['indexNumber'] = ++$counter;
            $dealers[$key]['merchant_link_id'] = 0;
            $dealers[$key]['status'] = 'pending';
            $dealers[$key]['merchant_link_relation_id'] = 0;

            $dealers[$key]['merchant_location'] = 'Location';
            $dealers[$key]['merchant_location_id'] = '';
            $dealers[$key]['row_type'] = 'own';

            $dealers[$key]['delete_status'] = 'active';



            if (!is_null($dealer->merchant_id)) {

                //$mlIds = merchantlocation::where('merchant_id', $dealer->merchant_id)->pluck('location_id');
                //$dealers[$key]['merchant_location'] = location::whereIn('id', $mlIds)->get()->count();

                $dealers[$key]['delete_status'] = $this->merchantTransactionExist($dealer->merchant_id) ? 'inactive' : 'active';

                if ($dealer->merchant_id == $supplierMerchantId) {
                    $dealers[$key]['delete_status'] = 'inactive';
                    $merchant = Merchant::where('id', $dealer->merchant_id)->first();
                    if (!is_null($merchant->dealer_default_location_id)) {
                        $merchantLocation = location::where('id', $merchant->dealer_default_location_id)->first();
                        $dealers[$key]['merchant_location'] = $merchantLocation->branch;
                        $dealers[$key]['merchant_location_id'] = $merchant->dealer_default_location_id;
                    }
                }


                // credit limit
                $dealers[$key]['credit_limit'] = 0;
                $dealers[$key]['credit_limit_id'] = '';
                $merchantCreditLimit = MerchantCreditLimit::where('supplier_merchant_id', $supplierMerchantId)->where('dealer_merchant_id', $dealer->merchant_id)->first();
                if ($merchantCreditLimit) {
                    $dealers[$key]['credit_limit'] = $merchantCreditLimit->credit_limit/100;
                    $dealers[$key]['credit_limit_id'] = $merchantCreditLimit->id;
                    $dealers[$key]['avail_credit_limit'] = $merchantCreditLimit->avail_credit_limit/100;
                }

                if (in_array($dealer->owner_user_id, $responderIds)) {

                    // check for transaction


                    $dealers[$key]['row_type'] = 'twoway';
                    $dealers[$key]['responder'] = '0';
                    $merchantLink = MerchantLink::where('initiator_user_id', $userId)->where('responder_user_id', $dealer->owner_user_id)->first();
                    $dealers[$key]['merchant_link_id'] = $merchantLink->id;

                    // initiator
                    $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id', $merchantLink->id)->where('ptype', 'supplier')->first();
                    if ($merchantLinkRelation != null) {
                        $dealers[$key]['status'] = $merchantLinkRelation->status;
                        $dealers[$key]['merchant_link_relation_id'] = $merchantLinkRelation->id;

                        if (!is_null($merchantLinkRelation->default_location_id)) {
                            $location = location::where('id', $merchantLinkRelation->default_location_id)->first();
                            $dealers[$key]['merchant_location'] = $location->branch;
                            $dealers[$key]['merchant_location_id'] = $merchantLinkRelation->default_location_id;
                        }

                    }
                }

                if (in_array($dealer->owner_user_id, $initiatorIds)) {
                    $dealers[$key]['row_type'] = 'twoway';
                    $dealers[$key]['responder'] = '1';
                    $merchantLink = MerchantLink::where('initiator_user_id', $dealer->owner_user_id)->where('responder_user_id', $userId)->first();
                    $dealers[$key]['merchant_link_id'] = $merchantLink->id;

                    // responder
                    $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id', $merchantLink->id)->where('ptype', 'dealer')->first();
                    if ($merchantLinkRelation != null) {
                        $dealers[$key]['status'] = $merchantLinkRelation->status;
                        $dealers[$key]['merchant_link_relation_id'] = $merchantLinkRelation->id;

                        if (!is_null($merchantLinkRelation->default_location_id)) {
                            $location = location::where('id', $merchantLinkRelation->default_location_id)->first();
                            $dealers[$key]['merchant_location'] = $location->branch;
                            $dealers[$key]['merchant_location_id'] = $merchantLinkRelation->default_location_id;
                        }

                    }

                }

            } else {

                // process one way
                $dealers[$key]['row_type'] = 'oneway';

                $oneWayRelation = OnewayRelation::where('oneway_id', $dealer->company_id)->where('ptype', 'dealer')->first();
                if (!is_null($oneWayRelation)) {
                    $dealers[$key]['status'] = $oneWayRelation->status;
                    $dealers[$key]['merchant_link_relation_id'] = $oneWayRelation->id;

                    if (!is_null($oneWayRelation->default_location_id)) {
                        $location = location::where('id', $oneWayRelation->default_location_id)->first();
                        $dealers[$key]['merchant_location'] = $location->branch;
                        $dealers[$key]['merchant_location_id'] = $oneWayRelation->default_location_id;
                    }

                }

            }

        }



        $response = [
            'data' => $dealers,
            'recordsTotal' => $dealers->count(),
            'recordsFiltered' => $dealers->count()
        ];
        return response()->json($response);
    }

    public function getOwnwayMerchantData($companyId){
        $oneway = Oneway::where('id', $companyId)->first();
        return response()->json($oneway);
    }

    /**
     * save inventory cost
     * @param Request $request
     */
    public function saveInventoryCost(Request $request) {
//        copy:
        $documentNo = inventorycost::where('doc_no', $request->input('documentNo'))->first();
        if ($documentNo != null) {
            return response()->json(['msg' => 'Document No Already Exist', 'status' => 'false']);
        }

        //$userId = Auth::user()->id;
        $userId = $this->getCompanyUserId();

        $merchant = Merchant::select('merchant.id as id')
            ->join('company', 'company.id', '=', 'merchant.company_id')
            ->where('company.owner_user_id', $userId)->first();

        if ($merchant == null) {
            return response()->json(['msg' => 'Buyer Merchant ID not exist', 'status' => 'false']);
        }

        $inventoryCost = new inventorycost();
        $inventoryCost->seller_merchant_id = $request->input('merchantId');
        $inventoryCost->buyer_merchant_id = $merchant->id;
        $inventoryCost->doc_date = date('Y-m-d', strtotime($request->input('dated')));
        $inventoryCost->doc_no = $request->input('documentNo');
        $inventoryCost->save();

        $inventoryCostId = $inventoryCost->id;

        $products = $request->input('products');
        foreach ($products as $product) {
            $inventoryCostProduct = new inventorycostproduct();
            $inventoryCostProduct->inventorycost_id = $inventoryCostId;
            $inventoryCostProduct->product_id = $product['productId'];
            $inventoryCostProduct->quantity = $product['qty'];
            $inventoryCostProduct->cost = $product['productCost'] * 100;
            $inventoryCostProduct->save();
        }

        return response()->json(['msg' => 'Inventory Cost saved successfully', 'status' => 'true']);
    }

    public function saveMerchantCreditLimit(Request $request)
    {
        $userData = new UserData();
        $supplierMerchantId = $userData->company_id();
        $dealerMerchantId = $request->input('merchantId');
        $creditLimitId = $request->input('creditLimitId');
        $creditLimit = (float)str_replace(",", "", $request->input('creditLimit'));
        $creditLimit = $creditLimit * 100;

        if ($creditLimitId != '') {
            $merchantCreditLimit = MerchantCreditLimit::find($creditLimitId);
        } else {
            $merchantCreditLimit = new MerchantCreditLimit();
        }
        $merchantCreditLimit->dealer_merchant_id = $dealerMerchantId;
        $merchantCreditLimit->supplier_merchant_id = $supplierMerchantId;
        $merchantCreditLimit->credit_limit = $creditLimit;
        $merchantCreditLimit->save();
        return response()->json(['msg' => 'Credit limit updated successfully', 'status' => 'true']);
    }


    public function saveMerchantTwoWayLinking(Request $request)
    {
        //$initiatorUserId = Auth::user()->id;
        $initiatorUserId = $this->getCompanyUserId();

        $responder = $request->input('merchant_id');
        $merchant = Company::where('systemid', $responder)->first();
        if ($merchant !== null) {
            $responderUserId = $merchant->owner_user_id;
            if ($initiatorUserId == $responderUserId) {
                return response()->json([
					'msg' => 'A merchant cannot add himself',
					'status' => 'false']);
            }

			Log::debug('TW responder='.$responder);
			Log::debug('TW responderUserId='.$responderUserId);
			Log::debug('TW initiatorUserId='.$initiatorUserId);

            $merchantLink = MerchantLink::
				where('responder_user_id', $responderUserId)->
				where('initiator_user_id', $initiatorUserId)->
				first();

			if (!empty($merchantLink)) {
				Log::debug('TW merchantLink='.json_encode($merchantLink));
				Log::debug('TW merchantLink->initiator_user_id='.
					$merchantLink->initiator_user_id);
				Log::debug('TW merchantLink->responder_user_id='.
					$merchantLink->responder_user_id);
			}

            if (!empty($merchantLink) &&
				$merchantLink->initiator_user_id == $initiatorUserId &&
				$merchantLink->responder_user_id == $responderUserId) {
                return response()->json([
					'msg' => 'Merchant ID already added',
					'status' => 'false'
				]);

            } else {
                // Add Two way linking
                $mLink = new MerchantLink();
                $mLink->initiator_user_id = $initiatorUserId;
                $mLink->responder_user_id = $responderUserId;
                $mLink->save();
                return response()->json([
					'msg' => 'Merchant ID added successfully',
					'status' => 'true'
				]);
            }

        } else {
            return response()->json([
				'msg' => 'Merchant ID not found',
				'status' => 'false'
			]);
        }
    }

    public function saveMerchantDefaultLocation(Request $request) {
        $locationId = $request->input('locationId');
        $rowType = $request->input('rowType');
        $linkingId = $request->input('linkingId');

        $status = false;
        if ($rowType == 'own') {
            $type = $request->input('type');
            $userData = new UserData();
            $merchantId = $userData->company_id();
            $merchant = Merchant::where('id', $merchantId)->first();
            if ($type == 'supplier') {
                $merchant->supplier_default_location_id = $locationId;
            } else {
                $merchant->dealer_default_location_id = $locationId;
            }
            $merchant->save();
            $status = true;
        } elseif ($rowType == 'oneway') {
            $oneWayRelation = OnewayRelation::where('id', $linkingId)->first();
            if ($oneWayRelation != null) {
                $oneWayRelation->default_location_id = $locationId;
                $oneWayRelation->save();
            }
            $status = true;
        } elseif ($rowType == 'twoway') {
            $twoWayRelation = MerchantLinkRelation::where('id', $linkingId)->first();
            if ($twoWayRelation != null) {
                $twoWayRelation->default_location_id = $locationId;
                $twoWayRelation->save();
            }
            $status = true;
        }

        if ($status) {
            return response()->json(['msg' => 'Default location save successfully', 'status' => 'true']);
        } else {
            return response()->json(['msg' => 'Default location not saved', 'status' => 'false']);
        }




    }

    public function delMerchantOnyWay(Request $request) {
        $oneWayId = $request->input('companyId');
        Oneway::find($oneWayId)->delete();
        OnewayRelation::where('oneway_id', $oneWayId)->delete();
        return response()->json(['status' => 'true']);
    }


    public function delMerchantTwoWayLinking(Request $request)
    {
        $selectedMerchantId = $request->input('selectedMerchantId');
        $foodCourtMerchant = FoodCourtMerchant::where('tenant_merchant_id', $selectedMerchantId)->get();
        foreach($foodCourtMerchant as $fcMerchant) {
            $fcMerchantTerminals = FoodCourtMerchantTerminal::where('foodcourtmerchant_id', $fcMerchant->id)->get();
            foreach($fcMerchantTerminals as $fcMerchantTerminal) {
                terminal::where('id', $fcMerchantTerminal->terminal_id)->delete();
            }
            FoodCourtMerchantTerminal::where('foodcourtmerchant_id', $fcMerchant->id)->delete();
        }

        FoodCourtMerchant::where('tenant_merchant_id', $selectedMerchantId)->delete();

        $merchantLinkId = $request->input('merchantLinkId');
        MerchantLink::find($merchantLinkId)->delete();
        MerchantLinkRelation::where('merchantlink_id', $merchantLinkId)->delete();
        return response()->json(['status' => 'true']);
    }

    public function getMerchantLocations($merchantId) {
        $ids = merchantlocation::where('merchant_id', $merchantId)->pluck('location_id');
        $location = location::whereIn('id', $ids)->latest()->get();
        $response = [
            'data' => $location,
            'recordsTotal' => location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->count(),
            'recordsFiltered' => location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->count()
        ];
        return response()->json($response);

    }

    public function saveMerchantOneway(Request $request) {
        $userData = new UserData();
        $selfMerchantId = $userData->company_id();

        $companyId = $request->input('company_id');

        if ($companyId != '') {
            $oneWay = Oneway::where('id', $companyId)->first();
        } else {
            $oneWay = new Oneway();
        }

        $oneWay->self_merchant_id = $selfMerchantId;
        $oneWay->company_name = $request->input('company_name');
        $oneWay->business_reg_no = $request->input('business_reg_no');
        $oneWay->address = $request->input('address');
        $oneWay->contact_name = $request->input('contact_name');
        $oneWay->mobile_no = $request->input('mobile_no');
        $oneWay->save();
        return response()->json(['msg' => $companyId != '' ? 'Merchant updated successfully' :  'Merchant added successfully', 'status' => 'true']);

    }

    public function saveOnewayRelation(Request $request) {
        $onewayRelation = new OnewayRelation();
        $onewayRelation->oneway_id = $request->input('companyId');
        $onewayRelation->ptype = $request->input('ptype');
        $onewayRelation->status = $request->input('status');
        $onewayRelation->save();
        return response()->json(['msg' => 'Status updated successfully', 'status' => 'true']);
    }

    public function changeOnewayRelationStatus(Request $request) {
        $onewayRelation = OnewayRelation::find($request->input('merchantLinkRelationId'));
        $onewayRelation->status = $request->input('status');
        $onewayRelation->save();
        return response()->json(['msg' => 'Status updated successfully', 'status' => 'true']);
    }

    public function saveMerchantLinkRelation(Request $request)
    {
        $merchantLinkRelation = new MerchantLinkRelation();
        $merchantLinkRelation->merchantlink_id = $request->input('merchantLinkId');
        $merchantLinkRelation->ptype = $request->input('ptype');
        $merchantLinkRelation->status = $request->input('status');
        $merchantLinkRelation->save();
        return response()->json(['msg' => 'Merchant ID added successfully', 'status' => 'true']);
    }

    public function deactivateMerchantLinkRelation(Request $request)
    {
        $merchantLinkRelationId = $request->input('merchantLinkRelationId');
        $status = $request->input('status');
        $merchantLinkRelation = MerchantLinkRelation::find($merchantLinkRelationId);
        $merchantLinkRelation->status = $status;
        $merchantLinkRelation->save();
        return response()->json(['msg' => 'Status deactivated successfully', 'status' => 'true']);
    }

    public function activateMerchantLinkRelation(Request $request)
    {
        $merchantLinkId = $request->input('merchantLinkId');
        $responderUserId = $request->input('merchantUserId');
        $merchantLinkRelationId = $request->input('merchantLinkRelationId');
        //$initiaterUserId = Auth::user()->id;
        $initiaterUserId = $this->getCompanyUserId();

        /*
        $merchantLink = MerchantLink::find($merchantLinkId);
        $merchantLink->initiator_user_id = $initiaterUserId;
        $merchantLink->responder_user_id = $responderUserId;
        $merchantLink->save();
        */
        MerchantLinkRelation::find($merchantLinkRelationId)->delete();
        return response()->json(['msg' => 'Request send successfully', 'status' => 'true']);
    }

    public function showDocumentSupplierView($merchant_id){
        $user_data = new UserData();

    	$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;    
        } else {
            $is_king  = false;
        }
        $ids = merchantproduct::where('merchant_id',
            $user_data->company_id())->pluck('product_id');

        $inventory_data = product::whereIn('ptype',
			['inventory', 'rawmaterial', 'warranty'])->
			whereNotNull('name')->whereIn('id', $ids)->get();

    	return view('data.documentsupplier',compact(
			'user_roles','is_king', 'inventory_data','merchant_id'
        ));
       
    }


    public function showDocumentDealerView($merchant_id){
//        flag:
        $user_data = new UserData();

    	$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;    
        } else {
            $is_king  = false;
        }
       
        $ids = merchantproduct::where('merchant_id',
            $user_data->company_id())->pluck('product_id');

        $inventory_data = product::whereIn('ptype',
			['inventory', 'customization'])->
			whereNotNull('name')->
			whereIn('id', $ids)->get();
        // ['inventory', 'rawmaterial', 'warranty'] // remove rawmaterial from products for now.

        $company_detail =  \App\Models\Company::where('id',
            $merchant_id)->first();
     //   dd($company_detail);

        $currency=  \App\Models\Currency::where('id',
           $company_detail->currency_id)->first();
         //  dd( $curreny);
        $warranty_prd_ids = product::whereIn('ptype',
            ['warranty'])->
            whereNotNull('name')->
            whereIn('id', $ids)->pluck('id');

        $pro_prd_ids = product::whereIn('ptype',
            ['customization'])->
            whereNotNull('name')->
            whereNotNull('prdcategory_id')->
            whereIn('id', $ids)->pluck('id');

        $pro_inventory_ids = product::whereIn('ptype',
            ['inventory'])->
            whereNotNull('name')->
            whereNotNull('photo_1')->
            whereNotNull('prdcategory_id')->
            whereNotNull('prdsubcategory_id')->
            whereNotNull('prdprdcategory_id')->
            whereIn('id', $ids)->pluck('id');

        // followed prices from warranty
        $warranty_price = warranty::
            whereNull('deleted_at')->
            whereIn('product_id', $warranty_prd_ids)->pluck('price', 'product_id');

    // followed prices from pro service
        $proservice_price = prd_proservices::
            whereNull('deleted_at')->
            whereIn('product_id',  $pro_prd_ids )->pluck('price', 'product_id');

    // followed prices from inventory
        $inventory_price = prd_inventory::
            whereNull('deleted_at')->
            whereIn('product_id',  $pro_inventory_ids )->pluck('price', 'product_id');
    

        // Convert to original - float
        foreach ($warranty_price as $key => $value) {
            $in_float = $value / 100;
            // $warranty_price[$key] = is_int($in_float) ? $in_float.'.00' : $in_float;
            $warranty_price[$key] = $in_float;
        }
 

         foreach ($proservice_price as $key => $value) {
            $in_float = $value / 100;
            // $warranty_price[$key] = is_int($in_float) ? $in_float.'.00' : $in_float;
            $proservice_price[$key] = number_format($in_float, 2);
        }
 

        foreach ($inventory_data as $key => $value) {
            # code...
            if($value->ptype =='inventory'){
                if( $inventory_price[$value->id]==null){
                 unset($inventory_data[$key]);

                }
            }
            else if($value->ptype =='warranty'){
                if( $warranty_price[$value->id]==null){
                 unset($inventory_data[$key]);

                }
            }
            else if($value->ptype =='customization'){
                if( $proservice_price[$value->id]==null){
                 unset($inventory_data[$key]);

                }
            }
            
        }
      
        // followed prices from wholesales
        $inventory_idx = product::whereIn('ptype',
            ['inventory'])->
            whereNotNull('name')->
            whereIn('id', $ids)->pluck('id');

        $wholesale_prices = new Wholesale();
        $product_whole_sale_price_and_range = [];

        foreach ($inventory_idx as $key => $value) {
            $wholesale = $wholesale_prices->where('product_id', $value)->get()->toArray();
          
            if (count($wholesale) !== 0) {
                $price_in_float = $wholesale[0]['price'] / 100;
                $per_item_whole_sale_price = $price_in_float ;  /// $wholesale[0]['unit']
                $wholesale[0]['per_item_whole_sale_price'] =number_format($per_item_whole_sale_price, 2);
            } else {
                $wholesale = null;
            }
           

            $product_whole_sale_price_and_range[$value] = $wholesale;
        }

    	return view('data.documentdealer',compact(
			'user_roles',
            'is_king',
            'inventory_data',
            'merchant_id',
            'company_detail',
            'warranty_price',
            'proservice_price',
            'currency',
            'product_whole_sale_price_and_range'
		));
    }

    public function viewDocumentInventoryCost($inventoryCostId)
    {
        $inventoryCost = inventorycost::find($inventoryCostId);
        if ($inventoryCost != null) {

            //$id = Auth::user()->id;
            $id = $this->getCompanyUserId();
            $user_data = new UserData();
            $user_data->exit_merchant();
            $user_roles = usersrole::where('user_id',$id)->get();
            $is_king =  \App\Models\Company::where('owner_user_id',
				Auth::user()->id)->first();

            $is_king = $is_king != null ? true : false;

            $inventory_data = inventorycostproduct::select('quantity', 'cost', 'product.*')->
				join('product', 'product.id', '=', 'inventorycostproduct.product_id')->
				where('inventorycostproduct.inventorycost_id', $inventoryCost->id)->get();

            $merchant_data = Merchant::select('company.name', 'company.systemId')->
				leftjoin('company','company.id','=','merchant.company_id')->
				where('merchant.id', $inventoryCost->buyer_merchant_id)->first();

            return view('data.viewDocumentInventoryCost',compact(
				'user_roles','is_king', 'inventory_data', 'merchant_data','inventoryCost'
			));
        }
    }


    public function showDocumentInventoryCostView($merchant_id){

        //$id = Auth::user()->id;
        $id = $this->getCompanyUserId();
        $user_data = new UserData();
        $user_data->exit_merchant();
        $user_roles = usersrole::where('user_id',$id)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        $is_king = $is_king != null ? true : false;

        $ids = merchantproduct::where('merchant_id',
            $user_data->company_id())->pluck('product_id');

        $inventory_data = product::whereIn('ptype', ['inventory', 'rawmaterial'])->
			whereNotNull('name')->
			whereIn('id', $ids)->get();

        $merchant_data = Merchant::select('company.name', 'company.systemId')->
			leftjoin('company','company.id','=','merchant.company_id')->
			where('merchant.id', $merchant_id)->
			first();

        return view('data.inventoryCost',compact(
			'user_roles','is_king', 'inventory_data', 'merchant_id', 'merchant_data'
		));
    }


    public function showConsignmentView()
    {
        // $id = $this->getCompanyUserId();
        // $user_data = new UserData();
        // $user_data->exit_merchant();
        // $user_roles = usersrole::where('user_id',$id)->get();
        // $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        // $is_king = $is_king != null ? true : false;
        return view('consignment.consignment');
        // ,compact('user_roles','is_king', 'merchant_id')

    }

    public function showDocumentInventoryCostLoadData(){
        try {
            $prd_inventory_ids = prd_inventory::where([['price', '!=', 'NULL']])->
				pluck('product_id')->toArray();

            $prd_rawmaterial_ids = rawmaterial::where([['price', '!=', 'NULL']])->
				pluck('product_id')->toArray();

            $filter=array_merge($prd_inventory_ids,$prd_rawmaterial_ids);
			$data  = product::where([['prdcategory_id', '!=', 'NULL'],
				['name', '!=', 'NULL']])->
				whereIn('id', $filter)->
				latest()->get();

        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('product_id', function ($product) {
                return '<p style="padding:0;margin:0;">' . $product->systemid.'</p>';
            })
            ->addColumn('product_name', function ($product) {
                if (!empty($product->thumbnail_1)) {
                    $img_src = '/images/product/' . $product->id . '/thumb/' . $product->thumbnail_1;
                    $img     = "<img src='$img_src' data-field='product_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'>";
                } else {
                    $img = null;
                }
                return $img . '<p class="os- linkcolor" data-field="restaurantnservices_pro_name" style="cursor: pointer; margin: 0;display: inline-block;color:#007bff;padding:0;">' . (!empty($product->name) ? $product->name : 'Product Name') . '</p>';
            })
            ->addColumn('product_price', function ($product) {
                return '<a href="JavaScript:void(0)" class="priceOutput currentprice" data-toggle="modal" data-target="#costPriceModal" style="color: #007bff;margin:0;text-decoration:none;" >0.00</a>';
            })
             ->addColumn('product_qty', function ($product) {
                return '<a href="JavaScript:void(0)" class="qtyOutput" data-toggle="modal" data-target="#costQtyModal" style="color: #007bff;margin:0;text-decoration:none;" >1</a>';
            })
              ->addColumn('product_amount', function ($location) {
                return '<p class="product_amount" style="padding:0;margin:0;">0</p>';
            })
            ->escapeColumns([])
            ->make(true);
                
        } catch (\Exception $e) {
			Log::error(
				"Error @ ".$e->getLine()." file ".$e->getFile().":".$e->getMessage()
			);
        }
    }

    public function save_unconfirmed_data(Request $request)
    {
        $systemid = new SystemID('stockreport');
        $stockreport = new stockreport();
        $stockreport->systemid =$systemid;
        $stockreport->creator_user_id = Auth::user()->id;
        $stockreport->type = 'transfer';
        $stockreport->location_id = $request->location_id;
        $stockreport->dest_location_id = $request->dest_location_id;

        $stockreport->save();

        foreach ($request->products as $product)
        {
            $stockreportproduct = new stockreportproduct();
            $stockreportproduct->product_id = $product['id'];
            $stockreportproduct->quantity = $product['qty'];
            $stockreportproduct->stockreport_id = $stockreport->id;
            $stockreportproduct->save();
        }

        return view('data.trackingconfirm', ["id", $stockreportproduct->id]);

    }

    public function showDocumenttrackingConfirmView($stockreport_id, Request $request)
    {
        $stockreport = StockReport::find($stockreport_id);
        $stockreport->created_date = Carbon::parse($stockreport->created_at)->format('dMy H:i:s');
        $stockreport->received_tstamp = !empty( $stockreport->received_tstamp ) ? Carbon::parse($stockreport->received_tstamp)->format('dMy H:i:s') : '';

        $stockreport->location_from = location::find($stockreport->location_id);
        $stockreport->location_to = location::find($stockreport->dest_location_id);

        $stockreport->creator_user = User::find($stockreport->creator_user_id);
        $stockreport->receiver_user = !empty($stockreport->receiver_user_id) ? User::find($stockreport->receiver_user_id) : '';
		//dd($stockreport->receiver_user);

        $stockreportproducts = stockreportproduct::where('stockreport_id', $stockreport->id)->get();


//        print_r(  Auth::user()->name );exit;
        $this->user_data = new UserData();
        $ids = merchantlocation::where('merchant_id',
            $this->user_data->company_id())->
            pluck('location_id');

        $locations = location::where([['branch', '!=', 'null']])->
            whereIn('id', $ids)->latest()->
            get();



        return view('data.trackingconfirm',compact(
            'stockreport', 'stockreportproducts', 'locations'
        ));
    }

    public function save_received_report_data(Request $request)
    {
        $stockreport = StockReport::find($request->stockreport_id);
        $stockreport->status = 'confirmed';
        $stockreport->receiver_user_id = Auth::user()->id;
        $stockreport->received_tstamp = Carbon::now()->toDateTimeString();
        $stockreport->save();

        foreach ($request->products as $product)
        {
            $stockreportproduct = stockreportproduct::find($product['id']);
            $stockreportproduct->received = $product['received'];
            $stockreportproduct->status = !empty($product['received']) ? 'checked' : 'unchecked';
            $stockreportproduct->save();
        }

        return 'Staff Name: '.Auth::user()->name.' <br>
                Staff ID: '.Auth::user()->staff->systemid.' <br>
                Date: '.Carbon::parse($stockreport->received_tstamp)->format('dMy H:i:s');

    }

    public function showInventoryPriceRange(Request $request) {
        $product_id = (int) $request->productId;

        $product_whole_sale_price_and_range = Wholesale::
            where('product_id', $product_id)
                ->get()
                ->toArray();

        return view('data.inventory-price-range-modals', compact([
            'product_whole_sale_price_and_range']));
    }
}
