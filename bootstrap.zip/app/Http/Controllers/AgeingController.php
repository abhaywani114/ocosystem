<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\usersrole;
use App\Models\role;
use App\Models\Company;
class AgeingController extends Controller
{
  public function __construct()
  {
      $this->middleware('auth');
       $this->middleware('CheckRole:stg');
  }

  public function ShowAgeingView() {
        $id = Auth::user()->id;
        return view('ageing.ageing');
  }
  public function ContraView($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.contra',compact('user_roles','is_king'));
  }
  public function CreditorAllTransactions($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.creditor_all_transactions',compact('user_roles','is_king'));
  }
  public function CreditorBalance($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.creditor_balance',compact('user_roles','is_king'));
  }
  public function CreditorDetails($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.creditor_details',compact('user_roles','is_king'));
  }
  public function DebtorAllTransactions($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.debtor_all_transactions',compact('user_roles','is_king'));
  }
  public function DebtorBalance($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.debtor_balance',compact('user_roles','is_king'));
  }
  public function DebtorDetails($id){
    $user_id = Auth::user()->id;
    $user_roles = usersrole::where('user_id',$user_id)->get();
    $is_king =  Company::where('owner_user_id',Auth::user()->id)->get();
    return view('ageing.debtor_details',compact('user_roles','is_king'));
  }
}
