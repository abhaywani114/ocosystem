<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MobRepairMaintenanceController extends Controller
{
    //
}
