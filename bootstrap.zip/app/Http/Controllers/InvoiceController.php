<?php

namespace App\Http\Controllers;

use App\Classes\SystemID;
use App\Classes\UserData;
use App\Models\Company;
use App\Models\InvoiceProduct;
use App\Models\Merchant;
use App\Models\MerchantCreditLimit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\usersrole;
use \App\Models\Invoice;


class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getCompanyUserId()
    {
        $userData = new UserData();
        $companyId = $userData->company_id();
        $company = Company::find($companyId);
        return $company->owner_user_id;
    }
    
    function showIssuedInvoiceView($invoice_id){
        $userData = new UserData();
        $user_name = Auth::user()->name;
        // get invoice detail
        $invoice_id = (int) $invoice_id;
        $invoice = Invoice::where(['id'=> $invoice_id])->first();
        $dealer_merchant_id = $invoice->dealer_merchant_id;
        $supplier_merchant_id = $invoice->supplier_merchant_id;
        $staff_user_id = $invoice->staff_user_id;
        $systemid = $invoice->systemid;

        // get credit limits
        $merchant_credit_limit = MerchantCreditLimit::where(
            [
                'dealer_merchant_id'=> $dealer_merchant_id,
                'supplier_merchant_id'=> $supplier_merchant_id
            ])->first();

        // get invoice products
        $invoice_products = InvoiceProduct::where(['invoice_id'=> $invoice_id])
            ->join('product', 'invoiceproduct.product_id', '=', 'product.id')
            ->join('prd_warranty', 'invoiceproduct.product_id', '=', 'prd_warranty.product_id')
            ->get();

        // get total price of the invoice
        $total_price = 0;
        foreach ($invoice_products as $key => $product) {
            $product_qty_price = $product->quantity * $product->price;
            $total_price = $total_price + $product_qty_price;
        }
        $total_price_format = $total_price / 100;

        // will deal wholesale seperately. As have to handle ranges there.

        return view('invoice.invoice', compact(
            'invoice',
            'merchant_credit_limit',
            'invoice_products',
            'user_name',
            'total_price_format'
        ));
    }

    function showReceivedInvoiceView(){
     return view('invoice.invoice');
    }
    function showInvoiceIssuedListView()
    {
    	$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
        $invoice_id=12;

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
    	return view('invoice.invoice_issued_list',compact('user_roles','is_king','invoice_id'));
    }

    function showInvoiceReceivedListView()
    {
    	$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
        $invoice_id=12;

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
    	return view('invoice.invoice_received_list',compact('user_roles','is_king','invoice_id'));
    }

    public function createInvoice(Request $request) {
        $invoice = new Invoice();
        $a = new SystemID('invoice');
        $system_id = $a->__toString();
        $user_id = Auth::user()->id;

        $owner_user_id = $this->getCompanyUserId();
        $merchant = Merchant::select('merchant.id as id')
            ->join('company', 'company.id', '=', 'merchant.company_id')
            ->where('company.owner_user_id', $owner_user_id)->first();

        $supplier_merchant_id = $merchant->id;
        $dealer_merchant_id = (int) $request['merchantId'];

        // check available credit limit
        // merchant credit limit
        $mc_limit =
            MerchantCreditLimit::where('dealer_merchant_id', $dealer_merchant_id)
                ->where('supplier_merchant_id', $supplier_merchant_id)
                ->first();

        // total demanding credit
        $total_credit_demanding = (float) $request['totalCredit'];
        $credit_limit = $mc_limit['credit_limit'] / 100;
        $avail_credit_limit = $mc_limit['avail_credit_limit'] / 100;

        $allowed_credit_limit = $credit_limit - $avail_credit_limit;
        if ($allowed_credit_limit < $total_credit_demanding) {
            return response()->json(['msg' => 'not allowed to avail', 'status' => 'false', 'allowed_credit_limit' => $allowed_credit_limit]);
        } else {
            // update avail limit
            $now_total_availed = $avail_credit_limit + $total_credit_demanding;
            $now_total_availed_to_int = $now_total_availed * 100; // convert to int from 10.10 to 1010.

            MerchantCreditLimit::where('id', $mc_limit['id'])
                ->update(['avail_credit_limit' => $now_total_availed_to_int]);
        }

        // save invoice and get invoice id.
        $invoice->systemid = $system_id;
        $invoice->supplier_merchant_id = $supplier_merchant_id;
        $invoice->dealer_merchant_id = $dealer_merchant_id;
        $invoice->deliveryorder_id = 0; // scheme still not build.
        $invoice->staff_user_id = $user_id;
        $invoice->save();
        // saved invoice id
        $invoice_id = $invoice->id;

        // save invoice products and Qty
        $products = $request['products'];
        foreach ($products as $product) {
            $invoiceProduct = new InvoiceProduct();
            $invoiceProduct->invoice_id = $invoice_id;
            $invoiceProduct->product_id = (int) $product['productId'];
            $invoiceProduct->quantity = (int) $product['qty'];

            $invoiceProduct->save();
        }

        return response()
            ->json([
                'msg' => 'saved successfully',
                'status' => 'true',
                'invoice_id' => $invoice_id
            ]);
    }
}
