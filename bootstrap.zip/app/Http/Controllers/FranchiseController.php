<?php

namespace App\Http\Controllers;

//use App\FranchiseMerchantLoc;
use App\Models\FranchiseMerchantLoc;
use Illuminate\Http\Request;
use App\Classes\UserData;
use \App\Models\usersrole;
use \Illuminate\Support\Facades\Auth;
use App\Models\Franchise;
use App\Models\FranchiseMerchant;
use App\Models\MerchantLink;
use App\Models\Company;
use Yajra\DataTables\DataTables;
use \App\Classes\SystemID;
use Illuminate\Support\Facades\Validator;
use App\Models\Merchant;
use App\Models\merchantlocation;
use App\Models\MerchantLinkRelation;
use App\Models\opos_receipt;
use App\Models\location;
use Illuminate\Support\Facades\Input;
use App\Models\terminal;
use App\Models\locationterminal;
use App\Models\FranchiseMerchantLocTerm;
use Log;

class FranchiseController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showFranchiseManagement() {

        $user_data = new UserData();

        $merchantId = $user_data->company_id();

        $user_roles = usersrole::where('user_id',$merchantId)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        $is_king = $is_king != null ? true : false;

        $franchises = Franchise::where('owner_merchant_id', $merchantId)->get();

        return view('franchise.franchise_management', compact('user_roles', 'is_king', 'franchises'));
    }


    public function showFranchiseList($id){
        $user_data = new UserData();
        $merchantId = $user_data->company_id();
        $user_roles = usersrole::where('user_id',$merchantId)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        return view('franchise.franchise_list',compact('id', 'user_roles', 'is_king'));
    }


    public function showFranchiseTerminalList(){
        $user_data = new UserData();
        $merchantId = $user_data->company_id();
        $user_roles = usersrole::where('user_id',$merchantId)->get();
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        return view('franchise.franchise_terminal_list', compact('user_roles', 'is_king'));
    }
    
    /**
     * save franchise management data
     * 
     * @param Request $request
     * @return type
     */
    public function saveFranchise(Request $request)
    {
		//Create a new product here
        try {
        $userData = new UserData();
        $SystemID = new SystemID('franchise');
        $merchantId = $userData->company_id();
            
        $franchise = new Franchise();
        $franchise->owner_merchant_id = $merchantId;
        $franchise->systemid = $SystemID;;
        $franchise->name = 'Franchise Name';
        $franchise->save();

		Log::debug('SF saveFranchise(): AFTER save()');

        $thisuserID = $this->getCompanyUserId();

        $franchisee_user_id = MerchantLink::where("initiator_user_id" ,
			$thisuserID)->pluck("responder_user_id");

        foreach ($franchisee_user_id as $item) {
            $company_id = Company::where("owner_user_id" , $item)->
				first()->id;
            $franchise_merchant_id = Merchant::where("company_id",
				$company_id)->first()->id;

            $check = FranchiseMerchant::where("franchise_id" ,
				$franchise->id)->
				where("franchisee_merchant_id" , $franchise_merchant_id)->
				where("deleted_at" , NULL)->count();

            if($check == 0){
                $franchiseMerchant = new FranchiseMerchant;
                $franchiseMerchant->franchise_id = $franchise->id;
                $franchiseMerchant->franchisee_merchant_id = $franchise_merchant_id;
                $franchiseMerchant->status = "inactive";
                $franchiseMerchant->save();
            }
        }
		
		$franchisee_user_id = MerchantLink::where("responder_user_id" , $thisuserID)->pluck("initiator_user_id");
        foreach ($franchisee_user_id as $item) {
            $company_id = Company::where("owner_user_id" , $item)->first()->id;
            $franchise_merchant_id = Merchant::where("company_id" , $company_id)->first()->id;
            $check = FranchiseMerchant::where("franchise_id" , $franchise->id)->where("franchisee_merchant_id" , $franchise_merchant_id)->where("deleted_at" , NULL)->count();
            if($check == 0){
                $franchiseMerchant = new FranchiseMerchant;
                $franchiseMerchant->franchise_id = $franchise->id;
                $franchiseMerchant->franchisee_merchant_id = $franchise_merchant_id;
                $franchiseMerchant->status = "inactive";
                $franchiseMerchant->save();
            }
        }		
		

        return response()->json([
			'msg' => 'Franchise added successfully',
			'status' => 'true'
		]);

        } catch (\Exception $e) {
            return response()->json([
				'msg' => $e->getMessage(),
				'status' => 'false'
			]);
        }
    }

    public function saveFranchiseMerchantLocation(Request $request){
        //Create a new product here
        try {
            $merchantId = $request->merchantId;
            if($request->locationIds){
                $selectedLocationIds = FranchiseMerchantLoc::where('franchisemerchant_id', $merchantId)->whereNotIn('location_id', $request->locationIds)->delete();
                foreach ($request->locationIds as $locationId) {
                    $selectedLocationId = FranchiseMerchantLoc::where('franchisemerchant_id', $merchantId)->where('location_id', $locationId)->count();
                    if (!$selectedLocationId){
                        $franchise = new FranchiseMerchantLoc();
                        $franchise->franchisemerchant_id = $merchantId;
                        $franchise->location_id = $locationId;        
                        $franchise->save();
                    }
                }
            } else {
                FranchiseMerchantLoc::where('franchisemerchant_id', $merchantId)->delete();
            }
            return response()->json([
                'msg' => 'Franchise Merchant Location added successfully',
                'status' => 'true'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'msg' => $e->getMessage(),
                'status' => 'false'
            ]);
        }        
    }

    public function getCompanyUserId()
    {
        $userData = new UserData();
        $companyId = $userData->company_id();
        $company = Company::find($companyId);
        return $company->owner_user_id;
    }

    /***************************/                        
    /*  PRODUCTS OF FRANCHISE  */
    /***************************/

    public function getFranchiseProducts($franchiseid){
        //Log::debug('franchise id'.json_encode($franchiseid));
        return view('franchise.franchise_products');
    }

    public function getFranchiseMerchants($id, Request $request)
    {
		//dd($id);
        $userId = $this->getCompanyUserId();

        $responderIds = MerchantLink::where('initiator_user_id', $userId)->pluck('responder_user_id')->toArray();
        $initiatorIds = MerchantLink::where('responder_user_id', $userId)->pluck('initiator_user_id')->toArray();

        $merchantUserIds = array_merge($responderIds, $initiatorIds);
	//	dd($merchantUserIds);
        $query = Company::select('company.id as company_id',
            'company.name as company_name',
            'company.business_reg_no as company_business_reg_no',
            'company.systemid as company_system_id',
            'company.owner_user_id',
            'merchant.id as merchant_id'
        )->join('merchant', 'merchant.company_id', '=', 'company.id')
            ->whereIn('company.owner_user_id', $merchantUserIds);

        ;
            

        $merchants = $query->get();
		
	//	 dd($merchants);

        $counter = 0;
        foreach ($merchants as $key => $merchant) {
            $merchants[$key]['indexNumber'] = ++$counter;
            $merchants[$key]['merchant_link_id'] = 0;
            $merchants[$key]['merchant_link_relation_id'] = 0;
            $merchants[$key]['merchant_location'] = 'Location';
            $merchants[$key]['merchant_location_id'] = '';
            $merchants[$key]['franchise_merchant_locations'] = [];
            $merchants[$key]['franchiseMerchantLocTermResult'] = [];
            $merchants[$key]['merchant_royalty'] = '';
            $merchants[$key]['franchise_id'] = '';
            $merchants[$key]['franchisemerchant_id'] = 0;
            $merchants[$key]['franchise_has_transaction'] = '';
            $merchants[$key]['status'] = 'inactive';

            if (!is_null($merchant->merchant_id)) {
                $franchiseMerchantResult = FranchiseMerchant::where('franchisee_merchant_id', $merchant->merchant_id)
															->where('franchise_id', $id)->first();
                
                if (!empty($franchiseMerchantResult)) {
                    $merchants[$key]['merchant_royalty'] = $franchiseMerchantResult->overall_royalty;
                    $merchants[$key]['status'] = $franchiseMerchantResult->status;
                    $merchants[$key]['franchisemerchant_id'] = $franchiseMerchantResult->id;
                }
            }

            if (!is_null($merchant->merchant_id)) {
				$franchiseMerchantResult = FranchiseMerchant::where('franchisee_merchant_id', $merchant->merchant_id)
															->where('franchise_id', $id)->first();
				if(!is_null($franchiseMerchantResult)){											
					$franchiseMerchantLocationResult = FranchiseMerchantLoc::where('franchisemerchant_id', $franchiseMerchantResult->id)->get();
					$locationIds = [];
					for ($i=0; $i < count($franchiseMerchantLocationResult); $i++) { 
						$locationIds[] = $franchiseMerchantLocationResult[$i]->location_id;
					}
					$merchants[$key]['franchise_merchant_locations'] = $locationIds;
				}
            }
           

            if (!is_null($merchant->merchant_id)) {
				$franchiseMerchantResult = FranchiseMerchant::where('franchisee_merchant_id', $merchant->merchant_id)
															->where('franchise_id', $id)->first();
				if(!is_null($franchiseMerchantResult)){	
					$franchiseMerchantLocTermResult = FranchiseMerchantLocTerm::select('franchisemerchantlocterm.id', 'location.id as location_id', 'location.systemid as location_systemid', 'opos_terminal.systemid as terminal_systemid')
							->join('franchisemerchantloc', 'franchisemerchantloc.id', '=', 'franchisemerchantlocterm.franchisemerchantloc_id')
							->join('location', 'franchisemerchantloc.location_id', '=', 'location.id')
							->join('opos_terminal', 'opos_terminal.id', '=', 'franchisemerchantlocterm.terminal_id')
							->where('franchisemerchantloc.franchisemerchant_id', $franchiseMerchantResult->id)
							->whereNull('opos_terminal.deleted_at')
							->get();
					//dd($franchiseMerchantLocTermResult);
					$locationIds = [];
					for ($i=0; $i < count($franchiseMerchantLocTermResult); $i++) { 
						$locationIds[] = $franchiseMerchantLocTermResult[$i]->location_id;
					}
					
					//dd($locationIds);
					$merchants[$key]['franchiseMerchantLocTermResult'] = $locationIds;
				}
            }

            if (!is_null($merchant->merchant_id)) {
				$franchiseMerchantResult = FranchiseMerchant::where('franchisee_merchant_id', $merchant->merchant_id)
															->where('franchise_id', $id)->first();
				if(!is_null($franchiseMerchantResult)){	
					$franchiseHasTransaction = franchisemerchantlocterm::join('franchisemerchantloc', 'franchisemerchantloc.id', '=', 'franchisemerchantlocterm.franchisemerchantloc_id')
							->join('opos_receipt', 'opos_receipt.terminal_id', '=', 'franchisemerchantlocterm.terminal_id')
							->where('franchisemerchantloc.franchisemerchant_id', $merchant->merchant_id)
							->count();
					
					$merchants[$key]['franchise_has_transaction'] = $franchiseHasTransaction;
				}
            }

            if (!is_null($merchant->merchant_id)) {
                $merchantResult = Merchant::where('id', $merchant->merchant_id)->first();
                if (!is_null($merchantResult->supplier_default_location_id)) {
                    $merchantLocation = location::where('id', $merchantResult->supplier_default_location_id)->first();
                    $merchants[$key]['merchant_location'] = $merchantLocation->branch;
                    $merchants[$key]['merchant_location_id'] = $merchantResult->supplier_default_location_id;
                }
            }

            if (in_array($merchant->owner_user_id, $responderIds)) {
                $merchants[$key]['row_type'] = 'twoway';
                $merchants[$key]['responder'] = '0';
                $merchantLink = MerchantLink::where('initiator_user_id', $userId)->where('responder_user_id', $merchant->owner_user_id)->first();
                $merchants[$key]['merchant_link_id'] = $merchantLink->id;

                // initiator
                $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id', $merchantLink->id)->where('ptype', 'dealer')->first();
                if ($merchantLinkRelation != null) {
                    $merchants[$key]['merchant_link_relation_id'] = $merchantLinkRelation->id;

                    if (!is_null($merchantLinkRelation->default_location_id)) {
                        $location = location::where('id', $merchantLinkRelation->default_location_id)->first();
                        $merchants[$key]['merchant_location'] = $location->branch;
                        $merchants[$key]['merchant_location_id'] = $merchantLinkRelation->default_location_id;
                    }
                }

            }
            if (in_array($merchant->owner_user_id, $initiatorIds)) {
                $merchants[$key]['row_type'] = 'twoway';
                $merchantLink = MerchantLink::where('initiator_user_id', $merchant->owner_user_id)->where('responder_user_id', $userId)->first();
                $merchants[$key]['merchant_link_id'] = $merchantLink->id;
                $merchants[$key]['responder'] = '1';

                // responder
                $merchantLinkRelation = MerchantLinkRelation::where('merchantlink_id', $merchantLink->id)->where('ptype', 'supplier')->first();
                
                if ($merchantLinkRelation != null) {
                    $merchants[$key]['merchant_link_relation_id'] = $merchantLinkRelation->id;

                    if (!is_null($merchantLinkRelation->default_location_id)) {
                        Log::debug('default location es ' . json_encode($merchantLinkRelation->default_location_id));
                        $location = location::where('id', $merchantLinkRelation->default_location_id)->first();
                        Log::debug('location trae' . json_encode($location));
                        $merchants[$key]['merchant_location'] = $location->branch;
                        $merchants[$key]['merchant_location_id'] = $merchantLinkRelation->default_location_id;
                    }

                }

            }
        }

//        $selected_locations = FranchiseMerchantLoc::where('franchisemerchant_id', $merchant->franchisemerchant[0]->id)->pluck('location_id')->toArray();
//        $merchants[$key]['selected_locations'] = implode(',', $selected_locations);
        // $merchants[$key]['selected_locations'] = '';
//        $merchants[$key]['selected_locations_count'] = count($selected_locations);

		//dd($merchants);
        $response = [
            'data' => $merchants,
            'recordsTotal' => $query->get()->count(),
            'recordsFiltered' => $query->get()->count()
        ];
        return response()->json($response);


    }
    
    /**
     * get franchise management list using ajax
     * @return type
     */
    public function getFranchiseManagementList()
    {

        $this->user_data = new UserData();
        $model = new Franchise();
        $data = $model->where('owner_merchant_id', $this->user_data->company_id())->
			orderBy('created_at', 'asc')->
            latest()->get();
        
	
        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('og_franchise_id', function ($franchiseList) {
                return '<p class="os-linkcolor franchiseList" data-field="og_franchise_id" style="cursor: pointer; margin: 0; text-align: center;"><a href="franchise-list/' . $franchiseList->id . '" target="_blank">' . $franchiseList->systemid . '</a></p>';
            })
            ->addColumn('og_franchise_name', function ($franchiseList) {
                return '<p class="os-linkcolor" data-field="og_franchise_name" style="cursor: pointer; margin: 0;display:inline-block" onclick="details(' . $franchiseList->systemid . ')">' . (!empty($franchiseList->name) ? $franchiseList->name : 'Franchise Name') . '</p>';
            })
            ->addColumn('og_franchise_royalty', function ($franchiseList) {
                return '<p class="os-linkcolor" data-field="og_franchise_royalty" style="cursor: pointer; margin: 0;display:inline-block"
				onclick="">0.00</p>';
            })
            ->addColumn('og_franchise_product', function ($franchiseList) {
                return '<p class="os-linkcolor franchiseList" data-field="og_franchise_product" style="cursor: pointer; margin: 0; text-align: center;"><a href="franchise-products/' . $franchiseList->id . '" target="_blank">' . $franchiseList->id . '</a></p>';
                //return '<p class="os-linkcolor" data-field="og_franchise_product" style="cursor: pointer; margin: 0;display:inline-block"
				//onclick="">0</p>';
            })
            ->addColumn('deleted', function ($franchiseList) {

               // dump(json_encode($franchiseList));
               

               $franchiseHasTransaction = franchisemerchantlocterm::join('franchisemerchantloc', 'franchisemerchantloc.id', '=', 'franchisemerchantlocterm.franchisemerchantloc_id')
                            ->join('opos_receipt', 'opos_receipt.terminal_id', '=', 'franchisemerchantlocterm.terminal_id')
                            ->join('franchisemerchant', 'franchisemerchant.id', '=', 'franchisemerchantloc.franchisemerchant_id')
							->where('franchisemerchant.franchisee_merchant_id', $this->user_data->company_id())
							->count();
                
                            //Log::debug('company id' . json_encode($franchiseHasTransaction));

                if($franchiseHasTransaction != 0){
                    return '<p data-field="deleted"
                    onclick="removeFranchiseManagementModel('.$franchiseList->id.')"
                    style="background-color:gray;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor: pointer;"
                    class="text-danger remove">
                    <i class="fas fa-times text-white"
                    style="color:white;opacity:1.0;
                    margin-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px gray;"></i></p>';
                }else{
                    return '<p data-field="deleted"
                    onclick="removeFranchiseManagementModel('.$franchiseList->id.')"
                    style="background-color:red;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor: pointer;"
                    class="text-danger remove">
                    <i class="fas fa-times text-white"
                    style="color:white;opacity:1.0;
                    margin-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px red;"></i></p>';
                }
			
			})->
		escapeColumns([])->
		make(true);
	}
	
        /**
         * 
         * 
         * @param Request $request
         * @return string
         * @throws \Exception
         */
        function getFranchiseManagementDetail(Request $request){
            try {
                $validation = Validator::make($request->all(), [
                    'franchise_id' => 'required',
                ]);

                if ($validation->fails()) {
                    throw new \Exception("validation_error", 19);
                }

                $franchise_details = Franchise::where('systemid',
                    $request->franchise_id)->first();

            if (!$franchise_details) {
                throw new \Exception('franchise_not_found', 25);
            }
            return  response()->json(['name' =>$franchise_details->name, 'status' => 'true']);

            
        } catch (\Exception $e) {
//            return $e->getMessage();
            if ($e->getMessage() == 'validation_error') {
                return '';

            } else if ($e->getMessage() == 'product_not_found') {
                return response()->json([
					'message' =>"Error occured while opening dialog, invalid product selected",
					'status' => 'false']);

            } else {
                return response()->json([
					'message' =>$e->getMessage(),
					'status' => 'false']);
            }
        }
    }
    
    
    
    /**
         * 
         * 
         * @param Request $request
         * @return string
         * @throws \Exception
         */
        function updateFranchiseManagementDetail(Request $request){
            
            try {

            $allInputs = $request->all();
            $systemid       = $request->get('systemid');
            $changed = false;

            $validation = Validator::make($allInputs, [
                'systemid'         => 'required',
            ]);

            if ($validation->fails()) {
                throw new Exception("franchise_not_found", 1);
            }

             $franchise = Franchise::where('systemid', $systemid)->first();

             if (!$franchise) {
                throw new Exception("franchise_not_found", 1);
            }

            if ($request->has('franchise_name')) {
				$franchise->name = ($request->franchise_name);
				$changed = true;
				$msg = "Franchise Name updated";
            }

            if ($changed == true) {
                $franchise->save();
                $response = response()->json(['msg' => $msg,
					'status' => 'true']);
            } else {
                $response = response()->json([
					'msg' =>'Franchise Name not found', 'status' => 'false']);
            }

        }  catch (\Exception $e) {
            if ($e->getMessage() == 'product_not_found') {
                $msg = "Product not found";
            } else if ($e->getMessage() == 'invalid_cost') {
                $msg = "Invalid cost";
            } else {
                $msg = $e->getMessage();
            }
            $response = response()->json(['msg' =>$msg, 'status' => 'false']);
        }

        return $response;
    }
    
    
    public function getfranchiseManagmentModel(Request $request)
    {
        
        try {
            $allInputs = $request->all();
            $id        = $request->get('id');
            $fieldName = $request->get('field_name');
            $franchise = Franchise::where('id', $id)->first();
            return view('franchise.franchise-management-modals', compact(['id', 'fieldName', 'franchise']));
            

        } catch (\Illuminate\Database\QueryException $ex) {
            $response = (new ApiMessageController())->queryexception($ex);
        }
    }

    public function getfranchiseTerminalModel(Request $request)
    {
        
        try {
            $allInputs = $request->all();
            $id        = $request->get('id');
            $fieldName = $request->get('field_name');
            $franchise = terminal::where('systemid', $id)->first();
            return view('franchise.franchise_terminal_modals', compact(['id', 'fieldName', 'franchise']));
            

        } catch (\Illuminate\Database\QueryException $ex) {
            $response = (new ApiMessageController())->queryexception($ex);
        }
    }
    

    public function destoryFranchiseManagement($id)
    {
        try {
            $this->user_data = new UserData();
            $franchise          = Franchise::find($id);
            $franchiseCompanyID = $franchise->owner_merchant_id; 
            $franchiseOwnerID = Company::where("id" , $franchiseCompanyID)->first()->owner_user_id;
            $franchise->delete();

            $franchisee_user_id = MerchantLink::where("initiator_user_id" , $franchiseOwnerID)->pluck("responder_user_id");

            foreach ($franchisee_user_id as $item) {
                $company_id = Company::where("owner_user_id" , $item)->first()->id;
                $franchise_merchant_id = Merchant::where("company_id" , $company_id)->first()->id;
                $check = FranchiseMerchant::where("franchise_id" , $id)->where("franchisee_merchant_id" , $franchise_merchant_id)->whereNull("deleted_at");

                $check->update(['deleted_at' => $franchise->deleted_at]);
            }


            $msg = "Franchise deleted successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Illuminate\Database\QueryException $ex) {
            //$msg = "Some error occured";
            $msg = $ex;

            return view('layouts.dialog', compact('msg'));
        }
    }

    public function destoryFranchiseTerminal($id)
    {
        try {
            $this->user_data = new UserData();
            $franchise_terminal         = terminal::find($id);
            if($franchise_terminal){
                $franchise_terminal->delete();
            }

            $location_terminal          = locationterminal::where('terminal_id', $id)->first();
            if($location_terminal){
                $location_terminal->delete();
            }

            $franchisemerchantlocterm   = FranchiseMerchantLocTerm::where('terminal_id', $id)->first();
            if($franchisemerchantlocterm){
                $franchisemerchantlocterm->delete();
            }

            $msg = "Franchise deleted successfully";
            return view('layouts.dialog', compact('msg'));

        } catch (\Illuminate\Database\QueryException $ex) {
            //$msg = "Some error occured";
            $msg = $ex;

            return view('layouts.dialog', compact('msg'));
        }
    }
    
    /**
     * Getting marchant location
     * @return \Illuminate\Http\JsonResponse
     */
    public function getLocations()
    {
        $this->user_data = new UserData();

        $ids = merchantlocation::where('merchant_id',
			$this->user_data->
			company_id())->
			pluck('location_id');

        $location = location::where([['branch', '!=', 'null']])->
			whereIn('id', $ids)->
			where('warehouse', 0)->
			where('foodcourt', 0)->
			latest()->
			get();

        $response = [
            'data' => $location,
            'recordsTotal' => location::whereIn('id', $ids)->
				latest()->count(),
            'recordsFiltered' => location::whereIn('id', $ids)->
				latest()->count()
        ];
        return response()->json($response);
    }
    
    /**
       * @param Request $request
       * @return string
       * @throws \Exception
       */
	   
    function updateFranchiseMerchant(Request $request){

		try {
			$validation = Validator::make($request->all(), [
				'franchisId' => 'required',
			]);

			if ($validation->fails()) {
				throw new \Exception("validation_error", 19);
			}
			
			$franchise_details = FranchiseMerchant::where('franchise_id',
				$request->franchisId)->where('franchisee_merchant_id',
				$request->merchantId)->first();

			if (!$franchise_details) {
				if(!is_null($request->status)){

				} 
				if(!is_null($request->royalty)){
				
				}
					
			} else {
				if(!is_null($request->royalty)){
					FranchiseMerchant::where('franchise_id', $request->franchisId)->where('franchisee_merchant_id',
					$request->merchantId)->update(array(
						'overall_royalty'=> $request->royalty
						));
				}
				
				if(!is_null($request->status)){
					FranchiseMerchant::where('franchise_id', $request->franchisId)->where('franchisee_merchant_id',
					$request->merchantId)->update(array(
						'status'=> $request->status
						));
				}
				
			}

			return  response()->json([
				'royalty' =>$franchise_details->overall_royalty,
				'status' => 'true'
			]);

		} catch (\Exception $e) {
			if ($e->getMessage() == 'validation_error') {
				return '';

			} else if ($e->getMessage() == 'franchise_not_found') {
				return  response()->json([
					'message' =>"Error occured while opening dialog, Invalid franchise selected",
					'status' => 'false'
				]);

			} else {
				return  response()->json([
					'message' =>$e->getMessage(),
					'status' => 'false'
				]);
			}
		}
	}	   
	   
    function getFranchiseRoyalty(Request $request){

		try {
			$validation = Validator::make($request->all(), [
				'franchisId' => 'required',
			]);

			if ($validation->fails()) {
				throw new \Exception("validation_error", 19);
			}

			$franchise_details = FranchiseMerchant::where('franchise_id',
				$request->franchisId)->where('franchisee_merchant_id',
				$request->merchantId)->first();

			if (!$franchise_details) {
				throw new \Exception('franchise_not_found', 25);
			}

			return  response()->json([
				'royalty' =>$franchise_details->overall_royalty,
				'status' => 'true'
			]);

		} catch (\Exception $e) {
			if ($e->getMessage() == 'validation_error') {
				return '';

			} else if ($e->getMessage() == 'franchise_not_found') {
				return  response()->json([
					'message' =>"Error occured while opening dialog, Invalid franchise selected",
					'status' => 'false'
				]);

			} else {
				return  response()->json([
					'message' =>$e->getMessage(),
					'status' => 'false'
				]);
			}
		}
	}


    public function saveMerchantLocation(Request $request) {
//        Franchise
        $model = new FranchiseMerchantLoc();
        $model->location_id = $request->get('location_id');
        $model->franchisemerchant_id = $request->get('franchisemerchant_id');
        $model->save();
    }


    public function saveFranchiseeTerminalList(Request $request) {
        try {
        $merchantId = $request->input('merchantId');
        $locationId = $request->input('locationId');

        $systemid = new SystemID('terminal');
        $terminal = new terminal();
        $franchisemerchantlocterm = new FranchiseMerchantLocTerm();

        $terminal->systemid = $systemid;
        $terminal->btype_id = 1;
        $terminal->save();

        $sq_name = 'receipt_seq_' . sprintf("%06d",$terminal->id);
        \DB::select(\DB::raw("create sequence $sq_name nocache nocycle"));        
        $franchisemerchantlocId = franchisemerchantloc::
			where('franchisemerchant_id', $merchantId)->
			where('location_id', $locationId)->
			value('id');

        $franchisemerchantlocterm->franchisemerchantloc_id =
			$franchisemerchantlocId;

        $franchisemerchantlocterm->terminal_id = $terminal->id;
        $franchisemerchantlocterm->save();
        return response()->json([
            'msg' => 'Franchisee merchant location terminal added successfully',
            'status' => 'true'
        ]);

        } catch (\Exception $e) {
            return response()->json([
                'msg' => $e->getMessage(),
                'status' => 'false'
            ]);
        }
    }


    public function getFranchiseeTerminalList() {
        $merchantID = Input::get('merchant_id');
        $terminals = FranchiseMerchantLocTerm::select('franchisemerchantlocterm.id', 'location.branch', 'location.systemid as location_systemid', 'opos_terminal.systemid as terminal_systemid')
			->join('franchisemerchantloc', 'franchisemerchantloc.id', '=', 'franchisemerchantlocterm.franchisemerchantloc_id')
			->join('location', 'franchisemerchantloc.location_id', '=', 'location.id')
			->join('opos_terminal', 'opos_terminal.id', '=', 'franchisemerchantlocterm.terminal_id')
			->where('franchisemerchantloc.franchisemerchant_id', $merchantID)
            ->whereNull('opos_terminal.deleted_at')
			->orderBy('opos_terminal.systemid', 'desc')
			->get();

        $counter = 0;
        foreach ($terminals as $key => $terminal) {
            $terminals[$key]['indexNumber'] = ++$counter;
        }
        $response = [
            'data' => $terminals,
            'recordsTotal' => $terminals->count(),
            'recordsFiltered' => $terminals->count()
        ];
        return response()->json($response);
    }

    public function getTerminalLocations() {

//        Franchise
        $ids = franchisemerchantloc::where('franchisemerchant_id', Input::get('merchant_id'))->pluck('location_id');
        $location = location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->get();
        $response = [
            'data' => $location
        ];
        return response()->json($response);
    }

    public function removeMerchantLocation(Request $request) {
//        Franchise
        $model = new FranchiseMerchantLoc();
        $model->where('location_id', $request->get('location_id'))->where('franchisemerchant_id', $request->get('franchisemerchant_id'))->delete();
    }
}

