<?php

namespace App\Http\Controllers;

use App\Classes\SystemID;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\usersrole;

use App\Models\Company;
use App\Models\Merchant;

use App\Models\Staff;

use Milon\Barcode\DNS1D;
use Milon\Barcode\DNS2D;
use App\Models\Debitnote;
use App\Models\Debitnoteitem;
use App\Models\product;
use DB;
use App\Models\Currency;
use Carbon\Carbon;
use Yajra\DataTables\DataTables;

class DebitNoteController extends Controller
{


    public function saveDebitNote(Request $request)
    {
          //	id	systemid	creator_user_id	dealer_user_id
        $company_id = Merchant::where('id', $request->merchant_id)->value('company_id');
        $company_data = Company:: where('id', $company_id)->first();
        $currency=  \App\Models\Currency::where('id',
                $company_data->currency_id)->first();
    
        $user_data = Auth::user();
        $staff= Staff::where('user_id', $user_data->id)->first();
        $user_company_data = Company:: where('id', $staff->company_id)->first();
        $tableData =$request->tableData;
        $Totalprice=0;
      
        $debitnote =new Debitnote();
    
        $system_id = new SystemID('debitnote');
        $systemid= $system_id-> __toString();
            $debitnote->systemid = $systemid;// $value['ProductID'];
            $debitnote->creator_user_id =  $user_data->id;
            $debitnote->dealer_user_id =   $company_data->owner_user_id;
            $debitnote->status =  'active';
            $debitnote->save();
        $code = DNS1D::getBarcodePNG(trim($systemid), "C128");
        $qr = DNS2D::getBarcodePNG($systemid, "QRCODE");
        foreach ($tableData as $key => $value) {
          if($value['Price'] > 0){
            $product_id = product::where('systemid',  $value['ProductID'])->value('id');
            $product_Desc = product::where('systemid',  $value['ProductID'])->value('description');
            $debitnoteitem =new Debitnoteitem();
            $debitnoteitem->debitnote_id	 = $debitnote->id;
            $debitnoteitem->product_id =     $product_id;
            $debitnoteitem->price = $value['Price'];
            $debitnoteitem->quantity =  $value['TQty']/$value['Price'];
            $debitnoteitem->save();
            $Totalprice=$Totalprice+$value['TQty'];
                
          }
           
        }
          $gen_date = date('dMy h:m:s');
         $response = [
                        'dealer_data' => $company_data,
                        'user_data' => $user_data,
                        'user_company' => $user_company_data,
                        'tableData'=> $tableData,
                        'genDate'=> $gen_date,
                        'staff' =>   $staff,
                        'currency'=>$currency,
                        'Totalprice'=> number_format((float)$Totalprice, 2, '.', ''),
                        'barcode'=> $code,
                        'qr'=> $qr,
                        'systemid'=> $systemid
                        ];
            return response()->json($response);
    }


    public function showDebitNoteView($debitnoteid)
    {
       $debitNotes = Debitnote::where('id',$debitnoteid)->first();
        if($debitNotes->creator_user_id == Auth::user()->id){
            $user_data = Auth::user();
            $is_king =  Company::where('owner_user_id',Auth::user()->id)->first();
            $currency=  Currency::where('id',$is_king->currency_id)->first();
            $dealer_company =  Company::where('owner_user_id', $debitNotes->dealer_user_id)->first();
            $staff= Staff::where('user_id', $debitNotes->creator_user_id)->first();
        }else{
            $user_data= Staff::where('user_id', $debitNotes->creator_user_id)
               ->join('users', 'users.id', '=','staff.user_id')->first();
            $is_king =  Company::where('owner_user_id',$debitNotes->creator_user_id)->first();
            $currency=  Currency::where('id',$is_king->currency_id)->first();
            $dealer_company =  Company::where('owner_user_id', $debitNotes->dealer_user_id)->first();
            $staff= Staff::where('user_id', $debitNotes->creator_user_id)->first();
        }
        $systemid =  $debitNotes->systemid;
        $code = DNS1D::getBarcodePNG(trim($systemid ), "C128");
        $qr = DNS2D::getBarcodePNG($systemid, "QRCODE");
      
        $Totalprice=0;
        $debitNotesitem = Debitnoteitem::where('debitnote_id',$debitnoteid)->get(); 
        $product_detail= array();
        $index = 0;
        foreach ($debitNotesitem as $key => $value) {
                $Totalprice=number_format((float)$Totalprice+($value->price * $value->quantity), 2, '.', '') ;
                $product = product::where('id',$value->product_id)->first();
                $product_detail[$index] = $value;
                $product_detail[$index] ->no= $index+1;
                $product_detail[$index] ->amount =number_format((float)($value->price * $value->quantity), 2, '.', '') ;
                $product_detail[$index] ->productid =$product ->systemid;
                $product_detail[$index] ->productname =$product ->name;
            $index++;
        } 
        $genDate = date('dMy h:m:s');
      
        return view("debitnote.debitnote",compact('is_king','currency','debitnoteid',
                        'user_data',
                        'dealer_company',
                        'genDate',
                        'staff',
                        'Totalprice',
                        'code',
                        'qr','product_detail', 'systemid'));
  
    }

 

    public function DebitNoteIssuedList(Request $request)
    {
    	$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
   
        $month= $request->month;
        $start_yr= $request->year;
       
        $type = $request->type;
        if($type=='Issue'){
            $debitNotes = Debitnote::where('creator_user_id', $id)->
                 whereMonth('created_at',$month)
                ->whereYear('created_at', date($start_yr))
                ->get();
        
        }else{

             $debitNotes = Debitnote::where('creator_user_id','!=', $id)->
                 whereMonth('created_at',$month)
                ->whereYear('created_at', date($start_yr))
                ->get();
        
        }
        
        $debitdata = array();
        $index = 0;
        foreach ($debitNotes as $key => $value) {
            $documentid=$value->systemid;
            $debitnote_id=$value->id;
              if($type=='Issue'){
                    $dealuser_id =  $value ->dealer_user_id;
            }else{
                $dealuser_id =  $value ->creator_user_id;
            }
            $dealerCompany =  \App\Models\Company::where('owner_user_id', $dealuser_id)->first();
            $debitnoteitem = Debitnoteitem::where('debitnote_id',$debitnote_id)->
                    whereMonth('created_at',$month)
                    ->whereYear('created_at', date($start_yr))
                    ->get(); 
            $sumAmount =0;
            foreach ($debitnoteitem as $key => $value) {
                $sumAmount= $sumAmount+($value->price * $value->quantity);
            } 
            $debitdata[$index] = $value;
            $debitdata[$index]->noteid = $debitnote_id;
            $debitdata[$index]->documentid = $documentid;
            $debitdata[$index]->company = $dealerCompany->name ;
            $debitdata[$index]->amount = $sumAmount;
            $index++;
               
        }
       
    
        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();
        $currency=  \App\Models\Currency::where('id',$is_king->currency_id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }

         return Datatables::of($debitdata)->
            addIndexColumn()->
            addColumn('inven_pro_id', function ($memberList) {
                return '<a href="debitnote/'.$memberList->noteid.'" target="_blank" style="cursor: pointer;" >'.$memberList->documentid.'</a>' ;
            })->
            addColumn('inven_pro_date', function ($memberList) {
                return date('dMy H:i:s',strtotime($memberList->created_at));
            })->
            addColumn('inven_pro_branch', function ($memberList) {
                return $memberList->company;
            })->
            addColumn('amount', function ($memberList) {
                return  number_format((float)$memberList->amount, 2, '.', ''); 
            })->
            escapeColumns([])->
            make(true);
    	
    }



	public function showDebitNoteIssuedListView()
	{
		$id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
        $debitnote_id=12;

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
         return view('debitnote.debitnote_issued_list',compact('user_roles','is_king','debitnote_id'));
	}
    public function showDebitNoteReceivedListView()
    {
        $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();
        $debitnote_id=12;

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
         return view('debitnote.debitnote_received_list',compact('user_roles','is_king','debitnote_id'));
    }
}
