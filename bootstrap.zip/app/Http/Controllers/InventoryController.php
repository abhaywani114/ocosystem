<?php

namespace App\Http\Controllers;

use App\Http\Requests\Inventory\Barcode\CreateBarcodeFromRangeValidator;
use App\Models\SettingBarcodeMatrix;
use App\Models\opos_receiptremarks;
use App\Models\opos_refundremarks;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\DataTables;
use App\Models\inventorycost;
use Illuminate\Support\Carbon;
use Illuminate\Http\Request;
use App\Models\Wholesale;
use App\Http\Functions;
use Milon\Barcode\DNS1D;
use Milon\Barcode\DNS2D;
use Matrix\Exception;
use App\User;
use Log;

use Illuminate\Support\Facades\Validator;

use \App\Models\usersrole;
use \App\Models\role;
use \Illuminate\Support\Facades\Auth;

use \App\Classes\SystemID;

use \App\Models\product;
use \App\Models\productcolor;
use \App\Models\prd_inventory;
use \App\Models\Merchant;
use \App\Models\merchantproduct;
use \App\Models\opos_brancheod;
use \App\Models\opos_eoddetails;
use \App\Models\opos_itemdetails;
use \App\Models\opos_itemdetailsremarks;
use \App\Models\opos_receipt;
use \App\Models\opos_receiptdetails;
use \App\Models\opos_receiptproduct;
use \App\Models\opos_receiptproductspecial;
use \App\Models\locationproduct;
use \App\Models\merchantlocation;
use \App\Models\location;
use \App\Models\opos_locationterminal;
use \App\Models\opos_terminalproduct;
use \App\Models\opos_refund;
use \App\Models\StockReport;
use \App\Models\stockreportremarks;
use \App\Models\wastagereportremarks;
use \App\Models\opos_damagerefund;
use \App\Models\Staff;
use \App\Models\opos_wastage;
use \App\Models\opos_wastageproduct;
use \App\Models\productbarcode;
use \App\Models\warehouse;
use \App\Models\rack;
use \App\Models\rackproduct;
use \App\Models\stockreportproduct;
use \App\Models\stockreportproductrack;
use \App\Models\productbarcodelocation;
use \App\Models\voucherproduct;
use \App\Models\voucherlist;
use \App\Models\voucher;

use \App\Models\warranty;

use \App\Classes\UserData;
use App\Models\opos_promo_product;

use \App\Models\Stocktakemgmt;
use Illuminate\Support\Arr;


class InventoryController extends Controller
{
	protected $user_data;
	
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('CheckRole:prod');
	}
	
	public function index()
	{
		$this->user_data = new UserData();

		/* Dipak: DON'T TOUCH THIS! YOU HAVE SCREWED UP THE CODE */
		//$model = prd_inventory:: whereNotNull('price');

		$model = new prd_inventory();
		$ids = merchantproduct::where('merchant_id',
		$this->user_data->company_id())->pluck('product_id');
		
		/* Dipak: DON'T TOUCH THIS! YOU HAVE SCREWED UP THE CODE */
		//$ids = product::where('ptype', 'inventory')->whereNotNull('name')->whereNotNull('thumbnail_1')->whereNotNull('prdcategory_id')->whereNotNull('prdsubcategory_id')->whereNotNull('prdprdcategory_id')->whereIn('id', $ids)->pluck('id');

		$ids = product::where('ptype', 'inventory')->
			whereIn('id', $ids)->pluck('id');


		$data = $model->whereIn('product_id', $ids)->
		orderBy('created_at', 'asc')->latest()->get();
		
		// Product qty count
		$merchant_id = $this->user_data->company_id();
		$location_data = location::
		join('merchantlocation', 'merchantlocation.location_id', '=', 'location.id')->where('merchant_id', $merchant_id)->whereNotNull('location.branch')->get();
		
		foreach ($data as $key => $value) {
			$price = Wholesale::where('product_id', $value->product_id)->first();

			$check_quantity = $this->check_quantity($value->product_id);
			$data[$key]['quantity'] = $check_quantity;
			$data[$key]['price_two'] = $price ? $price->price : 0;
			$check_transaction = $this->check_transaction($value->product_id);
			$data[$key]['transaction'] = $this->check_transaction($value->product_id);
		}

		$wholesale_prices = new Wholesale();
        $product_whole_sale_price_and_range = [];
		foreach ($ids as $key => $value) {
            $product_whole_sale_price_and_range[$value] = $wholesale_prices->where('product_id', $value)->get()->toArray();
        }
        
		return Datatables::of($data)->
		addIndexColumn()->
		addColumn('systemid', function ($memberList) {
			return $memberList->product_name->systemid;
		})->
		//showing the barcode
		addColumn('systemid_dsp', function ($memberList) {
			return '<p class="os-linkcolor qtyOutput" data-field="systemid_dsp" style="cursor: pointer; margin: 0; text-align: center;"><a class="os-linkcolor" href="/landing/inventorybarcode/' . $memberList->product_name->systemid . '" target="_blank" style="text-decoration: none;">' . $memberList->product_name->systemid . '</a></p>';
		})->
		
		addColumn('inven_pro_name', function ($memberList) {
		    
			if (!empty($memberList->product_name->thumbnail_1)) {
		    
				$img_src = '/images/product/' .
					$memberList->product_name->id . '/thumb/' .
					$memberList->product_name->thumbnail_1;
				
				$img = "<img src='$img_src' data-field='inven_pro_name' style=' width: 25px;height: 25px;display: inline-block;margin-right: 8px;object-fit:contain;'>";
				
			}  else {
				$img = null;
			} 
			return $img . '<p class="os-linkcolor" data-field="inven_pro_name" style="cursor: pointer; margin: 0;display:inline-block" onclick="details(' . $memberList->product_name->systemid . ')">' . (!empty($memberList->product_name->name) ? $memberList->product_name->name : 'Product Name') . '</p>';
			
		})->
		
		addColumn('inven_price', function ($memberList) {
		    
			return '<p class="os-linkcolor" data-field="inven_price" data-id="retail"  style="cursor: pointer; margin: 0; text-align: right;" >' . (!empty($memberList->price) ? number_format(($memberList->price / 100), 2) : '0.00') . '</p>';
		})->
		
		addColumn('inven_price_two', function ($memberList) {
			return '<p class="os-linkcolor" data-field="inven_price" data-id="wholesale" style="cursor: pointer; margin: 0; text-align: right;" >' . number_format(($memberList->price_two / 100), 2) . '</p>';
		})->
		
		addColumn('inven_qty', function ($memberList) {
			
			return '<p class="os-linkcolor qtyOutput" data-field="inven_qty" style="cursor: pointer; margin: 0; text-align: center;"><a class="os-linkcolor" href="landing/show-inventoryqty-view/' . $memberList->product_name->systemid . '" target="_blank" style="text-decoration: none;">' . (!empty($memberList->quantity) ? $memberList->quantity : '0') . '</a></p>';
		})->
		addColumn('inven_tax', function ($memberList) {
			
			return '<p class="os-linkcolor qtyOutput" data-field="inven_tax" style="cursor: pointer; margin: 0; text-align: center;"><a class="os-linkcolor" href="landing/show-inventoryqty-view/' . $memberList->product_name->systemid . '" target="_blank" style="text-decoration: none;">-</a></p>';
		})->
		addColumn('inven_cogs', function ($memberList) {
			return '<p class="os-linkcolor cogsOutput" data-target="#inventoryCogsModal" data-toggle="modal" data-field="inven_cogs" style="cursor: pointer; margin: 0; text-align: right;">' . (!empty($memberList->cogs) ? $memberList->cogs : '0.00') . '</p>';
		})->
		
		addColumn('inven_cost', function ($memberList) {
			return '<p class="os-linkcolor qtyOutput" data-field="inven_qty" style="cursor: pointer; margin: 0; text-align: center;"><a class="os-linkcolor" href="landing/inventorycost/'.$memberList->product_name->id.'" target="_blank" style="text-decoration: none;">' . (!empty($memberList->cost) ? $memberList->cost : '0.00') . '</a></p>';
		})->
		
		addColumn('inven_pending', function ($memberList) {
			return '<p class="os-linkcolor" data-field="inven_pending" style="cursor: pointer; margin: 0; text-align: center;">' . (!empty($memberList->pending) ? $memberList->pending : '0') . '</p>';
		})->
		
		addColumn('inven_loyalty', function ($memberList) {
			return '<p class="os-linkcolor loyaltyOutput" data-field="inven_loyalty" style="cursor: pointer; margin: 0; text-align: center;" data-target="#inventoryLoyaltyModal" data-toggle="modal">'.(!empty($memberList->loyalty) ? $memberList->loyalty : '0').'</p>';
		})->
		
		addColumn('deleted', function ($memberList) {
			if ($memberList->transaction == 'True') {
				
				return '<p
                    style="background-color:#ddd;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor:not-allowed;"
                    class="text-secondary" >
                    <i class="fas fa-times text-white"
                    style="color:white;opacity:1.0;
                    padding-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px #ccc;"></i></p>';
				
			} else {
				
				return '<p data-field="deleted" data-target="#showMsgModal" data-toggle="modal"
                    style="background-color:red;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor: pointer;"
                    class="text-danger remove">
                    <i class="fas fa-times text-white"
                    style="color:white;opacity:1.0;
                    padding-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px red;"></i></p>';
			}
		})->
		escapeColumns([])->
		make(true);
	}
	
	public function check_transaction($product_id)
	{
		$sales_count = opos_receiptproduct::where('product_id', $product_id)
			->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
			->count();
		$stock_count = StockReport::where('product_id', $product_id)->count();
		$wastage = opos_wastageproduct::where('product_id', $product_id)->count();
		$total = $sales_count + $stock_count + $wastage;
		if ($total > 0) {
			return true;
		} else {
			return false;
		}
		
	}

    /**
     * @param product $productId product id
     */
    private function getPromoProductSaleQty($productId){

        // promo product sale qty
        $receiptPromos = opos_receiptproduct::
        select('opos_receiptproduct.quantity', 'opos_receiptdetails.void', 'opos_receiptproduct.promo_id')
            ->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
            ->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
            ->whereNotNull('opos_receiptproduct.promo_id')
            ->where('opos_receiptdetails.void', '!=', 1)
            ->get();

        $promo_product_sale_qty = 0;
        foreach ($receiptPromos as $receiptPromo) {
            $promoProducts = opos_promo_product::select('product_id', 'quantity')->where('promo_id', $receiptPromo->promo_id)->get();
            foreach($promoProducts as $promoProduct) {
                if ($promoProduct->product_id == $productId) {
                    $promo_product_sale_qty += (int) $receiptPromo->quantity * (int)$promoProduct->quantity;
                }
            }
        }

        return $promo_product_sale_qty;
    }

    public function check_quantity($product_id)
	{
		$final_qty = 0;


        //$promo_product_sale_qty = $this->getPromoProductSaleQty($product_id);

        // Product Meta data (reciept, location, document no., etc.)
        $sales_qty = opos_receiptproduct::
        select('opos_receipt.systemid as document_no', 'opos_receiptproduct.receipt_id', 'opos_itemdetails.id as item_detail_id', 'opos_itemdetails.receiptproduct_id', 'opos_receiptproduct.quantity', 'opos_itemdetails.created_at as last_update', 'location.branch as location', 'location.id as locationid', 'opos_receiptdetails.void')
            ->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
            ->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
            ->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
            ->where('opos_receiptproduct.product_id', $product_id)
            ->where('opos_receiptdetails.void', '!=', 1)
            ->sum('opos_receiptproduct.quantity');

        /*
        $sales_qty = opos_receiptproduct::where('product_id', $product_id)
            ->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->where('opos_receiptdetails.void', '!=', 1)
			->sum('opos_receiptproduct.quantity');
        */

        $voucherQty = voucher::join('voucherproduct', 'voucherproduct.product_id', '=', 'prd_voucher.product_id')
            ->where('voucherproduct.product_id', $product_id)
            ->whereIn('prd_voucher.type', ['qty'])
            ->sum('voucherproduct.vquantity');


        $stock_qty = StockReport::where('product_id', $product_id)->sum('quantity');
        $refund_c = opos_refund::join("opos_receiptproduct", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')->where('opos_receiptproduct.product_id', $product_id)->where('refund_type', 'C')->count();
        $refund_dx = opos_refund::join("opos_receiptproduct", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')->where('opos_receiptproduct.product_id', $product_id)->where('refund_type', 'Dx')->count();
        $wastage = opos_wastageproduct::where('product_id', $product_id)->sum('wastage_qty');
        $redeemed = DB::table('product_pts_redemption')->where('product_id', $product_id)->sum('quantity');
        $final_qty = $stock_qty - $sales_qty + $refund_c - $refund_dx - $wastage - $voucherQty - $redeemed;
		return $final_qty;
	}
	
	public function location_productqty($product_id, $location_id)
	{

	    // promo product sale qty
        /*
        $receiptPromos = opos_receiptproduct::
        select('opos_receiptproduct.quantity', 'opos_receiptdetails.void', 'opos_receiptproduct.promo_id')
            ->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
            ->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
            ->whereNotNull('opos_receiptproduct.promo_id')
            ->where('opos_receiptdetails.void', '!=', 1)
            ->where('location.id', '=', $location_id)
            ->get();
        */

        $promo_product_sale_qty = 0;
        /*
        foreach ($receiptPromos as $receiptPromo) {
            $promoProducts = opos_promo_product::select('product_id', 'quantity')->where('promo_id', $receiptPromo->promo_id)->get();
            foreach($promoProducts as $promoProduct) {
                if ($promoProduct->product_id == $product_id) {
                    $promo_product_sale_qty += (int) $receiptPromo->quantity * (int)$promoProduct->quantity;
                }
            }
        }
        */

		$final_qty = 0;
		$product_Sales_qty_data = opos_receiptproduct::
		leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->where('opos_receiptproduct.product_id', $product_id)
			->where('opos_receiptdetails.void', '!=', 1)
			->where('location.id', '=', $location_id)
			->sum('opos_receiptproduct.quantity');


		
		$stock_qty = StockReport::where('product_id', $product_id)->where('location_id', $location_id)->sum('quantity');
		
		$refund_c = opos_refund::
		join("opos_receiptproduct", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->where('opos_receiptproduct.product_id', $product_id)
			->where('location.id', $location_id)
			->where('opos_refund.refund_type', 'C')
			->count();
		
		$refund_dx = opos_refund::
		join("opos_receiptproduct", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->where('opos_receiptproduct.product_id', $product_id)
			->where('location.id', $location_id)
			->where('opos_refund.refund_type', 'Dx')
			->count();


        $voucherQty = voucher::join('voucherproduct', 'voucherproduct.product_id', '=', 'prd_voucher.product_id')
            ->where('voucherproduct.location_id', $location_id)
            ->where('voucherproduct.product_id', $product_id)
            ->whereIn('prd_voucher.type', ['qty'])
            ->sum('voucherproduct.vquantity');

        $wastage = opos_wastageproduct::where('product_id', $product_id)->where('location_id', $location_id)->sum('wastage_qty');
		$redeemed = DB::table('product_pts_redemption')->where('location_id', $location_id)->where('product_id', $product_id)->sum('quantity');
		$final_qty = $stock_qty - $product_Sales_qty_data + $refund_c - $refund_dx - $wastage - $promo_product_sale_qty - $redeemed - $voucherQty;
		return $final_qty;
	}
	
	public function getInventoryQty()
	{
		return Datatables::of(array('',))->
		addIndexColumn()->
		addColumn('inventoryqtry_pro_id', function ($memberList) {
			return '<p class="os-linkcolor" data-field="inventoryqtry_pro_id" style="cursor: pointer; margin: 0; text-align: center;">24576553</p>';
		})->
		
		addColumn('inventoryqtry_type', function ($memberList) {
			return '<p data-field="inventoryqtry_type" style="cursor: pointer; margin: 0;">Dummy</p>';
		})->
		
		addColumn('inventoryqtry_lastup', function ($memberList) {
			return '<p data-field="inventoryqtry_lastup" style="cursor: pointer; margin: 0;" data-toggle="modal">24Jan19 23:46</p>';
		})->
		
		addColumn('inventoryqtry_location', function ($memberList) {
			return '<p data-field="inventoryqtry_location" style="cursor: pointer; margin: 0;" data-toggle="modal">LF-Kajang</p>';
		})->
		
		addColumn('inventoryqtry_qty', function ($memberList) {
			return '<p data-field="inventoryqtry_qty" style="cursor: pointer; margin: 0; text-align: center;">7</p>';
		})->
		
		escapeColumns([])->
		make(true);
	}
	
	
	public function edit($id)
	{
	
	}
	
	public function showEditModal(Request $request)
	{
		Log::debug('***** showEditModal() *****');

		try {
			$allInputs = $request->all();
			$id = $request->get('id');
			$fieldName = $request->get('field_name');
			
			
			$validation = Validator::make($allInputs, [
				'id' => 'required',
				'field_name' => 'required'
			]);
			
			if ($validation->fails()) {
				$response = (new ApiMessageController())->
					validatemessage($validation->errors()->first());

				Log::debug('response='. $response);
				
			} else {
				$inventory = prd_inventory::where('id', $id)->first();

                $wholesales = Wholesale::
                    where('product_id', $inventory->product_id)
                    ->get()
                    ->toArray();

				Log::debug('id='.$id);
				Log::debug('fieldName='.$fieldName);
				Log::debug('inventory='.json_encode($inventory));
				Log::debug('wholesales='.
					json_encode($wholesales));

				return view('inventory.inventory-modals',
					compact([
						'id',
						'fieldName',
						'inventory',
						'wholesales'
					]));
			}
			
		} catch (\Illuminate\Database\QueryException $ex) {
			Log::error($ex);
			$response = (new ApiMessageController())->queryexception($ex);
		}
	}
	
	
	public function store(Request $request)
	{
		//Create a new product here
		try {
			$this->user_data = new UserData();
			$SystemID = new SystemID('product');
			$product = new product();
			$inventory = new prd_inventory();
			$merchantproduct = new merchantproduct();

			$product->systemid = $SystemID;
			$product->ptype = 'inventory';
			$product->save();
			
			$inventory->product_id = $product->id;
			$inventory->save();
			
			$merchantproduct->product_id = $product->id;
			$merchantproduct->merchant_id = $this->user_data->company_id();
			$merchantproduct->save();
			
			
			$msg = "Product added successfully";
			return view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = $e;//"Some error occured";
			return view('layouts.dialog', compact('msg'));
		}
	}
	
	public function update_remark(Request $request)
	{
		try {
			$id = Auth::user()->id;
			
			$item_id = $request->get('item_id');
			$item_remark = $request->get('item_remark') ? $request->get('item_remark') : '';
			$remark_type = $request->get('remark_type');

			Log::debug('remark_type='.$remark_type);


			// $opos_itemdetailsremarks = opos_itemdetailsremarks::where('user_id',$id)->where('itemdetails_id',$item_id)->orderby('id',"desc")-> first();

			if ($remark_type == 'stock') {
				//pranto code
				$count = stockreportremarks::where('stockreport_id','=',$item_id)->count();
				if ($count <=0) {
					$stockreportremarks = new stockreportremarks();
					$stockreportremarks->stockreport_id = $item_id;
					$stockreportremarks->user_id = $id;
					$stockreportremarks->remarks = $item_remark;
					$stockreportremarks->save();
				}else{
					stockreportremarks::where('stockreport_id', $item_id)->update(array(
					'remarks'=> $item_remark,
					'user_id' => $id
					));
				}
			} else if($remark_type == 'cash_sale_receipt'){

			    opos_receiptremarks::create([
			        'receipt_id' => $item_id,
                    'user_id' => $id,
                    'remarks' => $item_remark
                ]);

            } else if($remark_type == 'refund'){

			    opos_refundremarks::create([
			        'refund_id' => $item_id,
                    'user_id' => $id,
                    'remarks' => $item_remark
                ]);

			} else if($remark_type == 'wastage'){
				$wastagereportremarks = new wastagereportremarks();
				$wastagereportremarks->wastage_id = $item_id;
				$wastagereportremarks->user_id = $id;
				$wastagereportremarks->remarks = $item_remark;
				$wastagereportremarks->save();
			} else {
				$opos_itemdetailsremarks = new opos_itemdetailsremarks();
				$opos_itemdetailsremarks->itemdetails_id = $item_id;
				$opos_itemdetailsremarks->user_id = $id;
				$opos_itemdetailsremarks->remarks = $item_remark;
				
				$opos_itemdetailsremarks->save();
			}
			$msg = "Item remarks saved successfully";
			$data = view('layouts.dialog', compact('msg'));
		} catch (\Exception $e) {
			
			{
				$msg = "Error occured while Saving remarks";
			}
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	public function update_barcode_sku(Request $request)
	{
		try {
			$id = Auth::user()->id;
			
			$barcode_id = $request->get('barcode_id');
			$sku = $request->get('sku');
			$is_main = $request->get('is_main');
			if ($is_main == 0) {
				$productbarcode = productbarcode::where('id', $barcode_id)->first();
				$productbarcode->sku = $sku;
				$productbarcode->save();
			} else {
				$productbarcode = product::where('id', $barcode_id)->first();
				$productbarcode->sku = $sku;
				$productbarcode->save();
			}
			$msg = "SKU saved successfully";
			$data = view('layouts.dialog', compact('msg'));

		} catch (\Exception $e) {
			$msg = "Error occured while Saving remarks";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	public function update_barcode_name(Request $request)
	{
		try {
			$id = Auth::user()->id;
			
			$barcode_id = $request->get('barcode_id');
			$name = $request->get('name');
			$is_main = $request->get('is_main');
			if ($is_main == 0) {
				$productbarcode = productbarcode::where('id', $barcode_id)->first();
				$productbarcode->name = $name;
				$productbarcode->save();
			} else {
				$productbarcode = product::where('id', $barcode_id)->first();
				$productbarcode->name = $name;
				$productbarcode->save();
			}
			$msg = "Barcode name saved successfully";
			$data = view('layouts.dialog', compact('msg'));

		} catch (\Exception $e) {
			$msg = "Error occured while Saving remarks";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}

	
	public function update(Request $request)
	{
		try {
			$allInputs = $request->all();
			$prd_inventory_id = $request->get('prd_inventory_id');
			$changed = false;

			$msg = NULL;
			
			$validation = Validator::make($allInputs, [
				'prd_inventory_id' => 'required',
			]);
			
			if ($validation->fails()) {
				throw new Exception("product_not_found", 1);
			}
			
			$prd_inventory = prd_inventory::find($prd_inventory_id);
			if (!$prd_inventory) {
				throw new Exception("product_not_found", 1);
			}
            $product_id_for_wholesale = $prd_inventory->product_id;

			if ($request->has('price')) {
				$new_price = ((int)$request->price) * 100;
				if ($prd_inventory->price != $new_price) {
					$prd_inventory->price = $new_price;
					$changed = true;
					$msg = "Price updated successfully";
				}
			}

			if ($changed == true) {
				$prd_inventory->save();

                // update whole sale
                if($request->checker == "wholesale"){
                	$result = $this->updateWholesale($product_id_for_wholesale, $request->all());
                	if($result != ''){
                		$msg = $result;
                	}
                }
			} else {

                // update whole sale
                if($request->checker == "wholesale"){
                	$result = $this->updateWholesale($product_id_for_wholesale, $request->all());
                	if($result != ''){
                		$msg = $result;
                	}
                }
			}

            if($msg == NULL){
            	$response = NULL;
            }
            else{
            	$response = view('layouts.dialog', compact('msg'));
            }
			
		} catch (\Exception $e) {
			if ($e->getMessage() == 'product_not_found') {
				$msg = "Product not found";
			} else if ($e->getMessage() == 'invalid_cost') {
				$msg = "Invalid cost";
			} else {
				$msg = $e->getMessage();
			}
			
			//$msg = $e;
			$response = view('layouts.dialog', compact('msg'));
		}
		return $response;
	}

	function updateWholesale($product_id, $data) {

		Log::debug('updateWholesale:'.json_encode($data));


        $wholesale_update = Wholesale::
			where(['product_id' => $product_id])->get();

			$changed = false;
			$last_position = count($data) - (count($wholesale_update) + 3);
			$msg = '';

        // insert
        for($i=1; $i< $last_position ; $i++){
            $wholsale_input_tu_key = 'wholsale_input_tu_'.$i;
            $wholsale_input_price_key = 'wholsale_input_price_'.$i;

            $wholsale_input_tu_key_previous = 'wholsale_input_tu_'. ($i-1);
            $wholsale_input_price_key_previous = 'wholsale_input_price_'. ($i-1);

            if($i == 1){
        		if($data[$wholsale_input_price_key] && $data[$wholsale_input_tu_key]){
        			$previous_wholesale = Wholesale::where("product_id", $product_id)->where("position", $i)->first();
        			if($previous_wholesale){
        				if($previous_wholesale->unit != $data[$wholsale_input_tu_key] || $previous_wholesale->price != ($data[$wholsale_input_price_key] * 100)){
        					Wholesale::updateOrCreate(["product_id" => $product_id, "position" => $i], [
			            		"product_id" => $product_id,
			            		"position" => $i,
			            		"funit" => $i,
			            		"unit" => (int) $data[$wholsale_input_tu_key],
			            		"price" => (int) ($data[$wholsale_input_price_key] * 100),
			            		"deleted_at" => NULL,
			            	]);
			            	$msg = "Price updated successfully";
        				}
        			}
        			else{
        				Wholesale::updateOrCreate(["product_id" => $product_id, "position" => $i], [
		            		"product_id" => $product_id,
		            		"position" => $i,
		            		"funit" => $i,
		            		"unit" => (int) $data[$wholsale_input_tu_key],
		            		"price" => (int) ($data[$wholsale_input_price_key] * 100),
		            		"deleted_at" => NULL,
		            	]);
		            	$msg = "Price updated successfully";
        			}
	            }
            }
            else{
            	if($data[$wholsale_input_price_key] && $data[$wholsale_input_tu_key] && $data[$wholsale_input_tu_key_previous] && ($data[$wholsale_input_tu_key] > ($data[$wholsale_input_tu_key_previous] + 1)) && ($data[$wholsale_input_price_key] < $data[$wholsale_input_price_key_previous])){

        			$previous_wholesale = Wholesale::where("product_id", $product_id)->where("position", $i)->first();
        			if($previous_wholesale){
        				if($previous_wholesale->unit != $data[$wholsale_input_tu_key] || $previous_wholesale->price != ($data[$wholsale_input_price_key] * 100)){
	        				Wholesale::updateOrCreate(["product_id" => $product_id, "position" => $i], [
			            		"product_id" => $product_id,
			            		"position" => $i,
			            		"funit" => ((int) $data[$wholsale_input_tu_key_previous]) + 1,
			            		"unit" => (int) $data[$wholsale_input_tu_key],
			            		"price" => (int) ($data[$wholsale_input_price_key] * 100),
				            	"deleted_at" => NULL,
			            	]);
			            	$msg = "Price updated successfully";
        				}
        			}
        			else{
        				Wholesale::updateOrCreate(["product_id" => $product_id, "position" => $i], [
		            		"product_id" => $product_id,
		            		"position" => $i,
		            		"funit" => ((int) $data[$wholsale_input_tu_key_previous]) + 1,
		            		"unit" => (int) $data[$wholsale_input_tu_key],
		            		"price" => (int) ($data[$wholsale_input_price_key] * 100),
			            	"deleted_at" => NULL,
		            	]);
		            	$msg = "Price updated successfully";
        			}
	            }
	            if($data[$wholsale_input_tu_key] && $data[$wholsale_input_price_key] && $data[$wholsale_input_price_key] > $data[$wholsale_input_price_key_previous]){
	            	$msg = "Price must be lower than previous tier";
	            }
	            /*if($data[$wholsale_input_tu_key] && $data[$wholsale_input_price_key] && $data[$wholsale_input_tu_key] < ($data[$wholsale_input_tu_key_previous] + 1)){
	            	$msg = "Input unit cannot be lower than the starting unit";
	            }*/
            }
        }
        return $msg;
     }
	

	public function destroy($id)
	{
		
		try {
			$this->user_data = new UserData();
			
			$inventory = prd_inventory::where("id", $id)->first();

			if(!$inventory){
				$msg = "Product not found, please refresh your browser";
			}
			else{
				$is_exist = merchantproduct::where([
					'product_id' => $inventory->product_id,
					'merchant_id' => $this->user_data->company_id()
				])->first();
				
				if (!$is_exist) {
					throw new Exception("Error Processing Request", 1);
				}
				$is_exist->delete();
				$product_id = $inventory->product_id;
				product::find($product_id)->delete();
				$inventory->delete();
				
				// \DB::table('client')->where('id', $id)->delete();
				$msg = "Product deleted successfully";
			}
			return view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = $e;// "Some error occured";
			return view('layouts.dialog', compact('msg'));
		}
	}
	
	
	public function showInventoryView()
	{
	    
		return view('inventory.inventory');
	}
	
	
	public function showInventoryQtyView($systemid)
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		// Get product from system id
		$product = product::where('systemid', $systemid)->first();
		
		// Product inventory data
		$model = new prd_inventory();
		$product_data = $model->where('product_id', $product->id)->first();
		
		// Product Meta data (reciept, location, document no., etc.)
		$opos_product = opos_receiptproduct::
		select('opos_receipt.systemid as document_no', 'opos_receiptproduct.receipt_id', 'opos_receiptproduct.promo_id'  ,'opos_itemdetails.id as item_detail_id', 'opos_itemdetails.receiptproduct_id', 'opos_receiptproduct.quantity', 'opos_receiptproduct.created_at as last_update', 'location.branch as location', 'location.id as locationid', 'opos_receiptdetails.void')
			->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->where('opos_receiptproduct.product_id', $product->id)
			//->distinct()
			->orderby('opos_receiptproduct.id', 'DESC')
			->get();

	//	dd($opos_product);

		// Getting promo receipt
        /*
        $receiptPromos = opos_receiptproduct::
        select('opos_receipt.systemid as document_no', 'opos_receiptproduct.receipt_id', 'opos_itemdetails.id as item_detail_id', 'opos_itemdetails.receiptproduct_id', 'opos_receiptproduct.quantity', 'opos_itemdetails.created_at as last_update', 'location.branch as location', 'location.id as locationid', 'opos_receiptdetails.void', 'opos_receiptproduct.promo_id')
            ->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
            ->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
            ->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
            ->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
            ->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
            ->whereNotNull('opos_receiptproduct.promo_id')
            ->orderby('opos_itemdetails.id', 'DESC')
            ->get();



        $item_count = count($opos_product);
        foreach ($receiptPromos as $receiptPromo) {
            $promoProducts = opos_promo_product::select('product_id', 'quantity')->where('promo_id', $receiptPromo->promo_id)->get();
            foreach($promoProducts as $promoProduct) {
                if ($promoProduct->product_id == $product->id) {
                    $receiptPromo->quantity = (int) $receiptPromo->quantity * (int)$promoProduct->quantity;
                    $opos_product[$item_count] = $receiptPromo;
                    $item_count++;
                }
            }
        }
        */

        $this->user_data = new UserData();

        $refund = opos_refund::select('opos_receipt.systemid as document_no', 'opos_receiptproduct.receipt_id', 'opos_receiptproduct.quantity', 'opos_refund.refund_type', 'opos_itemdetails.id as item_detail_id', 'opos_itemdetails.receiptproduct_id', 'opos_refund.created_at as last_update', 'location.branch as location', 'location.id as locationid', 'opos_receiptdetails.void')
			->join("opos_receiptproduct", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
			->leftjoin('opos_itemdetails', 'opos_itemdetails.receiptproduct_id', '=', 'opos_receiptproduct.id')
			->leftjoin('opos_receipt', 'opos_receipt.id', '=', 'opos_receiptproduct.receipt_id')
			->leftjoin('opos_receiptdetails', 'opos_receipt.id', '=', 'opos_receiptdetails.receipt_id')
			->leftjoin('opos_locationterminal', 'opos_receipt.terminal_id', '=', 'opos_locationterminal.terminal_id')
			->leftjoin('location', 'location.id', '=', 'opos_locationterminal.location_id')
			->whereIn('opos_refund.refund_type', array('C', 'Dx'))
			->where('opos_receiptproduct.product_id', $product->id)->get();
	//	dd($refund );
        $item_count = count($opos_product);
		foreach ($refund as $key => $value) {
			$refund_type = $value->refund_type;
			if ($refund_type == "C" || $refund_type == "Dx") {
				// if($refund_type == "C" || $refund_type == "Cx" || $refund_type == "Dx"){
				// if($refund_type == 'C' || $refund_type == "Dx") {
				if ($refund_type == 'C') {
					$opos_product[$item_count] = $value;
					$opos_product[$item_count]->sales_type = 'Refund C';
					$opos_product[$item_count]->quantity = 1;
					$item_count++;
				}
				// if($refund_type == 'Cx' || $refund_type == "Dx") {
				if ($refund_type == "Dx") {
					$opos_product[$item_count] = $value;
					$opos_product[$item_count]->sales_type = 'Refund Dx';
					$opos_product[$item_count]->quantity = -1;
					$item_count++;
				}
			}
		}

        $wastage = opos_wastageproduct::
		select('product.systemid as productsys_id', 'product.id as product_id', 'product.thumbnail_1', 'product.name', 'opos_wastage.systemid as document_no', 'opos_wastageproduct.wastage_qty as quantity', 'opos_wastageproduct.created_at as last_update', 'location.branch as location', 'location.id as locationid')
			->join('opos_wastage', 'opos_wastage.id', '=', 'opos_wastageproduct.wastage_id')
			->join('location', 'location.id', '=', 'opos_wastageproduct.location_id')
			->join("product", 'opos_wastageproduct.product_id', '=', 'product.id')
			->where('opos_wastageproduct.product_id', $product->id)
			->get();

        $item_count = count($opos_product);
		foreach ($wastage as $key => $value) {
			$opos_product[$item_count] = $value;
			$opos_product[$item_count]->wastage = 1;
			$opos_product[$item_count]->sales_type = "Wastage & Damage";
			$opos_product[$item_count]->quantity = 0 - $value->quantity;
			$item_count++;
		}


        $voucher_data = voucherproduct::select('product.systemid as document_no','voucherproduct.product_id as product_id','voucherproduct.created_at as last_update','product.*','prd_voucher.*','voucherproduct.*','location.branch as location', 'location.id as locationid')->join('product','product.id','=','voucherproduct.voucher_id')
            ->join('prd_voucher','prd_voucher.product_id','=','product.id')
            // ->join('voucherlist','voucherlist.voucher_id', '=','prd_voucher.id')
            ->leftjoin('location','voucherproduct.location_id','=','location.id')
            ->where('voucherproduct.product_id',$product->id)
            ->whereIn('prd_voucher.type', ['qty'])
            ->where('voucherproduct.vquantity','>', 0)
            ->get();

        $item_count = count($opos_product);
        foreach ($voucher_data as $key => $value) {
            $opos_product[$item_count] = $value;
            $opos_product[$item_count]->voucher = 1;
            $opos_product[$item_count]->document_no = $value->systemid;
            $opos_product[$item_count]->sales_type = "Voucher";
            $opos_product[$item_count]->quantity = 0 - $value->vquantity;
            $item_count++;
        }


		$StockReport = StockReport::select('stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreport.quantity', 'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 'location.id as locationid')
			->leftjoin('location', 'location.id', '=', 'stockreport.location_id')
			->where('stockreport.product_id', $product->id)->distinct()->get();

		
		$item_count = count($opos_product);
		foreach ($StockReport as $key => $value) {
			$opos_product[$item_count] = $value;
			if ($value->refund_type == 'stockin') {
				$sales = 'Stock In';
			} else if ($value->refund_type == 'stockout') {
				$sales = 'Stock Out';
				$opos_product[$item_count]->quantity = $value->quantity;
				
			} else {
				$sales = $value->refund_type;
			}
			$opos_product[$item_count]->sales_type = $sales;
			$opos_product[$item_count]->item_detail_id = $value->stockreport_id;
			$opos_product[$item_count]->stock = 1;
			$item_count++;
		}
		
		$StockReportTRout = StockReport::select('stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreportproduct.quantity', 
											'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 
											'location.id as locationid')
			->join('location', 'location.id', '=', 'stockreport.location_id')
			->join('stockreportproduct', 'stockreport.id', '=', 'stockreportproduct.stockreport_id')
			->where('stockreportproduct.product_id', $product->id)->distinct()->get();
		//dd($StockReportTRout);
		
			$item_count = count($opos_product);
			foreach ($StockReportTRout as $key => $value) {
				$opos_product[$item_count] = $value;
				$sales = 'Stock Out';
				$opos_product[$item_count]->sales_type = $sales;
				$opos_product[$item_count]->item_detail_id = $value->stockreport_id;
				$opos_product[$item_count]->quantity = $value->quantity * -1;
				$opos_product[$item_count]->stock = 3;
				$item_count++;
			}		
			
		$StockReportTRin = StockReport::select('stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreportproduct.quantity', 
											'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 
											'location.id as locationid')
			->join('location', 'location.id', '=', 'stockreport.dest_location_id')
			->join('stockreportproduct', 'stockreport.id', '=', 'stockreportproduct.stockreport_id')
			->where('stockreportproduct.product_id', $product->id)->distinct()->get();

		
			$item_count = count($opos_product);
			foreach ($StockReportTRin as $key => $value) {
				$opos_product[$item_count] = $value;
				$sales = 'Stock In';
				$opos_product[$item_count]->sales_type = $sales;
				$opos_product[$item_count]->item_detail_id = $value->stockreport_id;
				$opos_product[$item_count]->quantity = $value->quantity;
				$opos_product[$item_count]->stock = 3;
				$item_count++;
			}				
	//	dd($opos_product);
		
		$loyaltyredemption = DB::table('product_pts_redemption')
						->select('product_pts_redemption.systemid as document_no', 
								'product_pts_redemption.id as redemption_id', 'product_pts_redemption.quantity', 
								'product_pts_redemption.created_at as last_update', 'product_pts_redemption.remarks as item_remarks',
								'location.branch as location', 'location.id as locationid')
			->leftjoin('location', 'location.id', '=', 'product_pts_redemption.location_id')
			->where('product_pts_redemption.product_id', $product->id)->distinct()->get();

		
		$item_count = count($opos_product);
		
		foreach ($loyaltyredemption as $key => $value) {
			$opos_product[$item_count] = $value;
			$opos_product[$item_count]->sales_type = "Loyalty";
			$opos_product[$item_count]->item_detail_id = $value->redemption_id;
			$opos_product[$item_count]->stock = false;
			$opos_product[$item_count]->wastage = false;
			$opos_product[$item_count]->refund_type = false;
			$opos_product[$item_count]->voucher = false;
			$opos_product[$item_count]->void = false;
			$opos_product[$item_count]->quantity = 0 - $value->quantity;
			$item_count++;
		}	
	
		
		$merchant_id = Merchant::where('id', $this->user_data->company_id())->pluck('id')->first();
		$location_sales_qty = array();
		// Latest item remarks
		$prev_id = 0;
		$prev_key = 0;
		foreach ($opos_product as $key => $value) {
			
			if ($value->stock) {
				$product_remark = stockreportremarks::orderby('created_at', 'DESC')
					->where('stockreport_id', $value->stockreport_id)
					->where('user_id', Auth::user()->id)->first();
				if ($product_remark) {
					$opos_product[$key]->item_remarks = $product_remark->remarks;
					//return $opos_product[$key]->item_remarks;
				}
			}
			if ($value->wastage) {
				
				$opos_wastage = new opos_wastage();
				$opos_wastage_id = $opos_wastage->where('systemid', $value->document_no)->first();
				$product_remark = wastagereportremarks::orderby('created_at', 'DESC')
					->where('wastage_id', $opos_wastage_id->id)
					->where('user_id', Auth::user()->id)->first();
					//return $opos_wastage_id->id;
					$opos_product[$key]->item_detail_id = $opos_wastage_id->id;
				if ($product_remark) {
					$opos_product[$key]->item_remarks = $product_remark->remarks;
				}
			} else {
				$item_id = $value->item_detail_id;
				$product_remark = opos_itemdetailsremarks::orderby('created_at', 'DESC')
					->where('itemdetails_id', $item_id)
					->where('user_id', Auth::user()->id)->first();
				if ($product_remark) {
					$opos_product[$key]->item_remarks = /*(strlen($product_remark->remarks) > 60 ) ? substr($product_remark->remarks,0,60)."..." : */
						$product_remark->remarks;
				}
				if ($value->refund_type || $value->wastage || $value->voucher ) {
					continue;
				}
				if (isset($value->promo_id)) {
                    $opos_product[$key]->sales_type = "Bundle Sales";
                    $opos_product[$key]->quantity = 0 - $value->quantity;
					if ($value->void == 1) {
                        $opos_product[$key]->sales_type = "Void Sales";
                        $opos_product[$key]->quantity = 0;
                    }

                } else {
                    if ($value->void == 1) {
                        $opos_product[$key]->sales_type = "Void Sales";
                        $opos_product[$key]->quantity = 0;
                    } else {
						if($opos_product[$key]->sales_type != "Loyalty"){
							$opos_product[$key]->sales_type = "Cash Sales";
							$opos_product[$key]->quantity = 0 - $value->quantity;
						}
                    }
                }

			}

		}
		
		// opos_product sort by Lastupdate (db_table.created_at) Desc
		$opos_product = $opos_product->sortBy('last_update', SORT_REGULAR, true);
	//	
		// Product Location Stock data
		$location_data = location::
		join('merchantlocation', 'merchantlocation.location_id', '=', 'location.id')->where('merchant_id', $merchant_id)->whereNotNull('location.branch')->get();
		foreach ($location_data as $key => $value) {
			$final_qty = $this->location_productqty($product->id, $value->location_id);
            $location_data[$key]['quantity'] = $final_qty;
		}

		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		foreach ($opos_product as $key => $value) {
			if($value->document_no == $prev_id && $opos_product[$prev_key]->stock == 1){
				$opos_product[$prev_key]->quantity = $opos_product[$prev_key]->quantity + $value->quantity;
				unset($opos_product[$key]);
			} else {
				$prev_key = $key;
				$prev_id = $value->document_no;
			}			
		}
		
	//	exit;
		
		return view('inventory.inventoryqty', compact('user_roles', 'is_king', 'product', 'product_data', 'opos_product', 'location_data'));
	}
	
	public function showwastagereport(Request $request)
	{

		$id = Auth::user()->id;
	$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		Log::debug('is_king='.json_encode($is_king));

		$company_id = $is_king->id;
		Log::debug('company_id='.$company_id);

		$merchant_id = \App\Models\Merchant::where('company_id',
			$company_id)->value('id');
			$report_id = $request->doc_id;		
		$waste = Merchantproduct::where('merchant_id',$merchant_id)
			 ->join("product", 'merchantproduct.product_id', '=', 'product.id')
			 ->join("opos_wastageproduct",'product.id' , '=','opos_wastageproduct.product_id' )
			 ->join('opos_wastage', 'opos_wastage.id', '=', 'opos_wastageproduct.wastage_id')
			 ->where('opos_wastage.systemid', $report_id)	
		     ->leftjoin('location', 'location.id', '=', 'opos_wastageproduct.location_id')
			 ->select('product.*',  'opos_wastage.systemid as document_no', 'opos_wastageproduct.wastage_qty as quantity', 'opos_wastageproduct.created_at as last_update', 'location.branch as location', 'location.id as locationid')
			 ->get();
	

		//	 dd($wastage);
	
	   
        $wastage = Merchantproduct::where('merchant_id',$merchant_id)
				->join("product", 'merchantproduct.product_id', '=', 'product.id')
				->join("opos_receiptproduct", 'product.id', '=', 'opos_receiptproduct.product_id')
				->join("opos_refund", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
                ->join("opos_damagerefund", 'opos_refund.id' , '=', 'opos_damagerefund.refund_id')
				->join('locationproduct','product.id','=','locationproduct.product_id')
                 ->join('location','locationproduct.location_id','=','location.id')
				->leftjoin('opos_receipt', 'opos_receiptproduct.receipt_id', '=', 'opos_receipt.id')
				 ->where('opos_receipt.systemid', $report_id)
				->select('product.*','opos_receipt.systemid as document_no', 'opos_damagerefund.damage_qty as quantity', 'opos_damagerefund.created_at as last_update','location.branch as location','location.id as locationid')
                ->groupBy('location')
				->get();
				

		$item_count = count($wastage);
		foreach ($waste as $key => $value) {
			$wastage[$item_count] = $value;
			$wastage[$item_count]->type = 'wastage';
			$item_count++;
		}
		
		
	
			
        $wastage_data = Merchantproduct::where('merchant_id',$merchant_id)
				->join("product", 'merchantproduct.product_id', '=', 'product.id')
				->join("opos_receiptproduct", 'product.id', '=', 'opos_receiptproduct.product_id')
				->join("opos_refund", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
				->join("opos_damagerefund", 'opos_refund.id' , '=', 'opos_damagerefund.refund_id')
				->join('locationproduct','product.id','=','locationproduct.product_id')
                 ->join('location','locationproduct.location_id','=','location.id')
				->leftjoin('opos_receipt', 'opos_receiptproduct.receipt_id', '=', 'opos_receipt.id')
				 ->join('users', 'users.id', '=', 'opos_receipt.staff_user_id')
				->join('staff', 'staff.user_id', '=', 'users.id')
				 ->where('opos_receipt.systemid', $report_id)
				->select('product.*','users.name as staff_name', 'staff.systemid as staff_id','opos_receipt.systemid as document_no', 'opos_damagerefund.damage_qty as quantity', 'opos_damagerefund.created_at as last_update','location.branch as location','location.id as locationid')
             	->first();
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventorywastagereport',
			compact('user_roles', 'is_king', 'wastage', 'wastage_data','report_id'));
	}
	
	public function showstockreport(Request $request)
	{
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$stock_system_id = $request->doc_id;
		
		$stockreport = StockReport::
		select('product.*', 'productbarcode.barcode','users.name as staff_name', 'staff.systemid as staff_id', 'stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreport.quantity', 'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 'location.id as locationid')
			->leftjoin('location', 'location.id', '=', 'stockreport.location_id')
			->join('product', 'product.id', '=', 'stockreport.product_id')
			->join('users', 'users.id', '=', 'stockreport.creator_user_id')
			->join('staff', 'staff.user_id', '=', 'stockreport.creator_user_id')
			->leftjoin('productbarcode','product.id', '=', 'productbarcode.product_id')
			->where('stockreport.systemid', $stock_system_id)->get();
		
		if(sizeof($stockreport) == 0){
			$stockreport = StockReport::
				select('product.*', 'productbarcode.barcode','users.name as staff_name', 'staff.systemid as staff_id', 'stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreportproduct.quantity', 'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 'location.id as locationid')
				->leftjoin('location', 'location.id', '=', 'stockreport.location_id')
				->join('stockreportproduct', 'stockreportproduct.stockreport_id', '=', 'stockreport.id')
				->join('product', 'product.id', '=', 'stockreportproduct.product_id')
				->join('users', 'users.id', '=', 'stockreport.creator_user_id')
				->join('staff', 'staff.user_id', '=', 'stockreport.creator_user_id')
				->leftjoin('productbarcode','product.id', '=', 'productbarcode.product_id')
				->where('stockreport.systemid', $stock_system_id)->get();
		}
		$stockreport_data = StockReport::
		select('users.name as staff_name', 'staff.systemid as staff_id', 'stockreport.systemid as document_no', 'stockreport.id as stockreport_id', 'stockreport.type as refund_type', 'stockreport.created_at as last_update', 'location.branch as location', 'location.id as locationid')
			->leftjoin('location', 'location.id', '=', 'stockreport.location_id')
			->join('users', 'users.id', '=', 'stockreport.creator_user_id')
			->join('staff', 'staff.user_id', '=', 'stockreport.creator_user_id')
			->where('stockreport.systemid', $stock_system_id)->first();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventorystockreport',
			compact('user_roles', 'is_king', 'stockreport', 'stockreport_data'));
	}
	
	public function showInventoryQtyDamage()
	{
		$id = Auth::user()->id;
		Log::debug('id='.$id);
		$user_roles = usersrole::where('user_id', $id)->get();
		Log::debug('user_roles='.$user_roles);

		// This will fail on a staff account!!!
		// **** Trying to get property 'id' of non-object ****
		// is_king is the company record of the owner_user_id
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		Log::debug('is_king='.json_encode($is_king));

		$company_id = $is_king->id;
		Log::debug('company_id='.$company_id);

		$merchant_id = \App\Models\Merchant::where('company_id',
			$company_id)->value('id');
		$damage = Merchantproduct::where('merchant_id',$merchant_id)
				->join("product", 'merchantproduct.product_id', '=', 'product.id')
				->join("opos_receiptproduct", 'product.id', '=', 'opos_receiptproduct.product_id')
				 ->join("opos_refund", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
				 ->join("opos_damagerefund", 'opos_refund.id' , '=', 'opos_damagerefund.refund_id')
				 ->leftjoin('opos_receipt', 'opos_receiptproduct.receipt_id', '=', 'opos_receipt.id')
				 ->select('opos_refund.receiptproduct_id','merchantproduct.merchant_id','product.systemid as productsys_id', 'product.id as product_id', 'product.thumbnail_1', 'opos_receiptproduct.name', 'opos_receipt.systemid as document_no', 'opos_receiptproduct.receipt_id', 'opos_damagerefund.damage_qty as quantity', 'opos_refund.refund_type', 'opos_damagerefund.created_at as last_update')
				->get();
	
		$wastage = Merchantproduct::where('merchant_id',$merchant_id)
			 ->join("product", 'merchantproduct.product_id', '=', 'product.id')
			 ->join("opos_wastageproduct",'product.id' , '=','opos_wastageproduct.product_id' )
			 ->join('opos_wastage', 'opos_wastage.id', '=', 'opos_wastageproduct.wastage_id')
			 ->select('product.systemid as productsys_id', 'product.id as product_id', 'product.thumbnail_1', 'product.name', 'opos_wastage.systemid as document_no', 'opos_wastageproduct.wastage_qty as quantity', 'opos_wastageproduct.created_at as last_update')
	
			->get();
		
		$item_count = count($damage);
		foreach ($wastage as $key => $value) {
			$damage[$item_count] = $value;
			$damage[$item_count]->type = 'wastage';
			$item_count++;
		}
		
		$damage = $damage->sortBy('last_update', SORT_REGULAR, true);
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}

		
		return view('inventory.inventoryqtydamage',
			compact('user_roles', 'is_king', 'damage'));
	}
	
	public function showInventoryQtyWastageForm()
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$this->user_data = new UserData();
		$ids = merchantproduct::where('merchant_id',
			$this->user_data->company_id())->pluck('product_id');
		
		$opos_product = product::whereIn('ptype', array('inventory', 'rawmaterial'))->whereNotNull('name')->get();
		$staff_data = Staff::join('users', 'users.id', '=', 'staff.user_id')->where('staff.user_id', Auth::user()->id)->first();
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		$modal = "newLocationDialog";
		$ids = merchantlocation::where('merchant_id', $this->user_data->company_id())->pluck('location_id');
		$location = location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->get();
		
		foreach ($opos_product as $key => $value) {
			$final_qty = $this->check_quantity($value->id);
			$opos_product[$key]['quantity'] = $final_qty;
		}
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventoryqtywastageform',
			compact('user_roles', 'is_king', 'opos_product', 'staff_data', 'location'));
	}
	
	public function showWastageForm(Request $request)
	{
		$this->user_data = new UserData();
		$location_id = $request->get('id');
		$opos_product = array();
		$final_product = array();
		
		if ($location_id) {
			$opos_product = product::whereIn('ptype', array('inventory', 'rawmaterial'))->whereNotNull('name')->get();
			foreach ($opos_product as $key => $value) {
				
				$final_qty = $this->location_productqty($value->id, $location_id);
				
				if ($final_qty <= 0) {
					continue;
				}
				$final_product[$key] = $value;
				$final_product[$key]->quantity = $final_qty;
				$final_product[$key]->product_id = $value->id;
			}
			$opos_product = $final_product;
		}
		
		return Datatables::of($opos_product)->
		addIndexColumn()->
		addColumn('inven_pro_id', function ($memberList) {
			return $memberList->systemid;
		})->
		addColumn('inven_pro_name', function ($memberList) {
			return '<img src="' . asset('images/product/' . $memberList->id . '/thumb/' . $memberList->thumbnail_1) . '" style="height:40px;width:40px;object-fit:contain;margin-right:8px;">' . $memberList->name;
		})->
		addColumn('inven_pro_existing_qty', function ($memberList) {
			return $memberList->quantity;
		})->
		addColumn('inven_pro_qty', function ($memberList) {
			return '<div class="value-button increase" id="increase_' . $memberList->id . '" onclick="increaseValue(' . $memberList->id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
                </div><input type="number" id="number_' . $memberList->id . '"  class="number product_qty" value="0"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->id . ')">
                <div class="value-button decrease" id="decrease_' . $memberList->id . '" onclick="decreaseValue(' . $memberList->id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
                </div>';
		})->
		escapeColumns([])->
		make(true);
		
	}
	
	public function updatewastage(Request $request)
	{
		
		try {
			$id = Auth::user()->id;
			
			$table_data = $request->get('table_data');
			$total_qty = 0;
			$wastage_system = DB::select("select nextval(wastage_seq) as index_damage");
			$wastage_system_id = $wastage_system[0]->index_damage;
			$wastage_system_id = sprintf("%010s", $wastage_system_id);
			$wastage_system_id = '112' . $wastage_system_id;
			
			foreach ($table_data as $key => $value) {
				if ($value['qty'] <= 0) {
					continue;
				}
				$opos_wastage = new opos_wastage();
				$opos_wastage->systemid = $wastage_system_id;
				$opos_wastage->staff_user_id = $id;
				$opos_wastage->save();
				
				
				$stock = new opos_wastageproduct();
				$stock->wastage_id = $opos_wastage->id;
				$stock->product_id = $value['product_id'];
				$stock->location_id = $value['location_id'];
				$stock->wastage_qty = $value['qty'];
				$stock->save();
				$total_qty += $value['qty'];
			}
			if ($total_qty > 0) {
				$msg = "Wastage recorded succesfully";
			} else {
				$msg = "Please select product.";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	
	public function showInventoryQtyLocation()
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventoryqtypdtlocation',
			compact('user_roles', 'is_king'));
	}
	
	
	public function barcodeIndex(Request $request)
	{
		$product = product::where('systemid', $request->system_id)->first();

		$barcodes = SettingBarcodeMatrix::where('category_id',
			$product->prdcategory_id)->
		where('subcategory_id', $product->prdsubcategory_id)->
		get();
		
		return Datatables::of($barcodes)->
		addColumn('bar', function ($barcodes) use ($request) {
			return '<img src="data:image/png;base64,' .
				DNS1D::getBarcodePNG(trim($request->system_id . '-' .
					$barcodes->barcode_numbers), "C128") .
				'" alt="barcode" width="200px" height="70px " ">' .
				'<br> <center>' . $request->system_id . '-' .
				$barcodes->barcode_numbers . '</center>';
		})->
		
		addColumn('color', function ($barcodes) use ($request) {
			return $barcodes->color_code;
		})->
		
		addColumn('sizes', function ($barcodes) use ($request) {
			if ($barcodes->color_id) {
				switch ($barcodes->color_id) {
					case 1:
						return $barcodes->size;
						break;
					case 2:
						$barcodes->size = "S";
						break;
					case 3:
						$barcodes->size = "M";
						break;
					case 4:
						$barcodes->size = "L";
						break;
					case 5:
						$barcodes->size = "XL";
						break;
					case 6:
						$barcodes->size = "XXL";
						break;
				}
			} else {
				return 'Without Color  ' . $barcodes->size;
			}
		})
			->rawColumns(['color'])
			->rawColumns(['sizes'])
			->rawColumns(['bar'])
			->make(true);
	}
	
	
	public function showInventoryBarcode($id)
	{
		$system_id = $id;
		$product = product::where('systemid', $system_id)->first();
		$product_id = $product->id;
		$product_qty = $this->check_quantity($product->id);
		$barcodematrix = SettingBarcodeMatrix::where('category_id', $product->prdcategory_id)->first();
		
		$barcode_sku = productbarcode::where('product_id', $product->id)->first();
		
		$barcode = DNS1D::getBarcodePNG(trim($system_id), "C128");
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		
		return view('inventory.inventorybarcode',
			compact('user_roles', 'is_king', 'barcode', 'product_id', 'system_id', 'product', 'barcodematrix', 'product_qty', 'barcode_sku'));
	}
	
	
	public function showBarcodeTable(Request $request)
	{
		$product_id = $request->id;
		$product = product::where('id', $product_id)->first();
		$product_qty = $this->check_quantity($product->id);
		$barcodematrix = SettingBarcodeMatrix::
			where('category_id', $product->prdcategory_id)->first();
		
		$this->user_data = new UserData();
		$merchant_id = $this->user_data->company_id();

        $merchant_product = DB::table('merchantproduct')->
            select('id')->
            where('merchant_id','=',$merchant_id)->
            where('product_id' ,'=',$product_id)->
            first();

		$barcode_sku = productbarcode::where('product_id', $product->id)->
			where('merchantproduct_id',$merchant_product->id)->
			first();
		
		$barcode = DNS1D::getBarcodePNG(trim($product->systemid), "C128");
		
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		
		$columns = array(
			0 => 'no',
			1 => 'barcode',
			2 => 'qr_code',
			3 => 'color',
			4 => 'matrix',
			5 => 'notes',
			6 => 'qty',
			7 => 'options',
			7 => 'actions'
		);
		$limit = $request->length;
		$start = $request->start;
		$search = $_REQUEST['search']['value'];
		
		$totalRecords = productbarcode::where('product_id', $product->id)->
			where('merchantproduct_id',$merchant_product->id)->
			where([['barcode', 'LIKE', "%" . $search . "%"]])->count();

		$totalFiltered = $totalRecords;
		$totalRecords += 1;
		$totalFiltered += 1;
		
		$barcodes_data = array();
		$count = $start + 1;
		
		$qr = DNS2D::getBarcodePNG($product->systemid, "QRCODE");
		$sku = 'SKU';
		if (!empty($product->sku))
			$sku = $product->sku;

		array_push(
			$barcodes_data, array(
				"no" => $count,
				"barcode" => $product->name ."<br><img src='data:image/png;base64," . $barcode . "' height='60px' width='200px' style='margin-top:0'/><br>" . $product->systemid,
				"qr_code" => "<p id='barcodesku_" . $product_id . "' style='margin-bottom: 0px;'><a href='#' data-is_main='1' class='sku' data-barcode_id='" . $product_id . "'>" . $sku . "</a></p><img src='data:image/png;base64," . $qr . "' height='70px' width='70px' />",
				"color" => "",
				"matrix" => "Colour Black Size XL XXL L M XXXl",
				"notes" => "<strong>Warranty No.325324234<br>Invoice
                        No.
                        5343533</strong>",
				"qty" => "$product_qty",
				"options" => "<a href='#' class='btn btn-success btn-log bg-web sellerbutton'style='padding-top: 25px;margin-bottom:0'>Print</a>",
				"actions" => ""
			)
		);
		
		$barcodes = productbarcode::where('product_id', $product->id)->where('merchantproduct_id',$merchant_product->id)->where([['barcode', 'LIKE', "%" . $search . "%"]])->skip($start)->take($limit)->orderBy('id', 'desc')->get();
		
		foreach ($barcodes as $barcode) {
			$sku = 'SKU';
			$name = 'New Barcode';
			$notes = $barcode->notes;
			if ($barcode->expirydate != '0000-00-00' && $barcode->expirydate != '1970-01-01' && !is_null($barcode->expirydate))
				$notes = "Expiry Date : <strong>" . date("dMy", strtotime($barcode->expirydate)) . "</strong>";
			if (!empty($barcode->sku))
				$sku = $barcode->sku;
			if (!empty($barcode->name))
				$name = $barcode->name;
			$count++;
			$code = DNS1D::getBarcodePNG(trim($barcode->barcode), "C128");
			$qr = DNS2D::getBarcodePNG($barcode->barcode, "QRCODE");
			$final_qty = productbarcodelocation::
			where('productbarcode_id', $barcode->id)
				->sum('quantity');
			
			$barcodes_data[0]['qty'] -= $final_qty;
			$check_barcode = productbarcodelocation::
			where('productbarcode_id', $barcode->id)
				->get();
			if (count($check_barcode) > 0) {
				$actions = '<p style="background-color:#ddd;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor:not-allowed;margin-top:29px">
                    <i class="fas fa-times text-white" style="color:white;opacity:1.0;
                    padding-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px #ccc;"></i></p>';
			} else {
				$actions = '<input type="hidden"  value="' . $barcode->id . '"/><p style="background-color:red;
                    border-radius:5px;margin:auto;
                    width:25px;height:25px;
                    display:block;cursor: pointer;margin-top:29px" class="text-danger remove-barcode">
                    <i class="fas fa-times text-white" style="color:white;opacity:1.0;
                    padding-left:7px;padding-top:4px;
                    -webkit-text-stroke: 1px red;"></i></p>';
			}
			
			array_push(
				$barcodes_data, array(
					"no" => $count,
					"barcode" => "<p id='barcodename_" . $barcode->id. "' style='margin-bottom: 0px; margin-top : 10px;'><a href='#!' data-is_main='0' class='name' data-barcode_id='" . $barcode->id . "'>" .  $name . "</a></p>"."<img src='data:image/png;base64," . $code . "' height='60px' width='200px' style='margin-top:0'/><br>" . $barcode->barcode,
					"qr_code" => "<p id='barcodesku_" . $barcode->id . "' style='margin-bottom: 0px;'><a href='#' data-is_main='0' class='sku' data-barcode_id='" . $barcode->id . "'>" . $sku . "</a></p><img src='data:image/png;base64," . $qr . "' height='70px' width='70px' />",
					"color" => "",
					"matrix" => "",
					"notes" => $notes,
					"qty" => $final_qty,
					"options" => "<a href='#' class='btn btn-success btn-log bg-web sellerbutton'style='padding-top: 25px;margin-bottom:0'>Print</a>",
					"actions" => $actions
				)
			);
		}
		
		
		echo json_encode(array(
			"draw" => intval($_REQUEST['draw']),
			"recordsTotal" => $totalRecords,
			"recordsFiltered" => $totalFiltered,
			"data" => $barcodes_data
		));
	}
	
	
	function deleteBarcode(Request $request)
	{
		$barcode_id = $request->barcode_id;
		productbarcode::where('id', $barcode_id)->delete();
		$msg = "Barcode deleted successfully";
		$html = view('layouts.dialog', compact('msg'))->render();
		return $html;
    }


    function saveExpiry(Request $request){
        $system_id = trim($request->system_id);
        $product_id = trim($request->product_id);
        $month = trim($request->month);
        $month += 1;
        if($month < 10)
            $month = '0'.$month;
        $day = trim($request->day);
        if($day < 10)
            $day = '0'.$day;
        $year = trim($request->year);
        $year = substr($year,2);

        $expiry_date = $year."-".$month."-".$day;

        $this->user_data = new UserData();
        $merchant_id = $this->user_data->company_id();

        $merchant_product = DB::table('merchantproduct')->
            select('id')->
            where('merchant_id','=',$merchant_id)->
            where('product_id' ,'=',$product_id)->
            first();

        $barcode = $system_id." ".$day."".$month."".$year;
        $check = productbarcode::where('merchantproduct_id',$merchant_product->id)
        ->where('product_id',$product_id)
        ->where('barcode',$barcode)
        ->get();
	    if(count($check) > 0 ){
			$msg = "Duplicate barcode not allowed.";
	        $html = view('layouts.dialog', compact('msg'))->render();
        } else {
	        $product_barcode = new productbarcode();
	        $product_barcode->merchantproduct_id = $merchant_product->id;
	        $product_barcode->product_id = $product_id;
	        $product_barcode->barcode = $barcode;
	        $product_barcode->expirydate = $expiry_date;
	        $product_barcode->save();
	        $msg = "Saved expiry date successfully";
	        $html = view('layouts.dialog', compact('msg'))->render();
        }
        return $html;
    }

   
	/**
	 * Create Barcode from user input range
	 *
	 * @param Request $request
	 * @return \Illuminate\Http\JsonResponse
	 * @throws \Exception
	 */
	public function createBarcodeFromInputRange(Request $request)
	{
		$this->barcodeGeneratorValidator($request);
		
		$barcode_from 	= (int) $request->get('barcode_from');
		$barcode_to 	= (int) $request->get('barcode_to');
		$product_id 	= $request->get('product_id');
		$barcode_notes 	= $request->get('barcode_notes');
		$merchant_id 	= (new UserData())->company_id();

        $merchant_product = DB::table('merchantproduct')->
            select('id')->
            where('merchant_id','=',$merchant_id)->
            where('product_id' ,'=',$product_id)->
            first();

		if ($barcodes = $this->checkIfBarcodesExistWithRange($product_id, $merchant_product->id, $barcode_from, $barcode_to)) {
			$unique_barcodes = array_unique($barcodes);
			sort($unique_barcodes);
			if(count($unique_barcodes) > 10) {
				return response()->json([
					'status' 	=> 'success',
					'message' 	=> 'System detected clashing barcodes already in existence: <div class="text-left"><br/>'
						.implode('<br/>', array_slice($unique_barcodes, 0, 10)).'<br>Another '.(count($unique_barcodes)-10).' barcodes existed.</div>',
				]);
			} else {
				return response()->json([
					'status' 	=> 'success',
					'message' 	=> 'System detected clashing barcodes already in existence: <div class="text-left"><br/>'
						.implode('<br/>', array_slice($unique_barcodes, 0, 10)).'</div>',
				]);
			}
		}
		
		$this->createMultipleBarcodesWithRanges($barcode_from, $barcode_to, [
			'barcode_type' 			=> 'C128',
			'product_id' 			=> $product_id,
			'merchantproduct_id' 	=> $merchant_product->id,
			'notes' 	=> $barcode_notes
		]);
		
		return response()->json([
			'status' 	=> 'success',
			'message' 	=> 'Barcode generated successfully',
		]);
	}
	
	
	/**
	 * Create Multiple Barcodes
	 *
	 * @param $barcode_from
	 * @param $barcode_to
	 * @param $otherAttributes array
	 */
	public function createMultipleBarcodesWithRanges($barcode_from, $barcode_to, $otherAttributes)
	{
		$now = Carbon::now()->toDateTimeString();
		$build_barcode_array = [];
		
		for ($i = $barcode_from; $i <= $barcode_to; $i++) {
			$build_barcode_array[] = array_merge(
				['barcode' => $i, 'created_at' => $now, 'updated_at' => $now],
				$otherAttributes
			);
		}
		
		productbarcode::insert($build_barcode_array);
	}
	
	/**
	 * Generate Barcode from ranges
	 *
	 * @param $product_id
	 * @param $merchant_id
	 * @param $barcode_from
	 * @param $barcode_to
	 * @return boolean
	 */
	private function checkIfBarcodesExistWithRange($product_id, $merchant_id, $barcode_from, $barcode_to)
	{
		$barcodes = productbarcode::where(DB::raw('CAST(barcode AS UNSIGNED)'), '>=', $barcode_from)
			->where(DB::raw('CAST(barcode AS UNSIGNED)'), '<=', $barcode_to)
			->where('product_id', $product_id)
			->where('merchantproduct_id', $merchant_id)
			->pluck('barcode')
			->toArray();
		
		return (count($barcodes) > 0) ? $barcodes : false;
	}
	
	/**
	 * Barcode Generator Validator
	 *
	 * @param $request
	 */
	private function barcodeGeneratorValidator($request)
	{
		$request->validate([
			'barcode_from' => 'bail|required|integer|min:1',
			'barcode_to' => ['required', 'integer', 'gt:barcode_from',
				function ($attribute, $value, $fail) use ($request) {
					if (($value - $request->get('barcode_from')) > 10000) {
						$fail('The range between barcode must not exceed 10,000.');
					}
				},
			],
		], [
			'barcode_from.required' => 'Barcode minimum range is required',
			'barcode_from.integer' => 'Barcode minimum range must be a number',
			'barcode_from.min' => 'Barcode minimum range must be a positive number greater than 0',
			'barcode_to.required' => 'Barcode maximum range is required',
			'barcode_to.integer' => 'Barcode maximum range must be a number',
			'barcode_to.gt' => 'Barcode maximum range must be greater than Barcode minimum range',
		]);
	}
	
	
	function saveBarcode(Request $request)
	{
		$barcodes = trim($request->barcodes);
		$barcodes = str_replace("\n", ";", $barcodes);
		$barcodes = str_replace(",", ";", $barcodes);
		$parts = explode(';', $barcodes);
		
		Log::debug('parts=' . json_encode($parts));
		
		$this->user_data = new UserData();
		$merchant_id = $this->user_data->company_id();
		$duplicate_barcodes = "";
		
		$merchant_product = DB::table('merchantproduct')->
		select('id')->
		where('merchant_id', '=', $merchant_id)->
		where('product_id', '=', $request->id)->
		first();
		
		Log::debug('merchant_product=' . json_encode($merchant_product));
		
		
		$is_duplicate = false;
		foreach ($parts as $part) {
			$part = trim($part);
			
			Log::debug('merchant_id=' . $merchant_id);
			Log::debug('product_id =' . $request->id);
			Log::debug('barcode    =' . $part);
			
			$count = DB::table('merchantproduct as mp')->
			join('productbarcode as pb', 'mp.id', '=',
				'pb.merchantproduct_id')->
			select('pb.barcode')->
			where('mp.merchant_id', '=', $merchant_id)->
			// where('mp.product_id', '=', $request->id)->
			where('pb.barcode', '=', $part)->
			count();
			
			Log::debug('count=' . json_encode($count));
			
			if (empty($count)) {
				$product_barcode = new productbarcode();
				$product_barcode->merchantproduct_id = $merchant_product->id;
				$product_barcode->product_id = $request->id;
				$product_barcode->barcode = $part;
				$product_barcode->save();
				
			} else {
				$is_duplicate = true;
				$duplicate_barcodes .= $part . "<br>";
			}
		}
		
		if ($is_duplicate) {
			$msg = "Duplicated barcodes found:<br>" .
				$duplicate_barcodes;
			
			$html = view('layouts.dialog', compact('msg'))->render();
			return $html;
			
		} else {
			return 0;
		}
	}
	
	
	public function showInventoryCost($product_id)
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}

        $userId = Auth::user()->id;
        $merchant = Merchant::select('merchant.id as id')
            ->join('company', 'company.id', '=', 'merchant.company_id')
            ->where('company.owner_user_id', $userId)->first();



        $averageCost = inventorycost::selectRaw("format(sum((cost/100) * quantity)/sum(quantity),2) as  average_cost")
            ->join('inventorycostproduct', 'inventorycostproduct.inventorycost_id', '=', 'inventorycost.id')
            ->where('inventorycost.buyer_merchant_id', $merchant->id)->where('inventorycostproduct.product_id', $product_id)->first()->toArray();

        $quantity_left = $this->check_quantity($product_id);
        $product = product::find($product_id);

        return view('inventory.inventorycost',
			compact('user_roles', 'is_king', 'product_id', 'quantity_left', 'product', 'averageCost'));
	}

    public function productInventoryCost(Request $request, $product_id)
    {

        $buyerMerchantId = Auth::user()->id;
        $merchant = Merchant::select('merchant.id as id')
            ->join('company', 'company.id', '=', 'merchant.company_id')
            ->where('company.owner_user_id', $buyerMerchantId)->first();

        $query = inventorycost::selectRaw("inventorycost.id as inventory_cost_id,DATE_FORMAT(doc_date, '%d%b%y') as dated ,doc_no, Format(inventorycostproduct.cost / 100, 2) as cost,inventorycostproduct.quantity as quantity")
            ->join('inventorycostproduct', 'inventorycostproduct.inventorycost_id', '=', 'inventorycost.id');


        /*
        // name filter
        $search = $request->input('search');
        if (isset($search['value']) && $search['value'] != '')
            $query->where('title', 'like', '%'.$search['value'].'%');
        */

        /*
        // order by
        $order = $request->input('order');
        if (isset($order[0]['column']) && $order[0]['column'] != '') {
            if ($order[0]['column'] == 2) {
                $query->orderBy('title', $order[0]['dir']);
            }
            if ($order[0]['column'] == 4) {
                $query->orderBy('price', $order[0]['dir']);
            }
        }
        */

        $query->where('inventorycost.buyer_merchant_id', $merchant->id)->where('inventorycostproduct.product_id', $product_id);

        $query->orderBy('inventorycostproduct.id', 'desc');


        $totalRecords = $query->get()->count();

        // applying limit
        $productCostDetails = $query->skip($request->input('start'))->take($request->input('length'))->get();


        $counter = 0 + $request->input('start');

        foreach ($productCostDetails as $key => $productCost) {
            $productCostDetails[$key]['indexNumber'] = ++$counter;
        }

        $response = [
            'data' => $productCostDetails,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords
        ];
        return response()->json($response);
    }
	
	
	public function showInventoryStockIn()
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		$this->user_data = new UserData();
		$modal = "newLocationDialog";
		$ids = merchantlocation::where('merchant_id', $this->user_data->company_id())->pluck('location_id');
		$location = location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->get();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventorystockin',
			compact('user_roles', 'is_king', 'location'));
	}
	
	
	public function get_location_product(Request $request)
	{
		$this->user_data = new UserData();
		$modal = "newLocationDialog";
		$ids = merchantproduct::where('merchant_id',
			$this->user_data->company_id())->pluck('product_id');
	
		$location_id = $request->get('id');
	
		$type = $request->get('type');
		$source = $request->get('source');
		$opos_product = array();
		$final_product = array();
		$rack = array();
		$index = 0;
	//	dd($location_id);
	//	exit;
		if ($location_id) {
			
			$location = location::where('id', $location_id)->first();
			if ($source) {
				
				$opos_product = product::whereIn('ptype',
					array('inventory', 'rawmaterial'))->
					whereNotNull('name')->
					whereNotNull('prdcategory_id')->
					whereIn('id', $ids)->
					get();

			} else {
				$ptype = ($request->get('product_type')) ?
					$request->get('product_type') : 'inventory';

				$opos_product = product::where('ptype', $ptype)->
					whereNotNull('name')->
					whereNotNull('prdcategory_id')->
					whereIn('id', $ids)->get();
						
			}

			Log::debug('location=' . json_encode($location));
			// check if location is warehouse
			if ($location->warehouse == 1) {
		
				$rack_data = $request->get('rack_data');
				$warehouse = warehouse::where('location_id', $location_id)->
					first();

				Log::debug('warehouse=' . json_encode($warehouse));
				
				if ($warehouse) {
					$rack_list = rack::where('warehouse_id',
						$warehouse->id)->get();
				}

				foreach ($opos_product as $key => $value) {
					// $final_qty = $this->location_productqty($value->id, $location_id);
					if ($warehouse) {
						$rack_product_qty = 0;
						// $rack_id = '';
						$rack = array();
						$total_qty = 0;
						$valid_rack = array();
						foreach ($rack_list as $rk_key => $rk_value) {
							$rack_product_count = stockreportproductrack::
							join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
								->where('stockreportproduct.product_id', $value->id)
								->where('stockreportproductrack.rack_id', $rk_value->id)
								->sum('stockreportproduct.quantity');
							
							if ($type == "OUT") {
								if ($rack_product_count <= 0) {
									continue;
								}
								$valid_rack[] = $rk_value->id;
							}
							$rack[$rk_key] = $rk_value;
							$total_qty += $rack_product_count;
						}

						if ($type == 'OUT') {
							$rack_all = rack::where('warehouse_id',
								$warehouse->id)->
								whereIn('id', $valid_rack)->
								pluck('id');

						} else {
							$rack_all = rack::where('warehouse_id',
								$warehouse->id)->
								pluck('id');
						}

						$rack_id = stockreportproductrack::
						join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
							->where('stockreportproduct.product_id', $value->id)
							->whereIn('stockreportproductrack.rack_id', $rack_all)
							->orderby('stockreportproductrack.id', 'desc')->value('rack_id');

						if (empty($rack_id)) {
							$rack_id = rack::where('warehouse_id',
								$warehouse->id)->orderby('id', 'asc')->
								value('id');
						}

						$final_qty = $this->location_productqty($value->id,
							$location_id);

						if ($type == "OUT") {
							if ($final_qty <= 0) {
								continue;
							}

							$barcodes = productbarcode::select('productbarcode.id as barcode_id', 'productbarcode.*', 'product.*')
								->join('product', 'product.id', '=', 'productbarcode.product_id')
								->where('product_id', $value->id)
								->orderBy('product.systemid', 'desc')->get();
						     Log::debug('stock out barcodes = '.json_encode($barcodes));

							$barcode_qty = 0;
							foreach ($barcodes as $b_key => $b_value) {
								$b_rack_product_qty = 0;
								
								$b_total_qty = 0;
								$b_valid_rack = array();
								foreach ($rack_list as $rk_key => $rk_value) {
									$rack_product_count = productbarcodelocation::
									where('productbarcode_id', $b_value->barcode_id)
										->where('location_id', $location_id)
										->where('rack_id', $rk_value->id)
										->sum('quantity');
									
									if ($rack_product_count <= 0) {
										continue;
									}
									$b_valid_rack[] = $rk_value->id;
									$rack[$rk_key] = $rk_value;
									$b_total_qty += $rack_product_count;
								}

								$b_rack_all = rack::where('warehouse_id',
									$warehouse->id)->
									whereIn('id', $b_valid_rack)->pluck('id');

								$b_rack_id = productbarcodelocation::
								where('productbarcode_id', $b_value->barcode_id)
									->where('location_id', $location_id)
									->whereIn('rack_id', $b_rack_all)
									->orderby('id', 'desc')
									->pluck('rack_id')->first();
								
								if (empty($b_rack_id)) {
									$b_rack_id = rack::where('warehouse_id',
										$warehouse->id)->
										orderby('id', 'asc')->
										pluck('id')->first();
								}

								if ($b_total_qty <= 0) {
									continue;
								}

								$b_final_qty = $b_total_qty;
								if ($rack_data) {
									foreach ($rack_data as $rd_key => $rd_value) {
										if ($rd_value['product_id'] == $b_value->barcode_id) {
											$b_rack_id = $rd_value['rack_id'];
										}
									}
								}
								log::debug('b_rack_id' . $b_rack_id);
								if ($b_rack_id) {
									$b_total_qty = productbarcodelocation::
									where('productbarcode_id', $b_value->barcode_id)
										->where('rack_id', $b_rack_id)
										->where('location_id', $location_id)
										->sum('quantity');
								}
								log::debug('b_total_qty' . $b_total_qty);
								$b_rack_no = rack::where('id', $b_rack_id)->value('rack_no');
								
								$final_product[$index] = $b_value;
								$final_product[$index]->warehouse = 1;
								$final_product[$index]->existing_qty = $b_final_qty;
								$final_product[$index]->quantity = $b_total_qty;
								$final_product[$index]->product_id = $b_value->barcode_id;
								$final_product[$index]->systemid = $b_value->barcode;
								$final_product[$index]->first_product = 0;
								$final_product[$index]->rack = $rack;
								$final_product[$index]->rack_id = $b_rack_id;
								$final_product[$index]->rack_no = $b_rack_no;
								$final_product[$index]->location_id = $location_id;
								$barcode_qty += $b_final_qty;
								$index++;
							}
							
						}
						if ($rack_data) {
							foreach ($rack_data as $rd_key => $rd_value) {
								if ($rd_value['product_id'] == $value->id) {
									$rack_id = $rd_value['rack_id'];
								}
							}
						}
						if ($rack_id) {
							$total_qty = stockreportproductrack::
							join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
								->where('stockreportproduct.product_id', $value->id)
								->where('stockreportproductrack.rack_id', $rack_id)
								->sum('stockreportproduct.quantity');
						}
						$rack_no = rack::where('id', $rack_id)->value('rack_no');
						$final_product[$index] = $value;
						$final_product[$index]->warehouse = 1;
						if ($type == 'OUT') {
							$final_product[$index]->existing_qty = $final_qty - $barcode_qty;
						} else {
							$final_product[$index]->existing_qty = $final_qty;
						}
						$final_product[$index]->first_product = 1;
						$final_product[$index]->quantity = $total_qty;
						$final_product[$index]->product_id = $value->id;
						$final_product[$index]->rack = $rack;
						$final_product[$index]->rack_id = $rack_id;
						$final_product[$index]->rack_no = $rack_no;
						$final_product[$index]->location_id = $location_id;
						$index++;
					}
				}
				
			} else {
				foreach ($opos_product as $key => $value) {
					$final_qty = $this->location_productqty($value->id, $location_id);
				
					if ($type == "OUT") {
						// if ($final_qty <= 0) {
						// 	continue;
						// }
						$barcodes = productbarcode::select('productbarcode.id as barcode_id', 'productbarcode.*', 'product.*')
							->join('product', 'product.id', '=', 'productbarcode.product_id')
							->where('product_id', $value->id)
							->orderBy('productbarcode.id', 'desc')->get();
							
						$barcode_qty = 0;
						foreach ($barcodes as $b_key => $b_value) {
							
							
							$final_qty_barcode = productbarcodelocation::
							where('productbarcode_id', $b_value->barcode_id)
								->where('location_id', $location_id)
								->sum('quantity');
							
							if ($final_qty_barcode <= 0) {
								continue;
							}
							
							$final_product[$index] = $b_value;
							$final_product[$index]->existing_qty = $final_qty_barcode;
							$final_product[$index]->quantity = $final_qty_barcode;
							$final_product[$index]->rack = $rack;
							$final_product[$index]->product_id = $value->barcode_id;
							$final_product[$index]->systemid = $value->barcode;
							$final_product[$index]->first_product = 0;
							$final_product[$index]->location_id = $location_id;
							$barcode_qty += $final_qty_barcode;
							$index++;
						}
					}
					$final_product[$index] = $value;
					if ($type == "OUT") {
						$final_product[$index]->existing_qty = $final_qty - $barcode_qty;
				
					} else {
						$final_product[$index]->existing_qty = $final_qty;
					}
					$final_product[$index]->first_product = 1;
					$final_product[$index]->quantity = $final_qty;
					$final_product[$index]->product_id = $value->id;
					$final_product[$index]->rack = $rack;
					$final_product[$index]->location_id = $location_id;
					$index++;
				}
			}
			$i =0;
			foreach ($final_product as $key => $value) {
				
				if($value->systemid!=null){
					$opos_product[$i]=$value;
					$i++;
				}

				
			}
			$j= count($opos_product);
			foreach ($final_product as $key => $value) {
			
				if($value->systemid==null){
					$opos_product[$j]=$value;
					$j++;
				}
				
				
			}

		}

		if ($type == "OUT") {
			return Datatables::of($opos_product)->
			
			addIndexColumn()->
			addColumn('inven_pro_id', function ($memberList) {

				if($memberList->systemid!=''){
					return $memberList->systemid;
				}else{
				  return $memberList->barcode;
				}
			
			})->
			addColumn('inven_pro_name', function ($memberList) {
				return '<img src="' . asset('images/product/' . $memberList->id . '/thumb/' . $memberList->thumbnail_1) . '" style="height:40px;width:40px;object-fit:contain;margin-right:8px;">' . $memberList->name;
			})->
			addColumn('inven_pro_colour', function ($memberList) {
				$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
					->where('productcolor.product_id', $memberList->product_id)->first();
				if ($product_color) {
					return $product_color->name;
				}
				return "-";
			})->
			addColumn('inven_pro_matrix', function ($memberList) {
				return '-';
			})->
			addColumn('inven_pro_rack', function ($memberList) {
				// Squidster: protect count() from null
				if (!empty($memberList) and !empty($memberList->rack)) {
					if (count($memberList->rack) <= 0) {
						return '-';
					}
				}
				return '<div style="cursor: pointer;"
                        class="rack_list" id="' . $memberList->product_id . '" onclick="open_rack(' . $memberList->product_id . ',' . $memberList->first_product . ')">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';
			})->
			addColumn('inven_pro_existing_qty', function ($memberList) {
				return $memberList->existing_qty;
			})->
			addColumn('inven_pro_qty', function ($memberList) {
				if($memberList->systemid!=''){
						return '<div class="value-button increase" id="increase_' . $memberList->product_id . '" onclick="increaseValue(' . $memberList->product_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
                    </div><input type="number" onkeyup="check_value(' . $memberList->product_id . ')" id="number_' . $memberList->product_id . '"  class="number product_qty" value="0"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->product_id . ')">
                    <div class="value-button decrease" id="decrease_' . $memberList->product_id . '" onclick="decreaseValue(' . $memberList->product_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
                    </div>';
					}else{
						return '<div class="value-button increase" id="increase_' . $memberList->barcode_id . '" onclick="increaseValue(' . $memberList->barcode_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
                    </div><input type="number" onkeyup="check_value(' . $memberList->barcode_id . ')" id="number_' . $memberList->barcode_id . '"  class="number product_qty" value="0"  min="0" max="' . $memberList->quantity . '" required onblur="check_max(' . $memberList->barcode_id . ')">
                    <div class="value-button decrease" id="decrease_' . $memberList->barcode_id . '" onclick="decreaseValue(' . $memberList->barcode_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
                    </div>';
				}
				
			})->
			addColumn('inven_bluecrab', function ($memberList) {
				if($memberList->systemid!=''){
					return '<p data-field="bluecrab"
                        style="padding-top:1.4px;display:block;cursor: pointer;"
                        class=" btn-primary bg-bluecrab"
                        data-toggle="modal"><a class="os-linkcolor" href="barcodeinventoryout/' . $memberList->systemid . '/' . $memberList->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
	
				
				}else{

					return '<p data-field="bluecrab"
                        style="padding-top:1.4px;display:block;cursor: pointer;"
                        class=" btn-primary bg-bluecrab"
                        data-toggle="modal"><a class="os-linkcolor" href="barcodeinventoryout/' . $memberList->barcode . '/' . $memberList->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
	
				  
				}
				
			})
			->
			escapeColumns([])->
			make(true);

		} else {
			
			return Datatables::of($opos_product)->
			addIndexColumn()->
			addColumn('inven_pro_id', function ($memberList) {
				return $memberList->systemid;
			})->
			addColumn('inven_pro_name', function ($memberList) {
				return '<img src="' . asset('images/product/' . $memberList->id . '/thumb/' . $memberList->thumbnail_1) . '" style="height:40px;width:40px;object-fit:contain;margin-right:8px;">' . $memberList->name;
			})->
			addColumn('inven_pro_colour', function ($memberList) {
				$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
					->where('productcolor.product_id', $memberList->id)->first();
				if ($product_color) {
					return $product_color->name;
				}
				return "-";
			})->
			addColumn('inven_pro_matrix', function ($memberList) {
				return '-';
			})->
			addColumn('inven_pro_rack', function ($memberList) {
				if (count($memberList->rack) <= 0) {
					return '-';
				}
				return '<div style="cursor: pointer;"
                        class="rack_list" id="' . $memberList->id . '" onclick="open_rack(' . $memberList->id . ',)">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';                       // <div class="os-linkcolor rack_list" style="cursor:pointer" id="'.$memberList->id.'" onclick="open_rack('.$memberList->id.',)" >'.(($memberList->rack_id) ? $memberList->rack_id : "-" ).' </div>';
			})->
			addColumn('inven_pro_existing_qty', function ($memberList) {
				return $memberList->existing_qty;
			})->
			addColumn('inven_pro_qty', function ($memberList) {
				
				return '<div class="value-button increase" id="increase_' . $memberList->id . '" onclick="increaseValue(' . $memberList->id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
                    </div><input type="number" onkeyup="check_value(' . $memberList->id . ')" id="number_' . $memberList->id . '"  class="number product_qty" value="0" min="0"  required>
                    <div class="value-button decrease" id="decrease_' . $memberList->id . '" onclick="decreaseValue(' . $memberList->id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
                    </div>';
			})->
			addColumn('inven_bluecrab', function ($memberList) {
				return '<p data-field="bluecrab"
                        style="padding-top:1.4px;display:block;cursor: pointer;"
                        class=" btn-primary bg-bluecrab"
                        data-toggle="modal" ><a class="os-linkcolor" href="barcodeinventoryin/' . $memberList->systemid . '/' . $memberList->location_id . '" target="_blank" style="color:#fff;text-decoration: none;">O</a></p>';
			})->
			escapeColumns([])->
			make(true);
		}
	}
	
	public function selectRack(Request $request)
	{
		
		try {
			$product_id = $request->get('product_id');
			$location_id = $request->get('location_id');
			$type = $request->get('type');
			$product_type = $request->get('product_type');
			$fieldName = 'select_rack';
			$warehouse = warehouse::where('location_id', $location_id)->first();
			Log::debug('warehouse=' . json_encode($warehouse));
			if ($warehouse) {
				$rack_list = rack::where('warehouse_id', $warehouse->id)->get();
				// $final_qty = $this->location_productqty($value->id, $location_id);
				
				$rack_product_qty = 0;
				$rack_id = '';
				$rack = array();
				$total_qty = 0;
				foreach ($rack_list as $rk_key => $rk_value) {
					if ($product_type == 'barcode') {
						$rack_product_count = productbarcodelocation::
						where('productbarcode_id', $product_id)
							->where('rack_id', $rk_value->id)
							->where('location_id', $location_id)
							->sum('quantity');
					} else {
						
						$rack_product_count = stockreportproductrack::
						join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
							->where('stockreportproduct.product_id', $product_id)
							->where('stockreportproductrack.rack_id', $rk_value->id)
							->sum('stockreportproduct.quantity');
					}
					
					if ($type == "OUT") {
						if ($rack_product_count <= 0) {
							continue;
						}
					}
					$rack[$rk_key] = $rk_value;
					$total_qty += $rack_product_count;
				}
			}
			return view('inventory.inventory-modals',
				compact(['product_id', 'fieldName', 'rack']));
			
		} catch (\Illuminate\Database\QueryException $ex) {
			$response = (new ApiMessageController())->queryexception($ex);
		}
	}
	
	public function updateProductQuantitystock(Request $request)
	{
		
		try {
			$id = Auth::user()->id;
			
			$table_data = $request->get('table_data');
			$stock_type = $request->get('stock_type');
			$total_qty = 0;
			$stock_system = DB::select("select nextval(stockreport_seq) as index_stock");
			$stock_system_id = $stock_system[0]->index_stock;
			$stock_system_id = sprintf("%010s", $stock_system_id);
			$stock_system_id = '111' . $stock_system_id;


			log::debug('qty value:' . json_encode($table_data));
			foreach ($table_data as $key => $value) {
	            foreach ($table_data as $k => $v) {
	                if($value["product_id"] == $v["product_id"] && $key != $k && $value["location_id"] == $v["location_id"] ){
	                    unset($table_data[$key]);
	                    continue;
	                }
	            }
	        }

		
			foreach ($table_data as $key => $value) {
				
				Log::debug('value='.json_encode($value));

				// Don't add new record if qty <= 0
				if ($value['qty'] <= 0) continue;

				$pbloc = new productbarcodelocation();

				// Squidster: this is NOT correct!!
				$pbloc->productbarcode_id = $value['product_id'];

				$pbloc->location_id = $value['location_id'];
			
					$pbloc->rack_id = 0;
			
				$pbloc->quantity = ($stock_type == 'IN') ?
					$value['qty'] : '-' . $value['qty'];

				$pbloc->save();

				Log::debug('value["product_id"]='.
					json_encode($value['product_id']));
				$bar_product = productbarcode::where('product_id',
								$value['product_id'])->first();

				if($bar_product==null){
					$bar_product = productbarcode::where('id',
								$value['product_id'])->first();
				}	
		
				Log::debug('bar_product='.json_encode($bar_product));

				if($bar_product==null){
						$product_details = product::where('id',
					$value['product_id'])->first();
				}else{
					$product_details = product::where('id',
									$bar_product->product_id)->first();

				}	
			

				$stock = new StockReport();
				$stock->creator_user_id = Auth::user()->id;

				//('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
				$stock->type = ($stock_type == 'IN') ? 3 : 4;
				$stock->systemid = $stock_system_id;
				$stock->quantity = ($stock_type == 'IN') ?
					$value['qty'] : '-' . $value['qty'];

				$stock->product_id = $product_details->id;
				$stock->status = 'confirmed';
				$stock->location_id = $value['location_id'];
				$stock->save();
				$total_qty += $value['qty'];
			}
		
			if ($total_qty > 0) {
				if ($stock_type == "IN") {
					$msg = "Stock In performed succesfully";
				} else {
					$msg = "Stock Out performed succesfully";
				}
			} else {
				$msg = "Please select product";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	public function updateRackProductQuantitystock(Request $request)
	{
		
		try {
			$id = Auth::user()->id;
			
			$table_data = $request->get('table_data');
			$stock_type = $request->get('stock_type');
			
			$total_qty = 0;
			$stock_system = DB::select("select nextval(stockreport_seq) as index_stock");
			$stock_system_id = $stock_system[0]->index_stock;
			$stock_system_id = sprintf("%010s", $stock_system_id);
			$stock_system_id = '111' . $stock_system_id;
			
			foreach ($table_data as $key => $value) {
				if ($value['qty'] <= 0) {
					continue;
				}
				
				$rackproduct = rackproduct::where('rack_id', '=', $value['rack_id'])->where('product_id', '=', $value['product_id'])->orderby('id', 'desc')->first();
				if ($rackproduct) {
					$curr_qty = $rackproduct->quantity;
					if ($stock_type == "IN") {
						$curr_qty += $value['qty'];
					} else {
						$curr_qty -= $value['qty'];
					}
				} else {
					$curr_qty = $value['qty'];
				}
				log::debug('curr_qty' . $curr_qty);
				log::debug('value:' . json_encode($value));
				$product = new rackproduct();
				$product->product_id = $value['product_id'];
				$product->rack_id = $value['rack_id'];
				$product->quantity = $curr_qty;
				$product->save();
				
				$stockreport = new StockReport();
				$stockreport->type = ($stock_type == 'IN') ? 3 : 4; //('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
				$stockreport->creator_user_id = Auth::user()->id;
				$stockreport->systemid = $stock_system_id;
				$stockreport->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
				$stockreport->product_id = $value['product_id'];
				$stockreport->status = 'confirmed';
				$stockreport->location_id = $value['location_id'];
				$stockreport->save();
				
				$stockreportproduct = new stockreportproduct();
				$stockreportproduct->quantity = ($stock_type == 'IN') ? $value['qty'] : '-' . $value['qty'];
				$stockreportproduct->stockreport_id = $stockreport->id;
				$stockreportproduct->product_id = $value['product_id'];
				$stockreportproduct->save();
				
				$stockreportproductrack = new stockreportproductrack();
				$stockreportproductrack->stockreportproduct_id = $stockreportproduct->id;
				$stockreportproductrack->rack_id = $value['rack_id'];
				$stockreportproductrack->save();
				$total_qty += $value['qty'];
			}
			
			if ($total_qty > 0) {
				if ($stock_type == "IN") {
					$msg = "Stock In performed succesfully";
				} else {
					$msg = "Stock Out performed succesfully";
				}
			} else {
				$msg = "Please select product";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	
	public function barcodeinventoryin($system_id, $location_id)
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		$product = product::where('systemid', $system_id)->first();
		$location = location::where('id', $location_id)->first();
		
		return view('inventory.barcodeinventoryin',
			compact('user_roles', 'is_king', 'product', 'system_id', 'location'));
		
	}
	
	public function get_product_barcodes(Request $request)
	{
	
		$product = product::where('systemid', $request->system_id)->first();
		$location_id = $request->location_id;
		$type = $request->type;
		$product_id = $product->id;
		$product_qty = $this->check_quantity($product->id);
		$barcodematrix = SettingBarcodeMatrix::where('category_id', $product->prdcategory_id)->first();
		
		$product->quantity = $this->location_productqty($product->id, $location_id);
		$product->barcode = $product->systemid;
		$product->barcode_id = $product->id;
		
		$barcode_sku = productbarcode::where('product_id', $product->id)->first();
		$barcodes = productbarcode::select('productbarcode.id as barcode_id', 'productbarcode.*', 'product.*')
			->join('product', 'product.id', '=', 'productbarcode.product_id')
			->where('product_id', $product->id)
			->orderBy('productbarcode.id', 'desc')->get();
		$barcode_product = array();
		$barcode_product[0] = $product;
		$index = 1;
		foreach ($barcodes as $key => $value) {
			$barcode_product[$index] = $value;
			$index++;
		}
		
		
		$final_product = array();
		$rack = array();
		$location = location::where('id', $location_id)->first();
		Log::debug('location=' . json_encode($location));
		Log::debug('location warehouse check=' . json_encode($location->warehouse));
		// check if location is warehouse
		if ($location->warehouse == 1) {
			$rack_data = $request->get('rack_data');
			$warehouse = warehouse::where('location_id', $location_id)->first();
			Log::debug('warehouse=' . json_encode($warehouse));
			if ($warehouse) {
				$rack_list = rack::where('warehouse_id', $warehouse->id)->get();
			}
			foreach ($barcode_product as $key => $value) {
				
				if ($warehouse) {
					// $final_qty = $this->location_productqty($value->id, $location_id);
					if ($key == 0) {
						$rack_product_qty = 0;
						$rack_id = stockreportproductrack::
						join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
							->where('stockreportproduct.product_id', $value->id)
							->orderby('stockreportproductrack.rack_id', 'desc')->value('rack_id');
						if (empty($rack_id)) {
							$rack_id = rack::where('warehouse_id', $warehouse->id)->orderby('id', 'asc')->value('id');
						}
						// $rack_id = '';
						$rack = array();
						$total_qty = 0;
						foreach ($rack_list as $rk_key => $rk_value) {
							$rack_product_count = stockreportproductrack::
							join('stockreportproduct', 'stockreportproductrack.stockreportproduct_id', '=', 'stockreportproduct.id')
								->where('stockreportproduct.product_id', $value->id)
								->where('stockreportproductrack.rack_id', $rk_value->id)
								->sum('stockreportproduct.quantity');
							
							if ($type == "OUT") {
								if ($rack_product_count <= 0) {
									continue;
								}
							}
							$rack[$rk_key] = $rk_value;
							// $total_qty += $rack_product_count;
						}
						
						// if($type == "OUT") {
						//     if($total_qty <=0 ) {continue;}
						// }
						if ($rack_data) {
							foreach ($rack_data as $rd_key => $rd_value) {
								if ($rd_value['product_id'] == $value->id) {
									$rack_id = $rd_value['rack_id'];
								}
							}
							// if($rack_id) {
							//     $total_qty = stockreportproductrack::
							//     join('stockreportproduct','stockreportproductrack.stockreportproduct_id','=','stockreportproduct.id')
							//     ->where('stockreportproduct.product_id',$value->id)
							//     ->where('stockreportproductrack.rack_id',$rack_id)
							//     ->sum('stockreportproduct.quantity');
							// }
						}
						$final_qty = $this->location_productqty($value->id, $location_id);
						log::debug('final_qty' . $final_qty);
						$rack_no = rack::where('id', $rack_id)->value('rack_no');
						$final_product[$key] = $value;
						$final_product[$key]->warehouse = 1;
						$final_product[$key]->qty = $final_qty;
						$final_product[$key]->product_id = $value->id;
						$final_product[$key]->first_product = 1;
						$final_product[$key]->rack = $rack;
						$final_product[$key]->rack_id = $rack_id;
						$final_product[$key]->rack_no = $rack_no;
						$final_product[$key]->location_id = $location_id;
					} else {
						$rack_product_qty = 0;
						$rack_id = productbarcodelocation::
						where('productbarcode_id', $value->barcode_id)
							->where('location_id', $location_id)
							->orderby('id', 'desc')
							->pluck('rack_id')->first();
						if (empty($rack_id)) {
							$rack_id = rack::where('warehouse_id', $warehouse->id)->orderby('id', 'asc')->pluck('id')->first();
						}
						// $rack_id = '';
						// $rack = array();
						$total_qty = 0;
						$rack_product_count = productbarcodelocation::
						where('productbarcode_id', $value->barcode_id)
							->where('location_id', $location_id)
							->sum('quantity');
						if ($type == "OUT") {
							if ($rack_product_count <= 0) {
								continue;
							}
						}
						// $rack[$rk_key]=$rk_value;
						$total_qty += $rack_product_count;
						// foreach ($rack_list as $rk_key => $rk_value) {
						// }
						if ($type == "OUT") {
							if ($total_qty <= 0) {
								continue;
							}
						}
						// log::debug('rack_data'.json_encode($rack_data));
						if ($rack_data) {
							foreach ($rack_data as $rd_key => $rd_value) {
								if ($rd_value['product_id'] == $value->barcode_id) {
									$rack_id = $rd_value['rack_id'];
								}
							}
							// if($rack_id) {
							//     $total_qty = productbarcodelocation::
							//         where('productbarcode_id',$value->barcode_id)
							//         ->where('rack_id',$rack_id)
							//         ->where('location_id',$location_id)
							//         ->orderby('id','desc')
							//         ->pluck('quantity')->first();
							// }
						}
						// log::debug('total_qty'.$total_qty);
						$rack_no = rack::where('id', $rack_id)->value('rack_no');
						$final_product[$key] = $value;
						$final_product[$key]->warehouse = 1;
						$final_product[$key]->qty = $total_qty;
						$final_product[$key]->product_id = $value->id;
						$final_product[$key]->rack = $rack_list;
						$final_product[$key]->rack_id = $rack_id;
						$final_product[$key]->first_product = 0;
						$final_product[$key]->rack_no = $rack_no;
						$final_product[$key]->location_id = $location_id;
						$final_product[0]->qty -= $total_qty;
					}
				}
			}
		} else {
			foreach ($barcode_product as $key => $value) {
				if ($key == 0) {
					$final_qty = $this->location_productqty($value->id, $location_id);
					$final_product[$key] = $value;
					$final_product[$key]->qty = $final_qty;
					$final_product[$key]->rack = $rack;
					$final_product[$key]->first_product = 1;
					$final_product[$key]->location_id = $location_id;
				} else {
					$final_qty = productbarcodelocation::
					where('productbarcode_id', $value->barcode_id)
						->where('location_id', $location_id)
						->sum('quantity');
					$final_product[$key] = $value;
					$final_product[$key]->qty = $final_qty;
					$final_product[$key]->rack = $rack;
					$final_product[$key]->first_product = 0;
					$final_product[$key]->location_id = $location_id;
					$final_product[0]->qty -= $final_qty;
				}
				
				if ($type == "OUT") {
					if ($final_qty <= 0) {
						continue;
					}
				}
			}
		}
		// log::debug('final_product'.json_encode($final_product));
		return Datatables::of($final_product)->
		addIndexColumn()->
		addColumn('inven_pro_id', function ($memberList) {
			return $memberList->barcode;
		})->
		addColumn('inven_pro_name', function ($memberList) {
			return '<img src="' . asset('images/product/' . $memberList->id . '/thumb/' . $memberList->thumbnail_1) . '" style="height:40px;width:40px;object-fit:contain;margin-right:8px;">' . $memberList->name;
		})->
		addColumn('inven_pro_colour', function ($memberList) {
			$product_color = productcolor::join('color', 'productcolor.color_id', '=', 'color.id')
				->where('productcolor.product_id', $memberList->product_id)->first();
			if ($product_color) {
				return $product_color->name;
			}
			return "-";
		})->
		addColumn('inven_pro_matrix', function ($memberList) {
			return '-';
		})->
		addColumn('inven_pro_rack', function ($memberList) {
			if (count($memberList->rack) <= 0) {
				return '-';
			}
			return '<div style="cursor: pointer;"
                        class="rack_list" id="' . $memberList->barcode_id . '" onclick="open_rack(' . $memberList->barcode_id . ',' . $memberList->first_product . ')">' . (($memberList->rack_no) ? $memberList->rack_no : "-") . '</div>';                       // <div class="os-linkcolor rack_list" style="cursor:pointer" id="'.$memberList->id.'" onclick="open_rack('.$memberList->id.',)" >'.(($memberList->rack_id) ? $memberList->rack_id : "-" ).' </div>';
		})->
		
		addColumn('inven_pro_existing_qty', function ($memberList) {
			return ($memberList->qty) ? $memberList->qty : 0;
		})->
		addColumn('inven_pro_qty', function ($memberList) {
			return '<div class="value-button increase" id="increase_' . $memberList->barcode_id . '" onclick="increaseValue(' . $memberList->barcode_id . ')" value="Increase Value" style="margin-top:-25px;"><ion-icon class="ion-ios-plus-outline" style="font-size: 24px;margin-right:10px;"></ion-icon>
                    </div><input type="number" id="number_' . $memberList->barcode_id . '"  class="number product_qty" value="0" min="0"  required>
                    <div class="value-button decrease" id="decrease_' . $memberList->barcode_id . '" onclick="decreaseValue(' . $memberList->barcode_id . ')" value="Decrease Value" style="margin-top:-25px;"><ion-icon class="ion-ios-minus-outline" style="font-size: 24px;"></ion-icon>
                    </div>';
		})->
		escapeColumns([])->
		make(true);
		
	}
	
	public function updateProductBarcodeQuantity(Request $request)
	{
		try {
			$id = Auth::user()->id;
			
			$table_data = $request->get('table_data');
			$warehouse = $request->get('warehouse');
			$stock_type = $request->get('stock_type');
			$system_id = $request->get('system_id');
			$total_qty = 0;
			/*
			$stock_system = DB::
				select("select nextval(stockreport_seq) as index_stock");

			$stock_system_id = $stock_system[0]->index_stock;
			$stock_system_id = sprintf("%010s", $stock_system_id);
			$stock_system_id = '111' . $stock_system_id;
			*/

			// Squidster: Replaces old mechanism
			$stock_system = new SystemID('stockreport');
			$stock_system_id = $stock_system->__toString();
			Log::debug('stock in data='.json_encode($table_data ));
			//$i =0;
			foreach ($table_data as $key => $value) {
				//$i++;
				Log::debug('value='.json_encode($value));

				// Don't add new record if qty <= 0
				if ($value['qty'] <= 0) continue;

				$pbloc = new productbarcodelocation();

				// Squidster: this is NOT correct!!
				$pbloc->productbarcode_id = $value['product_id'];

				$pbloc->location_id = $value['location_id'];
				if ($warehouse == 1) {
					$pbloc->rack_id = $value['rack_id'];
				} else {
					$pbloc->rack_id = 0;
				}

				$pbloc->quantity = ($stock_type == 'IN') ?
					$value['qty'] : '-' . $value['qty'];

				$pbloc->save();

				Log::debug('value["product_id"]='.
					json_encode($value['product_id']));
				$bar_product = productbarcode::where('product_id',
								$value['product_id'])->first();
				if($bar_product==null){
				
					$bar_product = productbarcode::where('id',
													$value['product_id'])->first();
				}
				Log::debug('bar_product='.json_encode($bar_product));

				
				if($bar_product==null){
				
					$product_details = product::where('id',
					$value['product_id'])->first();
				}else{

					$product_details = product::where('id',
					$bar_product->product_id)->first();
				}

				$stock = new StockReport();
				$stock->creator_user_id = Auth::user()->id;

				//('voided', 'transfer', 'stockin', 'stockout', 'stocktake')
				$stock->type = ($stock_type == 'IN') ? 3 : 4;
				$stock->systemid = $stock_system_id;
				$stock->quantity = ($stock_type == 'IN') ?
					$value['qty'] : '-' . $value['qty'];

				$stock->product_id = $product_details->id;
				$stock->status = 'confirmed';
				$stock->location_id = $value['location_id'];
				$stock->save();
				$total_qty += $value['qty'];
			}
			
			if ($total_qty > 0) {
				$msg = "Stock In performed succesfully";
			} else {
				$msg = "Please select product";
			}
			$data = view('layouts.dialog', compact('msg'));
			
		} catch (\Exception $e) {
			$msg = "Error occured while saving stock";
			
			Log::error(
				"Error @ " . $e->getLine() . " file " . $e->getFile() .
				":" . $e->getMessage()
			);
			
			$data = view('layouts.dialog', compact('msg'));
		}
		return $data;
	}
	
	public function showInventoryStockOut()
	{
		$id = Auth::user()->id;
		$user_roles = usersrole::where('user_id', $id)->get();
		
		$is_king = \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
		$this->user_data = new UserData();
		$modal = "newLocationDialog";
		$ids = merchantlocation::where('merchant_id', $this->user_data->company_id())->pluck('location_id');
		$location = location::where([['branch', '!=', 'null']])->whereIn('id', $ids)->latest()->get();
		
		if ($is_king != null) {
			$is_king = true;
		} else {
			$is_king = false;
		}
		return view('inventory.inventorystockout',
			compact('user_roles', 'is_king', 'location'));
	}

	
}
