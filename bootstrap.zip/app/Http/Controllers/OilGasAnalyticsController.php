<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\usersrole;
use \App\Models\role;
use \Illuminate\Support\Facades\Auth;
use App\Models\merchantlocation;
use App\Models\location;
use App\Classes\UserData;
use Carbon\Carbon;
use DB;
class OilGasAnalyticsController extends Controller
{
    public function index() {
		$id = Auth::user()->id;
		$name = Auth::user()->name;
		$logged_in_user_id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();
		
        if ($is_king != null) {
			$is_king = true;
        } else {
            $is_king  = false;
        }
		//User Creation Date
		$userCreatedDate = DB::select('
			SELECT
				c.created_at
			FROM
				company c
			WHERE
				c.owner_user_id = '.$id.'
		');
		$userCreatedDate = Carbon::parse($userCreatedDate[0]->created_at)->format('d F Y');
		
		//branch location
		$branch_location = DB::select('
			SELECT
				l.branch,
				l.created_at,
				l.id,
				c.name
			FROM
				company c,
				merchant m,
				location l,
				merchantlocation ml
			WHERE
				c.owner_user_id = '.$id.'
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND l.branch is NOT NULL
				AND l.deleted_at is NULL;
		');
		
		$pumps = [];
		$volumes = [];
		$json_pumps = json_encode($pumps, JSON_HEX_APOS);
		$json_volumes = json_encode($volumes, JSON_HEX_APOS);
		
		return view('industry.oil_gas.analytics.og_pump_volume', compact('branch_location','json_pumps','json_volumes','userCreatedDate'));
    }
	
	public function loadChartData(Request $request) {
		
		$id = Auth::user()->id;
		$name = Auth::user()->name;
		$logged_in_user_id = Auth::user()->id;
		$user_roles = usersrole::where('user_id',$id)->get();
		$selectedDate = $request->selectedDate;
		$location_id = $request->location_id;
		
        $is_king =  \App\Models\Company::where('owner_user_id',
			Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;

        } else {
            $is_king  = false;
        }
		// fetch chart data according to owner_user_id,location_id and pump created date
		$pump_volumes = DB::select(
			'SELECT pump,SUM(volume) as volume, l.branch
			FROM 
				company c,
				merchant m,
				location l,
				og_controller oc,
				og_pumplog o,
				merchantlocation ml
				
			WHERE
				c.owner_user_id = :id
				AND l.id = :location_id
				AND m.company_id = c.id
				AND ml.merchant_id = m.id
				AND ml.location_id = l.id
				AND oc.location_id = l.id
				AND o.controller_id = oc.device_id
				AND DATE(o.created_at) = :selectedDate
			GROUP BY
				o.pump
			ORDER BY (o.pump) ASC;',["id"=>$id,"location_id"=>intval($location_id),"selectedDate"=>date($selectedDate)]
			
		);
		$pumps = [];
		$volumes = [];
		foreach($pump_volumes as $pump_volume){
			
			$pumps[] = 'Pump No ' . $pump_volume->pump;
		
			$volumes[] = sprintf("%.2f", $pump_volume->volume);
			
		}
		$json_pumps = json_encode($pumps, JSON_HEX_APOS);
		$json_volumes = json_encode($volumes, JSON_HEX_APOS);
		
		return response()->json(['json_pumps' => $json_pumps,'json_volumes' => $json_volumes]);
    }
	
}

