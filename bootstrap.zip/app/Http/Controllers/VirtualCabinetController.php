<?php

namespace App\Http\Controllers;

use App\StockReport;
use Illuminate\Http\Request;
use \App\Http\Controllers\FinancialYearController;
use App\Models\FinancialYear;
use Log;
use \App\Classes\SystemID;
use \App\Classes\UserData;
use Illuminate\Support\Facades\Auth;
use App\Models\usersrole;
use Matrix\Exception;
use Yajra\DataTables\DataTables;
use \App\Models\terminal;
use \App\Models\location;
use \App\Models\locationterminal;
use \App\Models\merchantlocation;
use \App\Models\opos_receipt;
use App\Models\Merchant;
use \App\Models\merchantproduct;
use App\Models\inventorycost;
use Carbon\Carbon;

use App\Models\Creditnote;

use App\Models\Debitnote;

class VirtualCabinetController extends Controller
{

	public function showVCAutoView() {
		Log::debug('***** showVCAutoView() *****');
        $FYData = new FinancialYearController();
        $FYData = $FYData->showFinancialYearView();
        return view('virtualcabinet.vc_auto',compact('FYData'));
    }

	function show1View($id) {
		try {

		if (!filter_var($id, FILTER_VALIDATE_INT)) {
			throw new Exception("validation_error", 1);
		}
	
		$FY = FinancialYear::find($id);

		$this->user_data = new UserData();
		$model           = new locationterminal();

        $ids  = 
        merchantlocation::join('location','location.id','=',
            'merchantlocation.location_id')->
            where('merchantlocation.merchant_id',
            $this->user_data->company_id())->
            whereNull('location.deleted_at')->
            pluck('merchantlocation.location_id');

        $dlt=$model->whereIn('location_id', $ids)->get('terminal_id');
		$dltrec =terminal::whereIn('id',$dlt)->get('id');

		$userId = Auth::user()->id;
		$merchant = Merchant::select('merchant.id as id')
			->join('company', 'company.id', '=', 'merchant.company_id')
			->where('company.owner_user_id', $userId)->first();

		if (!$FY) {
			throw new Exception("FY_not_found", 25);
		}

		$start_yr = $FY->start_financial_year->format('dMy');

		$end_yr  = (\Carbon\Carbon::create($FY->start_financial_year->toDateTimeString())->
			add(1,'year')->add(-1,'day')->format('dMy'));


		$damageyr = $FY->start_financial_year->format('y');
            	
		$damage = Merchantproduct::where('merchant_id',$merchant->id)
				->join("product", 'merchantproduct.product_id', '=', 'product.id')
				->join("opos_receiptproduct", 'product.id', '=', 'opos_receiptproduct.product_id')
				->join("opos_refund", 'opos_receiptproduct.id', '=', 'opos_refund.receiptproduct_id')
				->join("opos_damagerefund", 'opos_refund.id' , '=', 'opos_damagerefund.refund_id')
				->leftjoin('opos_receipt', 'opos_receiptproduct.receipt_id', '=', 'opos_receipt.id')
				->select('product.systemid as productsys_id', 'product.id as product_id', 'product.thumbnail_1', 'opos_receiptproduct.name', 'opos_receipt.systemid as document_no', 'opos_damagerefund.damage_qty as quantity', 'opos_damagerefund.created_at as last_update')
				->get();
			
		$wastage = Merchantproduct::where('merchant_id',$merchant->id)
			 ->join("product", 'merchantproduct.product_id', '=', 'product.id')
			 ->join("opos_wastageproduct",'product.id' , '=','opos_wastageproduct.product_id' )
			 ->join('opos_wastage', 'opos_wastage.id', '=', 'opos_wastageproduct.wastage_id')
			 ->select('product.systemid as productsys_id', 'product.id as product_id', 'product.thumbnail_1', 'product.name', 'opos_wastage.systemid as document_no', 'opos_wastageproduct.wastage_qty as quantity', 'opos_wastageproduct.created_at as last_update')
			->get();

		$item_count = count($wastage);
		foreach ($wastage as $key => $value) {
			$damage[$item_count] = $value;
			$damage[$item_count]->type = 'wastage';
			$item_count++;
		}

		for($i=0;$i<12;$i++) {
			$opmonthreceipt[$i]=opos_receipt::
				whereIn('terminal_id',$dltrec)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			$opmonthterminal[$i]=opos_receipt::
				whereIn('terminal_id',$dltrec)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get('terminal_id')->count();

			$inventoryCost[$i] = inventorycost::
				where('buyer_merchant_id', $merchant->id)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			$tracking_report[$i] = StockReport::
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			$creditissue[$i] = Creditnote::where('creator_user_id',$userId)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			$debitissue[$i] = Debitnote::where('creator_user_id',$userId)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();


			$creditreceived[$i] = Creditnote::where('creator_user_id','!=',$userId)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			$debitreceived[$i] = Debitnote::where('creator_user_id','!=',$userId)->
				whereMonth('created_at',$i+1)->
				whereBetween('created_at', [
					new Carbon($start_yr),
					new Carbon($end_yr)
				])->get()->count();

			foreach($damage as $data){
				if(strval($i+1)== date('m', strtotime($data->last_update)) &&
				$damageyr == date('y', strtotime($data->last_update))){

				$damagewastedate[$i] = date('m', strtotime($data->last_update));
				break;

				} else{
				   $damagewastedate[$i] ='';
				}                   
			}     
		}

		// Squidster: protect $damagewastedate
		if (empty($damagewastedate)) $damagewastedate = null;

		$data = view('virtualcabinet.auto_template',
			compact('FY','start_yr','end_yr','opmonthreceipt',
			'opmonthterminal', 'inventoryCost', 'tracking_report',
			'damagewastedate','creditissue','debitissue','creditreceived','debitreceived'));

		} catch (\Exception $e) {
			if ($e->getMessage() == 'validation_error') {
				$msg ="Invalid request";
			} else if ($e->getMessage() == 'FY_not_found') {
				$msg ="Error occured while opening Financial Year, Invalid FinancialYear selected";
			}  else {
				$msg ="Error occured while opening dialog";
			}
			
			Log::error("Error @ ".$e->getLine()." file ".$e->getFile().
			  ":".$e->getMessage());
			$data = view('layouts.dialog',compact('msg'));
		}

		return $data;
	}

	public function inventoryCosts(Request $request) {


	    $month = $request->input('month');

        $userData = new UserData();
        $buyerMerchantId = $userData->company_id();



        $query = inventorycost::selectRaw("inventorycost.id as inventory_cost_id,DATE_FORMAT(doc_date, '%d%b%y') as dated ,doc_no");



        /*
        // name filter
        $search = $request->input('search');
        if (isset($search['value']) && $search['value'] != '')
            $query->where('title', 'like', '%'.$search['value'].'%');
        */

        /*
        // order by
        $order = $request->input('order');
        if (isset($order[0]['column']) && $order[0]['column'] != '') {
            if ($order[0]['column'] == 2) {
                $query->orderBy('title', $order[0]['dir']);
            }
            if ($order[0]['column'] == 4) {
                $query->orderBy('price', $order[0]['dir']);
            }
        }
        */
        $query->orderBy('doc_date', 'desc');

        $query->where('inventorycost.buyer_merchant_id', $buyerMerchantId)->whereMonth('inventorycost.created_at',$month+1);

        $totalRecords = $query->get()->count();

        // applying limit
        $inventoryCostDetails = $query->skip($request->input('start'))->take($request->input('length'))->get();


        $counter = 0 + $request->input('start');

        foreach ($inventoryCostDetails as $key => $inventoryCost) {
            $inventoryCostDetails[$key]['indexNumber'] = ++$counter;
        }

        $response = [
            'data' => $inventoryCostDetails,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords
        ];
        return response()->json($response);

    }


	function showPigeonView() {
		return view('virtualcabinet.pigeon');
	}
	function showVCRackView()
	{
		 $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
		return view('virtualcabinet.manual_rack',compact('user_roles','is_king'));
	}

	function showVCRackFileView()
	{
		 $id = Auth::user()->id;
        $user_roles = usersrole::where('user_id',$id)->get();

        $is_king =  \App\Models\Company::where('owner_user_id',Auth::user()->id)->first();

        if ($is_king != null) {
            $is_king = true;
        } else {
            $is_king  = false;
        }
		return view('virtualcabinet.manual_rack_file',compact('user_roles','is_king'));
	}

	function terminal_model(Request $request){
		try {
			$date = $request->date;
			$month = $request->month;
			
			return view('virtualcabinet.opossum_terminal_list',compact('date','month'));

		} catch (\Exception $e) {

                Log::error(
                    "Error @ " . $e->getLine() . " file " . $e->getFile() . ":" . $e->getMessage()
                );

        }
	}

	function tracking_report_model(Request $request){
		try {
			$date = $request->date;
			$month = $request->month;

			return view('virtualcabinet.opossum_terminal_list',compact('date','month'));

		} catch (\Exception $e) {

                Log::error(
                    "Error @ " . $e->getLine() . " file " . $e->getFile() . ":" . $e->getMessage()
                );

        }
	}

	function tracking_report_model_data(Request $request)
    {
        try {

            $this->user_data = new UserData();
            $model           = new StockReport();

            $data = $model->whereMonth('created_at',$request->month+1)->orderBy('created_at', 'asc')->latest()->get();

            return Datatables::of($data)
                ->addIndexColumn()

                ->addColumn('terminal_id', function ($location) {

                    return '<p class="os-linkcolor loyaltyOutput" data-field="terminal_id" style="cursor: pointer; margin: 0; text-align: center;" data-target="#branch" data-toggle="modal">aaa</p>';
                })
                ->escapeColumns([])
                ->make(true);



        } catch (\Exception $e) {

            Log::error(
                "Error @ " . $e->getLine() . " file " . $e->getFile() . ":" . $e->getMessage()
            );
        }
    }


	function terminal_model_data(Request $request) {
		try {

			$this->user_data = new UserData();
			$model           = new locationterminal();
        	  	
			$ids  = merchantlocation::join('location','location.id','=',
				'merchantlocation.location_id')->
				where('merchantlocation.merchant_id',
				$this->user_data->company_id())->
				whereNull('location.deleted_at')->
				pluck('merchantlocation.location_id');

			$dlt=$model->whereIn('location_id', $ids)->get('terminal_id');
			$dltrec =terminal::whereIn('id',$dlt)->get('id');

			$oprece=opos_receipt::whereIn('terminal_id',$dltrec)->
				whereMonth('created_at',$request->month+1)->
				get("terminal_id");

			Log::debug('oprece'.json_encode($oprece));

			$data = $model->whereIn('terminal_id', $oprece)->
				orderBy('created_at', 'asc')->
				latest()->get();
				
			return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('loc_id', function ($location) {

                $location_systemid = location::find($location->location_id)->systemid;
                return '<p data-field="loc_id" style="cursor: pointer; margin: 0; text-align: center;">' . $location_systemid . '</p>';
            })
            ->addColumn('name', function ($location) {
                $terminal     = location::find($location->location_id)->branch;
                $locationname = empty($terminal) ? "Branch" : $terminal;
                return '<p class="os- linkcolor loyaltyOutput" data-field="branch" style=" margin: 0;" data-target="#branch" data-toggle="modal">' . $locationname . '</p>';
            })
            ->addColumn('terminal_id', function ($location) {
                $terminal          = terminal::find($location->terminal_id);
                $terminalrec=terminal::find($location->terminal_id)->terminalreceipt;
                
                $terminal_systemid = empty($terminal->systemid) ? "Terminal ID" : $terminal->systemid;
                return '<p class="os-linkcolor loyaltyOutput" data-field="terminal_id" style="cursor: pointer; margin: 0; text-align: center;" data-target="#branch" data-toggle="modal">' . $terminal_systemid . '</p>';
            })
            ->escapeColumns([])
            ->make(true);

		} catch (\Exception $e) {

			Log::error(
				"Error @ " . $e->getLine() . " file " .
					$e->getFile() . ":" . $e->getMessage()
			);
        }
	}
}
