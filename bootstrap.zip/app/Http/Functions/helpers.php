<?php

// QR Code generator
function qr_code_generator($qr_id) {
   return DNS2D::getBarcodePNG($qr_id, "QRCODE");
}

// Barcode Generator
function bar_code_generator($qr_id) {
   return DNS1D::getBarcodePNG($qr_id, "C39");
}

// For 3 digit sequence number
function seq_number_fix($number) {
   if(strlen($number) > 4)
      return substr($number, 2);
   if(strlen($number) > 3)
      return substr($number, 1);
   if(strlen($number) > 2)
      return substr($number, 0);
   if(strlen($number) > 1) 
      return '0' . $number;
   if(strlen($number) > 0) 
      return '00' . $number;
   return $number;
}

// To remove leading zeros from table prefix
function table_number_fix($number) {
   if ($number == 0) {
      return '';
   }
   return (int) $number;
}