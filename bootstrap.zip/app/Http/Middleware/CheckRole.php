<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use \App\Classes\UserData;
use \App\Models\role;
use \App\Models\usersrole;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $role)
    {

       $UserData  = new UserData();
        $user_type = Auth::user()->type;



        if ($role == 'onlysuperadmin') {

            if ($UserData->allow_all()) {
                return $next($request);
            }

            if (!$UserData->is_super_admin()) {
                abort(404);
            }

            return $next($request);

        } else if ($role == 'onlyuser') {

            if ($UserData->allow_all()) {
                return $next($request);
            }

            if ($user_type == 'admin') {
                abort(404);
            }

            return $next($request);
        }

        if ($UserData->is_super_king()) {
            return $next($request);
        }

        $role_id    = role::where('slug', $role)->first()->id;
        $user_roles = usersrole::where(['user_id' => Auth::User()->id, 'role_id' => $role_id])->get();

        if ($UserData->is_king()) {
            return $next($request);
        }

        if ($role == 'super') {
            if ($user_type != 'admin') {
                return abort(404);
            }
        }

        if ($user_roles->count() <= 0) {
            return abort(403);
        }

        return $next($request);
    }
}
